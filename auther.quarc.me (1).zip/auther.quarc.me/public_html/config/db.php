<?php
	
	$dbHOST = "localhost";
	$dbUSER = "pers0na2_auther";
	$dbPASS = "ZrDKv6G5";
	$dbNAME = "pers0na2_auther";

	@$db = mysqli_connect($dbHOST,$dbUSER,$dbPASS,$dbNAME);

	if(!$db){echo 'Ошибка подключения к БазеДанных'; exit();}  

	mysqli_set_charset($db,'utf8');
