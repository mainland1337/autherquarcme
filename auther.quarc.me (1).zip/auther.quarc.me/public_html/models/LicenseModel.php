<?php
	
	function TOKEN($login, $password, $binding, $version , $token){

		if(!$login && !$password)
			return false;

		if(!$binding && !$token && !$version)
			return false;

		$unix = date('d.m.Y H:i');

		$data['step1'] = md5($login);
		$data['step2'] = md5($password);
		$data['step3'] = md5($binding);
		$data['step4'] = md5($unix);
		$data['step5'] = md5($version);

		$check = $data['step1'] . $data['step2'] . $data['step3'] . $data['step4'] .  $data['step5'];

		$check = md5($check);

		if($token == $check)
			return $check;

		return false;
	}

	function EnterBinding($login, $binding){
		global $db;

		$login = SECURE($login);
		$binding = SECURE($binding);

		$query = "UPDATE `Users` SET `binding` = '{$binding}' WHERE `login` = '{$login}' LIMIT 1";

		return mysqli_query($db, $query);
	}

?>