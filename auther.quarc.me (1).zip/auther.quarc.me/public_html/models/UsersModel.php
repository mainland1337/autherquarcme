<?php

	function GetAllUsers($CurrentPage = 0, $MaxCount = false){
		global $db;

		$MaxCount = SECURE($MaxCount);
		$CurrentPage = SECURE($CurrentPage);

		
		if($MaxCount != false){
			$query = "SELECT * FROM `Users` WHERE 1 ORDER BY `id` DESC LIMIT {$CurrentPage}, {$MaxCount}";
		}else{$query = "SELECT * FROM `Users` WHERE 1";}
		
		$result = mysqli_query($db, $query);

		while ($row = mysqli_fetch_assoc($result)) {
			$array[] = $row;
		}
		return $array;
	}

	function deleteUser($id){
		global $db;

		$id = SECURE($id);

		$query = "DELETE FROM `Users` WHERE `id` = '{$id}' LIMIT 1";

		

		return mysqli_query($db, $query);
	}


	function saveUser($massive){
		
		global $db;

		$id = SECURE($massive['id']);
		$login = SECURE($massive['login']);
		$email = SECURE($massive['email']);
		$password = md5(SECURE($massive['password']));
		$subscription = strtotime(SECURE($massive['subscription']));
		$class = SECURE($massive['class']);
		$date_register = strtotime(SECURE($massive['date_register']));

		if($massive['password']){
			$query = "UPDATE `Users` SET 
			`login`= '{$login}',
			`email`= '{$email}',
			`password`= '{$password}',
			`subscription`= '{$subscription}',
			`class`= '{$class}',
			`date_register`= '{$date_register}' 
			WHERE `id` = '{$id}' ";
		}else{
			$query = "UPDATE `Users` SET 
			`login`= '{$login}',
			`email`= '{$email}',
			`subscription`= '{$subscription}',
			`class`= '{$class}',
			`date_register`= '{$date_register}' 
			WHERE `id` = '{$id}' ";
		}

		return mysqli_query($db, $query);
	}


	function deleteKey($massive){
		
		global $db;

		$id = SECURE($massive);
	
		$query = "DELETE FROM `appkeys` WHERE `keycode` = '{$id}' ";
		
		return mysqli_query($db, $query);
	}

	function deleteFile($massive){
		
		global $db;

		$id = SECURE($massive);
	
		$query = "DELETE FROM `files` WHERE `id` = '{$id}' ";
		
		return mysqli_query($db, $query);
	}


	function update_file($id, $filedata){
		
		global $db;

		$id = SECURE($id);
		$filedata = SECURE($filedata);
	
		$query = "UPDATE `files` SET `data`= NULL WHERE `keycode` = '{$id}'";
		
		return mysqli_query($db, $query);
	}

	function delete_filter($massive){
		
		global $db;

		$id = SECURE($massive);
	
		$query = "DELETE FROM `log_auto_action` WHERE `id` = '{$id}' ";
		
		return mysqli_query($db, $query);
	}

	function resetHwidKey($massive){
		
		global $db;

		$id = SECURE($massive);
	
		$query = "UPDATE `appkeys` SET `hwid`= NULL WHERE `keycode` = '{$id}'";
		
		return mysqli_query($db, $query);
	}

	function CheckUser($login, $password){
		global $db;

		$login = SECURE($login);
		$password = md5(SECURE($password));

		$query = "SELECT * FROM `Users` WHERE (`email` = '{$login}' or `login` = '{$login}') and `password` = '{$password}' LIMIT 1";

		$result = mysqli_query($db, $query);
		$row = mysqli_fetch_assoc($result);

		if($row != null){return $row;}
		if($row == null){return false;}
		
	}

	function GetUserByID($id){
		global $db;

		$login = SECURE($id);

		$query = "SELECT * FROM `Users` WHERE `id` = '{$login}' LIMIT 1";

		$result = mysqli_query($db, $query);
		$row = mysqli_fetch_assoc($result);

		if($row != null){return $row;}
		if($row == null){return false;}
		
	}

	function GetUserApps($user){
		global $db;
		
		$user_secure = SECURE($user);

		$query = "SELECT * FROM `appkeys` WHERE `profileid` = '{$user_secure}'";
		
		$result = mysqli_query($db, $query);
		
		while ($row = mysqli_fetch_assoc($result)) {
			$array[] = $row;
		}

		return $array;
	}

	function GetKeyLogs($user){
		global $db;
		
		$user_secure = SECURE($user);

		$query = "SELECT * FROM `applogs` WHERE `keycode` = '{$user_secure}'";
		
		$result = mysqli_query($db, $query);
		
		while ($row = mysqli_fetch_assoc($result)) {
			$array[] = $row;
		}

		return $array;
	}

	function GetAppKeys($id){
		global $db;
		
		$id_secure = SECURE($id);

		$query = "SELECT * FROM `appkeys` WHERE `profileid` = '{$id_secure}'";
		
		$result = mysqli_query($db, $query);
		
		while ($row = mysqli_fetch_assoc($result)) {
			$array[] = $row;
		}

		return $array;
	}

	function GetFiles($id){
		global $db;
		
		$id_secure = SECURE($id);

		$query = "SELECT * FROM `files` WHERE `secret_token` = '{$id_secure}'";
		
		$result = mysqli_query($db, $query);
		
		while ($row = mysqli_fetch_assoc($result)) {
			$array[] = $row;
		}

		return $array;
	}

	function GetKeyData($id){
		global $db;
		
		$id_secure = SECURE($id);

		$query = "SELECT * FROM `appkeys` WHERE `keycode` = '{$id_secure}'";
		
		$result = mysqli_query($db, $query);
		$row = mysqli_fetch_assoc($result);

		if($row != null){return $row;}
		if($row == null){return false;}
	}

	function GetLogAutomatization($id){
		global $db;

		$id = SECURE($id);

		$query = "SELECT * FROM `log_auto_action` WHERE `token` = '{$id}'";

		$result = mysqli_query($db, $query);
		
		while ($row = mysqli_fetch_assoc($result)) {
			$array[] = $row;
		}

		return $array;
	}

	function GiveInfo($id){
		global $db;

		$id = SECURE($id);

		$query = "SELECT * FROM `Users` WHERE `id` = '{$id}' or `login` = '{$id}' or `email` = '{$id}' LIMIT 1";

		$result = mysqli_query($db, $query);
		$row = mysqli_fetch_assoc($result);

		if($row != null){return $row;}
		if($row == null){return false;}
	}

	function RegisterKey($keycode, $time, $hwid){
		global $db;

		$keycode_secure = SECURE($keycode);
		$endtime_secure = SECURE($time);
		$hwid_secure = SECURE($hwid);
		$current_time = time();

		$query = "UPDATE `appkeys` SET `actived`= '1', `endtime`= '{$endtime_secure}', `starttime`= '{$current_time}', `hwid`= '{$hwid_secure}' WHERE `keycode` = '{$keycode_secure}' LIMIT 1";

		return mysqli_query($db, $query);
	}

	function ExpireKey($keycode){
		global $db;

		$keycode_secure = SECURE($keycode);

		$query = "UPDATE `appkeys` SET `endtime`= '1000' WHERE `keycode` = '{$keycode_secure}' LIMIT 1";

		return mysqli_query($db, $query);
	}

	function RegisterHWID($keycode, $hwid){
		global $db;

		$keycode_secure = SECURE($keycode);
		$hwid_secure = SECURE($hwid);

		$query = "UPDATE `appkeys` SET `hwid`= '{$hwid_secure}' WHERE `keycode` = '{$keycode_secure}'";

		return mysqli_query($db, $query);
	}

	function create_log_filter($token, $filter, $action){
		global $db;

		$action_secure = SECURE($action);
		$filter_secure = SECURE($filter);
		$token_secure = SECURE($token);

		$query = "INSERT INTO `log_auto_action` (`token`,`tag_filter`, `action` ) VALUES ('{$token_secure}', '{$filter_secure}', '{$action_secure}')";

		return mysqli_query($db, $query);
	}

	function create_file($filename, $rsa_key, $secure_type,$secret_token, $data){
		global $db;

		$filename_secure = SECURE($filename);
		$rsa_key_secure = SECURE($rsa_key);
		$tsecure_type_secure = SECURE($secure_type);
		$secret_token_secure = SECURE($secret_token);

		$query = "INSERT INTO `files` (`filename`,`rsa_key`, `secure_type`, `secret_token`, `data` ) VALUES ('{$filename_secure}', '{$rsa_key_secure}', '{$tsecure_type_secure}', '{$secret_token_secure}', '{$data}')";

		return mysqli_query($db, $query);
	}


	function create_log($keycode, $message, $tag, $token){
		global $db;

		$keycode_secure = SECURE($keycode);
		$message_secure = SECURE($message);
		$tag_secure = SECURE($tag);
		$token_secure = SECURE($token);
		$ip = $_SERVER['REMOTE_ADDR']; 

		$query = "INSERT INTO `applogs` (`ip`,`token`,`keycode`, `message`, `tag` ) VALUES ('{$ip}','{$token_secure}', '{$keycode_secure}', '{$message_secure}' , '{$tag_secure}')";

		return mysqli_query($db, $query);
	}

	function GiveAppInfo($id){
		global $db;

		$id = SECURE($id);

		$query = "SELECT * FROM `apps` WHERE `id` = '{$id}' LIMIT 1";

		$result = mysqli_query($db, $query);
		$row = mysqli_fetch_assoc($result);

		if($row != null){return $row;}
		if($row == null){return false;}
	}

	function setclassUser($id){
		global $db;

		$id = SECURE($id);
		$action = GiveInfo($id);

		if($action['class'] == "banned"){
			$query = "UPDATE `Users` SET `class`= 'user' WHERE `id` = '{$id}' or `login` = '{$id}' LIMIT 1";
		}else{
			$query = "UPDATE `Users` SET `class`= 'banned' WHERE `id` = '{$id}' or `login` = '{$id}' LIMIT 1";
		}


		return mysqli_query($db, $query);
	}


	function register($login, $email, $password){
		global $db;

		$login = SECURE($login);
		$email = SECURE($email);
		$password = md5(SECURE($password));
		$date_register = time() - 10;
		$subscription = time() - 10;
		$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$token = substr(str_shuffle($permitted_chars), 0, 32);
		$secret_token = substr(str_shuffle($permitted_chars), 0, 32);
		$query = "INSERT INTO `Users`(`token`, `secret_token`, `login`, `email`, `password`, `subscription`, `date_register`) VALUES ('{$token}','{$secret_token}','{$login}' , '{$email}' , '{$password}' , '{$subscription}' , '{$date_register}')";

		return mysqli_query($db, $query);
	}

	function create_app($profileid, $keycode, $hours, $tag){
		global $db;

		$profileid_secure = SECURE($profileid);
		$keycode_secure = SECURE($keycode);
		$hours_secure = SECURE($hours);
		$tag_secure = SECURE($tag);

		$query = "INSERT INTO `appkeys` (`profileid`, `keycode`, `hours`, `tag` ) VALUES ('{$profileid_secure}' , '{$keycode}' , '{$hours}', '{$tag}')";

		return mysqli_query($db, $query);
	}

	function resetPassword($login, $password){
		global $db;

		$login = SECURE($login);
		$password = SECURE($password);

		$query = "UPDATE `Users` SET `password`= '{$password}' WHERE `login` = '{$login}' LIMIT 1";

		return mysqli_query($db, $query);
	}

	function LeftTimeCalc($time){

		$time = $time - time();

		if(/*$time >= 31104000 && */$time >= 2592000){
			$time = $time / 60 / 60 / 24 / 30 / 12;
			$time = intval($time);
			$res  = $time . 'г';
			return $res;
		}
		if($time >= 2592000 && $time >= 86400){
			$time = $time / 60 / 60 / 24 / 30;
			$time = intval($time);
			$res  = $time . 'мес';
			return $res;
		}
		if($time >= 86400){
			$time = $time / 60 / 60 / 24;
			$time = intval($time);
			$res  = $time . 'д';
			return $res;
		}
		if($time <= 86400 && $time >= 3600){
			$time = $time / 60 / 60;
			$time = intval($time);
			$res  = $time . 'ч';
			return $res;
		}
		if($time <= 3600 && $time >= 60){
			$time = $time / 60;
			$time = intval($time);
			$res  = $time . 'мин';
			return $res;
		}
		if($time <= 60 && $time >= 0){
			$time = $time;
			$time = intval($time);
			$res  = $time . 'cек';
			return $res;
		}
	}

	function AddNewUser($login, $time){
		global $db;

		$login = SECURE($login);
		$time = SECURE($time);

		$info = GiveInfo($login);
		$CurrentTime = time();

		if($info['subscription'] >= time()){
			$AddTime = $info['subscription'] + $time;
		}else{
			$AddTime = $CurrentTime + $time;
		}

		$query = "UPDATE `Users` SET `subscription` = '{$AddTime}' WHERE `login` = '{$login}' LIMIT 1";

		return mysqli_query($db, $query);
	}

	function AddAllTime($array, $time){
		global $db;

		$time = SECURE($time);
		$time = $time * (60 * 60 * 24);

		foreach ($array as $key => $value) {
			
			$id = SECURE($value['id']);
			$subscription = SECURE($value['subscription']);
			$subscription = $subscription + $time;

			$query = "UPDATE `Users` SET `subscription` = '{$subscription}' WHERE `id` = '{$id}'";

			mysqli_query($db, $query);
		}

		return 0;
	}

?>
