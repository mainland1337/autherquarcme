<?php


function RandomBuild(){
	$update_dir = '../builds/';
	
	$open_dir_build = opendir($update_dir);
	
	$array_exe_files = array();
	
	while( $file = readdir($open_dir_build) )
	{
		if( $file == '.' || $file == '..' || is_dir($update_dir.$file) )
			continue;

		$file_info = new SplFileInfo($file);
		
		if ( $file_info->getExtension() == "exe" )
		{
			array_push($array_exe_files,$file);
		}
	}
	
	closedir($open_dir_build);
	
	$rand_build_id = rand(0,count($array_exe_files) - 1);
	
	$exe_file= new SplFileInfo($update_dir.$array_exe_files[$rand_build_id]);

	return $exe_file;
}


function DownloadNewBuild($exe_file, $zip_name)
{


	if( extension_loaded('zip') )
	{

		$zip = new ZipArchive();

		$zipn = $zip_name;

		$zip_name = "../builds/users/" . $zip_name;
		
		if($zip->open($zip_name , ZIPARCHIVE::CREATE)!==TRUE)
			exit;
		$name = mb_strimwidth(md5(rand(100000, 100000000)), '0', '15');
		$name .= mb_strimwidth(md5(rand(100000, 100000000)), '0', '15');
		$name .= mb_strimwidth(md5(rand(100000, 100000000)), '0', '20');
		$name = $name . ".exe";


		$zip->addFile($exe_file , $name);
		
		$zip->close();
		
		if( file_exists($zip_name) )
		{
			header("Pragma: public");
			header("Expires: 0");
			header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
			header("Cache-Control: public");
			header("Content-Description: File Transfer");
			header("Content-type: application/octet-stream");
			header("Content-Disposition: attachment; filename=\"" . $zipn . "\"");
			header("Content-Transfer-Encoding: binary");
			header("Content-Length: ".filesize($zip_name));
			readfile($zip_name);
			//unlink($zip_name);
			unlink($exe_file);
		}
	}
}
function DownloadBuild($zip_name)
{

	$derictory = '../builds/users/' . $zip_name;

	header("Pragma: public");
	header("Expires: 0");
	header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	header("Cache-Control: public");
	header("Content-Description: File Transfer");
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=\"".$zip_name."\"");
	header("Content-Transfer-Encoding: binary");
	header("Content-Length: ".filesize($derictory));
	readfile($derictory);

}

function CheckUserUpdate($login){
	global $db;

	$login = htmlspecialchars(mysqli_escape_string($db, $login));

	$query = "SELECT * FROM `updates` WHERE `login` = '{$login}' ORDER BY `id` DESC LIMIT 1";

	$result = mysqli_query($db, $query);

	$row = mysqli_fetch_assoc($result);
	if($row == null)
		return false;

	return $row;
}


function GetBuildCount(){
	$update_dir = '../builds/';
	$open_dir_build = opendir($update_dir);
	$update_count = 0;

	while( $file = readdir($open_dir_build) )
	{
		if( $file == '.' || $file == '..' || is_dir($update_dir.$file) )
			continue;

		$file_info = new SplFileInfo($file);

		if ( $file_info->getExtension() == "exe" )
		{
			$update_count++;
		}
	}
	closedir($open_dir_build);
	return $update_count;

}

function AddDownloadListUser($login , $name ,  $version){
	global $db;

	$login 		= SECURE($login);
	$name 		= SECURE($name);
	$version 	= SECURE($version);
	$time 		= time();

	$query = "INSERT INTO `updates` (`login`, `name`, `version`, `date`) 
	VALUES ('{$login}' , '{$name}' , '{$version}' , '{$time}')";

	return mysqli_query($db, $query);
}

?>