<?php /* Smarty version Smarty-3.1.6, created on 2019-04-27 18:36:43
         compiled from "../views/default/profile-reset-binding.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20397893405c410011009582-58477422%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b74eec8462b464e0995c30c5b87506ee974f8743' => 
    array (
      0 => '../views/default/profile-reset-binding.tpl',
      1 => 1556379401,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20397893405c410011009582-58477422',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5c4100110b3b9',
  'variables' => 
  array (
    'Title' => 0,
    'TicketInfo' => 0,
    'Me' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5c4100110b3b9')) {function content_5c4100110b3b9($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<head>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=Titillium+Web" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/0.7.2/p5.js"></script>
	<script type="text/javascript" src="https://vk.com/js/api/openapi.js?160"></script>
	<script src="https://night1taps.ru/main/js/jquery.redirect.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="shortcut icon" href="logotip_V2.png" type="image/png">
	<link href='https://fonts.googleapis.com/css?family=Monoton' rel='stylesheet' type='text/css'>
	<script type="text/javascript" src="https://vk.com/js/api/openapi.js?160"></script>
	<link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Poiret+One" rel="stylesheet">
	<title> <?php echo $_smarty_tpl->tpl_vars['Title']->value;?>
</title>
</head>

<body style="background: rgb(53, 75, 97);">	
	<div class="card text-center text-white mb-3 main_card " style="    margin-top: 100px;background-color: #d5d5d5; 
	margin-left: auto;
	margin-right: auto;
	width: 1000px;">		
		<div class="card-body ">
			<p class="card-text">
				<div class="row qdq1d1d">
					<div class="col-sm-12">
						<div class="card mb-3 card_body">
							<div class="card-body" style="color: rgb(72, 72, 72);">
								<?php if ($_smarty_tpl->tpl_vars['TicketInfo']->value==false){?>
								<h5 class="card-title" style="margin-bottom: 10px;">Логин: <?php echo $_smarty_tpl->tpl_vars['Me']->value['login'];?>
</h5>
								<form role="form" method="POST" action="/profile/res_binding/">
									<div class="txt-center ButtonBosX">
										<input type="submit" class="btn btn-outline-dark btn-block" value="Сбросить">
									</div>
								</form>
								<?php }?>
								<?php if ($_smarty_tpl->tpl_vars['TicketInfo']->value['status']=='active'){?>
								<h5 class="card-title" style="margin-bottom: 10px;">Логин: <?php echo $_smarty_tpl->tpl_vars['TicketInfo']->value['login'];?>
</h5>
								<h5 class="card-title" style="margin-bottom: 10px;">Дата создания: <?php echo date('d.m.Y H:i:s',$_smarty_tpl->tpl_vars['TicketInfo']->value['date']);?>
</h5>
								<h5 class="card-title" style="margin-bottom: 10px;">Статус заявик: На рассмотрении</h5>
								<?php }?>
								
								<?php if ($_smarty_tpl->tpl_vars['TicketInfo']->value['status']=='accept'){?>
								<h5 class="card-title" style="margin-bottom: 10px;">Логин: <?php echo $_smarty_tpl->tpl_vars['TicketInfo']->value['login'];?>
</h5>
								<h5 class="card-title" style="margin-bottom: 10px;">Дата создания: <?php echo date('d.m.Y H:i:s',$_smarty_tpl->tpl_vars['TicketInfo']->value['date']);?>
</h5>
								<h5 class="card-title" style="margin-bottom: 10px;">Статус заявик: Принято</h5>
								<?php }?>
								<?php if ($_smarty_tpl->tpl_vars['TicketInfo']->value['status']=='decline'){?>	
								<h5 class="card-title" style="margin-bottom: 10px;">Логин: <?php echo $_smarty_tpl->tpl_vars['TicketInfo']->value['login'];?>
</h5>
								<h5 class="card-title" style="margin-bottom: 10px;">Дата создания: <?php echo date('d.m.Y H:i:s',$_smarty_tpl->tpl_vars['TicketInfo']->value['date']);?>
</h5>
								<h5 class="card-title" style="margin-bottom: 10px;">Статус заявик: Отклонено</h5>
								<?php }?>
								
								<p class="card-text"></p>
							</div>
						</div>
					</div>
				</div>
				
			</p>
		</div>
		
		<div class="card-footer text-muted"><button type="button" class="btn btn-danger" onclick="document.location.href = 'http://eazyware.ru/profile'" style="padding: 0;
			padding-left: 5px;
			padding-right: 5px;
			background-color: rgba(56, 113, 220, 0.53);
			border-color: rgba(56, 113, 220,  0.37);">Вернутся в профиль</button>
		</div>
	</div>
</body>
<style>
	#footer {
	position: absolute;
	bottom: 0;
	text-align: center;
	width: 100%;
	height: 110px;
	padding-top: 35px;
	padding-bottom: 15px;
	color: #003873;
	}
	
	body {
	background-image: url(https://cdn.discordapp.com/attachments/357156696533106690/546051602977652738/2313131.png) !important;
	}
	
	
	@media (min-width: 200px){
	.main_card {
	max-width: 500px; 
	}
	}
	
	@media (min-width: 570px){
	.main_card {
	max-width: 1000px; 
	}
	}
	.card_body {
	background-color: rgba(0, 0, 0, 0.12)!important;
	}
	
	.card_body2 {
	background-color: rgba(0, 0, 0, 0.0)!important;
	text-indent: 10.10em; 
	margin-right: 50%;
	}
	
	.Buttonssssssssss {
	text-indent: 10.10em; 
	}
	
	
	.card_body_inner {
	background-color: rgba(0, 0, 0, 0.12)!important;
	letter-spacing: 1.1px;
	color: rgb(255, 255, 255);
	}
	
	.gradient-text {
	background: linear-gradient(45deg, rgb(137, 183, 255) 33%, rgb(73, 154, 255) 66%, rgb(173, 207, 255));
	-webkit-background-clip: text;
	-webkit-text-fill-color: transparent;
	color: #ffffff;
	}
	
	.stats_value {
	margin-top: 15px;
	color: rgba(114, 255, 196, 0.5490196078431373);
	background: linear-gradient(45deg, rgba(46, 53, 64, 0.45) 33%, rgba(60, 78, 101, 0.52) 66%, rgba(102, 122, 152, 0.5));
	display: -webkit-inline-box;
	text-align: -webkit-center;
	text-align: -webkit-center;
	line-height: 150px;
	width: 150px;
	height: 150px;
	-webkit-border-radius: 50%;
	-moz-border-radius: 50%;
	-ms-border-radius: 50%;
	-o-border-radius: 50%;
	border-radius: 50%;
	font-size: 28px;
	font-family: 'Monoton', cursive;
	box-shadow: 0 0 11px 6px rgba(53, 77, 97, 0.61);
	
	}
	
	.stats_value:hover {
	box-shadow: 0 0 20px 13px rgba(53, 77, 97, 0.61);
	}
	.zmdi {
	line-height: .9em;
	}
	
	.stats_text
	{
	color: #000000;
	padding: 10px;
	font-family: 'Poiret One';
	font-weight: bolder;
	font-size: 80%
	}
	
	.stats_row {
	background-color: rgba(255, 255, 255, 0.47)!important;
	margin-bottom: 5px;
	border-radius: 9px;
	max-width: 95%;
	padding: 5px;
	margin-left: auto;
	margin-right: auto;
	color: #000000;
	}
	
	.avatararea{
	width: 150px;
	height: 150px;
	margin-top: -10px;
	margin-left: 20px;
	border-radius: 10%;
	position: relative;
	background-color: rgba(255, 255, 255, 0.47)!important;
	background-size: 150px 150px;
	display: flex;
	justify-content: center;
	align-items: center;
	box-shadow: 0px 0px 15px #4a76a8;
	text-shadow: 0 0 black;
	box-shadow: inset 0 0 0px 100px rgba(0, 0, 0, 0), 0px 0px 15px #4a76a8;
	transition: 0.25s box-shadow, 0.33s color;
	position: fixed;
	z-index: 100;
	}
	
	.cpersonal-area{
	width: 1000px;
	height: 500px;
	position: fixed;
	left: 50%;
	top: 50%;
	transform: translate(-50%,-50%);
	background-size: 1000px 500px;
	border-radius: 10px;
	transition: .4s background , .4s color , .33s border-radius , .4s width;
	box-shadow: 0 15px 45px 0 rgba(255,255,255,.5);
	}
	
	.stats_row2 {
	background-color: rgba(255, 255, 255, 0.47)!important;
	margin-bottom: 5px;
	border-radius: 9px;
	max-width: 95%;
	padding: 5px;
	margin-left: auto;
	margin-right: auto;
	color: #000000;
	text-indent: 20.10em; 
	
	}
	
	.ButtonBosX{
	margin-bottom: 5px;
	border-radius: 9px;
	max-width: 30%;
	padding: 10px;
	margin-left: auto;
	margin-right: auto;
	color: #000000;
	text-indent: 1000.10em; 
	}	
	
	.ndchangeavatar{
	display: none;
	}		
	.qdq1d1d{
	margin-top: 0px;
	}
	
	
	.qdq1d1d1{
	text-indent: 4.0em; 
	color: #000000;
	}
	
	.qdq1d1d2{
	text-indent: 3.7em; 
	color: #000000;
	}
	
	.stats_icon {
	color: #000000;
	}
	
	.header_info {
	float: right;
	margin-bottom: -10px;
	}
	
	.rightssss { 
	right: 10px; /* Положение от правого края */
	width: 200px; /* Ширина блока */
	
	}
	
	h1 {
	font-family: "Avant Garde", Avantgarde, "Century Gothic", CenturyGothic, "AppleGothic", sans-serif;
	padding: 80px 50px;
	text-align: center;
	text-transform: uppercase;
	text-rendering: optimizeLegibility;
	}
	h1.elegantshadow {
	color: #131313;
	background-color: #e7e5e4;
	letter-spacing: 0.15em;
	text-shadow: 1px -1px 0 #767676, -1px 2px 1px #737272, -2px 4px 1px #767474, -3px 6px 1px #787777, -4px 8px 1px #7b7a7a, -5px 10px 1px #7f7d7d, -6px 12px 1px #828181, -7px 14px 1px #868585, -8px 16px 1px #8b8a89, -9px 18px 1px #8f8e8d, -10px 20px 1px #949392, -11px 22px 1px #999897, -12px 24px 1px #9e9c9c, -13px 26px 1px #a3a1a1, -14px 28px 1px #a8a6a6, -15px 30px 1px #adabab, -16px 32px 1px #b2b1b0, -17px 34px 1px #b7b6b5, -18px 36px 1px #bcbbba, -19px 38px 1px #c1bfbf, -20px 40px 1px #c6c4c4, -21px 42px 1px #cbc9c8, -22px 44px 1px #cfcdcd, -23px 46px 1px #d4d2d1, -24px 48px 1px #d8d6d5, -25px 50px 1px #dbdad9, -26px 52px 1px #dfdddc, -27px 54px 1px #e2e0df, -28px 56px 1px #e4e3e2;
	}
	h1.deepshadow {
	color: #e0dfdc;
	background-color: #333;
	letter-spacing: 0.1em;
	text-shadow: 0 -1px 0 #fff, 0 1px 0 #2e2e2e, 0 2px 0 #2c2c2c, 0 3px 0 #2a2a2a, 0 4px 0 #282828, 0 5px 0 #262626, 0 6px 0 #242424, 0 7px 0 #222, 0 8px 0 #202020, 0 9px 0 #1e1e1e, 0 10px 0 #1c1c1c, 0 11px 0 #1a1a1a, 0 12px 0 #181818, 0 13px 0 #161616, 0 14px 0 #141414, 0 15px 0 #121212, 0 22px 30px rgba(0, 0, 0, 0.9);
	}
	h1.insetshadow {
	color: #202020;
	background-color: #2d2d2d;
	letter-spacing: 0.1em;
	text-shadow: -1px -1px 1px #111, 2px 2px 1px #363636;
	}
	h1.retroshadow {
	color: #2c2c2c;
	background-color: #d5d5d5;
	letter-spacing: 0.05em;
	text-shadow: 4px 4px 0px #d5d5d5, 7px 7px 0px rgba(0, 0, 0, 0.2);
	}
</style>

<?php }} ?>