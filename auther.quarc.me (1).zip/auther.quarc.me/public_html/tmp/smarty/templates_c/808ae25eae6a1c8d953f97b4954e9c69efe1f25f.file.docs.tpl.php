<?php /* Smarty version Smarty-3.1.6, created on 2021-05-16 22:02:39
         compiled from "../views/default/docs.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1087788298601c3f6f9d9d04-15084018%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '808ae25eae6a1c8d953f97b4954e9c69efe1f25f' => 
    array (
      0 => '../views/default/docs.tpl',
      1 => 1621191758,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1087788298601c3f6f9d9d04-15084018',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_601c3f6fa378d',
  'variables' => 
  array (
    'Title' => 0,
    'Me' => 0,
    'status' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_601c3f6fa378d')) {function content_601c3f6fa378d($_smarty_tpl) {?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,500,500i,600,600i,700,700i&amp;subset=latin-ext">

    <link href="https://auther.quarc.me/views/default/css/tabler.min.css" rel="stylesheet" />
    <link href="https://auther.quarc.me/views/default/css/tabler-flags.min.css" rel="stylesheet" />
    <link href="https://auther.quarc.me/views/default/css/tabler-payments.min.css" rel="stylesheet" />
    <link href="https://auther.quarc.me/views/default/css/demo.min.css" rel="stylesheet" />

	<title> <?php echo $_smarty_tpl->tpl_vars['Title']->value;?>
 </title>
</head>

<body class="antialiased">
    <div class="page">
        <header class="navbar navbar-expand-md navbar-dark d-print-none">
            <div class="container-xl">
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="navbar-nav flex-row order-md-last">
                <div class="nav-item">
                    <?php if ($_smarty_tpl->tpl_vars['Me']->value==false){?>
                    <li class="nav-item active">
                        <a class="nav-link" href="/authorization">
                          <span class="nav-link-title">
                            Авторизация
                          </span>
                        </a>
                      </li>
                    <?php }?> 
    
                    <?php if ($_smarty_tpl->tpl_vars['Me']->value!=false){?>
                    <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="/authorization/logout/">
                          <span class="nav-link-title">
                            Выход
                          </span>
                        </a>
                      </li>
                      <li class="nav-item active">
                        <a class="nav-link" href="/profile">
                          <span class="nav-link-title">
                            <?php echo $_smarty_tpl->tpl_vars['Me']->value["login"];?>

                          </span>
                        </a>
                      </li>
                      </ul>
                    <?php }?>
                </div>
              </div>
              <div class="collapse navbar-collapse" id="navbar-menu">
                <div class="d-flex flex-column flex-md-row flex-fill align-items-stretch align-items-md-center">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                          <a class="nav-link" href="https://auther.quarc.me/">
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="5 12 3 12 12 3 21 12 19 12"></polyline><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7"></path><path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6"></path></svg>
                            </span>
                            <span class="nav-link-title">
                              Главная
                            </span>
                          </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/profile">
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><rect x="4" y="4" width="6" height="5" rx="2"></rect><rect x="4" y="13" width="6" height="7" rx="2"></rect><rect x="14" y="4" width="6" height="7" rx="2"></rect><rect x="14" y="15" width="6" height="5" rx="2"></rect></svg>
                            </span>
                            <span class="nav-link-title">
                              Мой профиль
                            </span>
                          </a>
                        </li>
                      <li class="nav-item active">
                        <a class="nav-link" href="/docs">
                          <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M14 3v4a1 1 0 0 0 1 1h4"></path><path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z"></path><line x1="9" y1="9" x2="10" y2="9"></line><line x1="9" y1="13" x2="15" y2="13"></line><line x1="9" y1="17" x2="15" y2="17"></line></svg>
                          </span>
                          <span class="nav-link-title">
                            Документация
                          </span>
                        </a>
                      </li>
                </ul>
                  
                </div>
              </div>
            </div>
          </header>
      <div class="content">
        <div class="container-xl">
          <!-- Page title -->

          <div class="row">
            <div class="d-none d-lg-block col-lg-3">
              <ul class="nav nav-vertical">
                <li class="nav-item">
                  <a href="#menu-base" class="nav-link" data-bs-toggle="collapse" aria-expanded="true">
                    <span class="nav-link-icon"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M8 9l3 3l-3 3"></path><line x1="13" y1="15" x2="16" y2="15"></line><rect x="4" y="4" width="16" height="16" rx="4"></rect></svg>
                    </span>
                    V1
                    <span class="nav-link-toggle"></span>
                  </a>
                  <ul class="nav nav-pills collapse show" id="menu-base">
                    <li class="nav-item">
                      <?php if ($_smarty_tpl->tpl_vars['status']->value==null){?>
                      <a href="/docs/" class="nav-link active">
                        Введение
                      </a>
                      <?php }?>
                      <?php if ($_smarty_tpl->tpl_vars['status']->value!=null){?>
                      <a href="/docs/" class="nav-link">
                        Введение
                      </a>
                      <?php }?>
                    </li>
                    <li class="nav-item">
                      <?php if ($_smarty_tpl->tpl_vars['status']->value==1){?>
                      <a href="/docs?status=1" class="nav-link active">
                        Авторизация
                      </a>
                      <?php }?>
                      <?php if ($_smarty_tpl->tpl_vars['status']->value!=1){?>
                      <a href="/docs?status=1" class="nav-link">
                        Авторизация
                      </a>
                      <?php }?>
                    </li>
                    <li class="nav-item">
                      <?php if ($_smarty_tpl->tpl_vars['status']->value==2){?>
                      <a href="/docs?status=2" class="nav-link active">
                        Логгирование
                      </a>
                      <?php }?>
                      <?php if ($_smarty_tpl->tpl_vars['status']->value!=2){?>
                      <a href="/docs?status=2" class="nav-link">
                        Логгирование
                      </a>
                      <?php }?>
                    </li>
                  </ul>
                </li>
               <li class="nav-item">
                  <a href="#menu-base" class="nav-link" data-bs-toggle="collapse" aria-expanded="true">
                    <span class="nav-link-icon"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M8 9l3 3l-3 3"></path><line x1="13" y1="15" x2="16" y2="15"></line><rect x="4" y="4" width="16" height="16" rx="4"></rect></svg>
                    </span>
                    V2 | C++ Static Library
                    <span class="nav-link-toggle"></span>
                  </a>
                  <ul class="nav nav-pills collapse show" id="menu-base">
                    <li class="nav-item">
                      <?php if ($_smarty_tpl->tpl_vars['status']->value==5){?>
                      <a href="/docs?status=5" class="nav-link active">
                        Библиотека AutherLibrary
                      </a>
                      <?php }?>
                      <?php if ($_smarty_tpl->tpl_vars['status']->value!=5){?>
                      <a href="/docs?status=5" class="nav-link">
                        Библиотека AutherLibrary
                      </a>
                      <?php }?>
                    </li>
                    <li class="nav-item">
                      <?php if ($_smarty_tpl->tpl_vars['status']->value==6){?>
                      <a href="/docs?status=6" class="nav-link active">
                        Инициализация
                      </a>
                      <?php }?>
                      <?php if ($_smarty_tpl->tpl_vars['status']->value!=6){?>
                      <a href="/docs?status=6" class="nav-link">
                        Инициализация
                      </a>
                      <?php }?>
                    </li>
                    <li class="nav-item">
                      <?php if ($_smarty_tpl->tpl_vars['status']->value==7){?>
                      <a href="/docs?status=7" class="nav-link active">
                        Доступные функции
                      </a>
                      <?php }?>
                      <?php if ($_smarty_tpl->tpl_vars['status']->value!=7){?>
                      <a href="/docs?status=7" class="nav-link">
                        Доступные функции
                      </a>
                      <?php }?>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
            <div class="col-lg-9">
                <?php if ($_smarty_tpl->tpl_vars['status']->value==null){?>
                <div class="card card-lg">
                  <div class="card-body">
                    <div class="markdown">
                      <div>
                        <div class="d-flex mb-3">
                          <h1 class="m-0">Доступ к API</h1>
                        </div>
                        <p>
                            Основной URL-адрес для вызова методов API (если не указано иное):<br> <code class="language-plaintext highlighter-rouge">https://auther.quarc.me/v1</code>
                        </p>
                      </div>
                      <h2 id="cursor-utilities">Для успешного вызова метода API требуется:</h2>
                      <ul>
                        <li>URL, составленный согласно требованиям к нужному запросу.</li>
                        <li>Корректные значения HTTP-заголовка <code class="language-plaintext highlighter-rouge">Content-Type</code> в запросе.
                            <br> API Auther поддерживает только один MIME-тип: <code class="language-plaintext highlighter-rouge">application/x-www-form-urlencoded</code>.
                             Любое другое значение приведет к ошибке формата данных.</li>
                      </ul>
                    </div>
                  </div>
                </div>
                <?php }?>
                <?php if ($_smarty_tpl->tpl_vars['status']->value==1){?>
                <div class="card card-lg">
                  <div class="card-body">
                    <div class="markdown">
                      <div>
                        <div class="d-flex mb-3">
                          <h1 class="m-0"><a href="#" class="btn btn-green" style="font-size: 10px;">POST-запрос</a> Авторизация и активация подписки</h1>
                        </div>
                        <p>
                            Основной URL-адрес для вызова методов API (если не указано иное):<br> <code class="language-plaintext highlighter-rouge">https://auther.quarc.me/v1</code>
                            <br>
                            <br>
                            Активация подписки начинается в момент первой авторизации.
                        </p>
                      </div>
                      <h2 id="cursor-utilities">Параметры запроса:</h2>
                      <ul>
                        <li>
                          <code class="language-plaintext highlighter-rouge">type</code>
                          <code class="language-plaintext highlighter-rouge" style="color: #c42020;">Обязателен</code> - строка. Тип действия, в данном случае должен быть auth.
                        </li>
                        <li>
                          <code class="language-plaintext highlighter-rouge">public_token</code> 
                          <code class="language-plaintext highlighter-rouge" style="color: #c42020;">Обязателен</code> - строка. Публичный токен. Можно получить в вашем профиле.
                        </li>
                        <li><code class="language-plaintext highlighter-rouge">license</code>
                          <code class="language-plaintext highlighter-rouge" style="color: #c42020;">Обязателен</code>  - строка. Сгенерировать можно в вашем профиле.
                          </li>
                        <li><code class="language-plaintext highlighter-rouge">hwid</code>
                          <code class="language-plaintext highlighter-rouge" style="color: #c42020;">Обязателен</code>  - строка. Пользовательский идентификатор.
                          </li>
                      </ul>
                      <h2 id="cursor-utilities">После запроса я не получаю ответа:</h2>
                      <ul>
                        <li>
                           Скорее всего вы указали не верный <code class="language-plaintext highlighter-rouge">public_token</code>, либо пропустили один из параметров запроса.
                        </li>
                      </ul>

                      <h2 id="cursor-utilities">Пример запроса:</h2>
                      <div class="example no_toc_section">
                        <div class="example-content">
                          Content-Type: application/x-www-form-urlencoded
                          <br>
                          type=auth&public_token=WCMsnUfT4FBS&license=demo&hwid=demo
                        </div>
                      </div>

                      <div class="hr-text hr-text-center">
                        <span>Возможные ответы</span>
                      </div>

                      <h2 id="cursor-utilities">Несуществующий ключ:</h2>
                      <div class="example no_toc_section">
                        <div class="example-content">
                          
                          {
                            <br>
                            "Status":"WrongKey"
                            <br>
                          }
                          
                        </div>
                      </div>
                      <h2 id="cursor-utilities">Успешная активация ключа:</h2>
                      <div class="example no_toc_section">
                        <div class="example-content">
                          
                          {
                            <br>
                            "Status":"Activated", 
                            <br>
                            "HWID":"demo", 
                            <br>
                            "License":"demo", 
                            <br>
                            "LicenseTime":"24", 
                            <br>
                            "SubStartTime":"161253029", 
                            <br>
                            "SubEndTime":"161339429"
                            <br>
                          }
                          
                        </div>
                      </div>
                      <h2 id="cursor-utilities">Успешная авторизация:</h2>
                      <div class="example no_toc_section">
                        <div class="example-content">
                          
                          {
                            <br>
                            "Status":"Authorized", 
                            <br>
                            "HWID":"demo", 
                            <br>
                            "License":"demo", 
                            <br>
                            "LicenseTime":"24", 
                            <br>
                            "SubStartTime":"161253029", 
                            <br>
                            "SubEndTime":"161339429"
                            <br>
                          }
                          
                        </div>
                      </div>
                      <h2 id="cursor-utilities">Окончившаяся подписка:</h2>
                      <div class="example no_toc_section">
                        <div class="example-content">
                          
                          {
                            <br>
                            "Status":"SubEnded",
                            <br>
                            "License":"demo", 
                            <br>
                            "LicenseTime":"24", 
                            <br>
                            "SubStartTime":"161253029", 
                            <br>
                            "SubEndTime":"161339429"
                            <br>
                          }
                          
                        </div>
                      </div>
                      <h2 id="cursor-utilities">Сменившийся HWID:</h2>
                      <div class="example no_toc_section">
                        <div class="example-content">
                          
                          {
                            <br>
                            "Status":"WrongHWID", 
                            <br>
                            "License":"demo"
                            <br>
                          }
                          
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <?php }?>
                <?php if ($_smarty_tpl->tpl_vars['status']->value==2){?>
                <div class="card card-lg">
                  <div class="card-body">
                    <div class="markdown">
                      <div>
                        <div class="d-flex mb-3">
                          <h1 class="m-0"><a href="#" class="btn btn-green" style="font-size: 10px;">POST</a> Создание лога</h1>
                        </div>
                        <p>
                            Основной URL-адрес для вызова методов API (если не указано иное):<br> <code class="language-plaintext highlighter-rouge">https://auther.quarc.me/v1</code>
                        </p>
                      </div>
                      <h2 id="cursor-utilities">Параметры запроса:</h2>
                      <ul>
                        <li>
                          <code class="language-plaintext highlighter-rouge">type</code>
                          <code class="language-plaintext highlighter-rouge" style="color: #c42020;">Обязателен</code> - строка. Тип действия, в данном случае должен быть log.
                        </li>
                        <li>
                          <code class="language-plaintext highlighter-rouge">private_token</code> 
                          <code class="language-plaintext highlighter-rouge" style="color: #c42020;">Обязателен</code> - строка. Приватный токен. Можно получить в вашем профиле.
                        </li>
                        <li><code class="language-plaintext highlighter-rouge">license</code>
                          <code class="language-plaintext highlighter-rouge" style="color: #c42020;">Обязателен</code>  - строка. Ключ активации к которому будет привязан лог.
                        </li>
                        <li>
                          <code class="language-plaintext highlighter-rouge">message</code>
                          <code class="language-plaintext highlighter-rouge" style="color: #c42020;">Обязателен</code>  - строка. Сообщение отправляемое в базу.
                        </li>
                        <li>
                          <code class="language-plaintext highlighter-rouge">tag</code> - строка. Префикс лога, только для удобства при просмотре в панеле.
                        </li>
                      </ul>
                      <h2 id="cursor-utilities">После запроса я не получаю ответа:</h2>
                      <ul>
                        <li>
                           Скорее всего вы указали не верный <code class="language-plaintext highlighter-rouge">private_token</code>, либо пропустили один из параметров запроса.
                        </li>
                      </ul>
                      <h2 id="cursor-utilities">Пример запроса:</h2>
                      <div class="example no_toc_section">
                        <div class="example-content">
                          Content-Type: application/x-www-form-urlencoded
                          <br>
                          type=log&private_token=WCMsnUfT4FBS&license=demo&message=demo&tag=month
                        </div>
                      </div>

                      <div class="hr-text hr-text-center">
                        <span>Возможные ответы</span>
                      </div>

                      <h2 id="cursor-utilities">Несуществующий ключ:</h2>
                      <div class="example no_toc_section">
                        <div class="example-content">
                          
                          {
                            <br>
                            "Status":"WrongKey"
                            <br>
                          }
                          
                        </div>
                      </div>
                      <h2 id="cursor-utilities">Успешное создание лога:</h2>
                      <div class="example no_toc_section">
                        <div class="example-content">
                          
                          {
                            <br>
                            "Status":"Success"
                            <br>
                          }
                          
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <?php }?>
                <?php if ($_smarty_tpl->tpl_vars['status']->value==3){?>
                <div class="card card-lg">
                  <div class="card-body">
                    <div class="markdown">
                      <div>
                        <div class="d-flex mb-3">
                          <h1 class="m-0"><a href="#" class="btn btn-green" style="font-size: 10px;">POST</a> Ручной сброс HWID</h1>
                        </div>
                        <p>
                            Основной URL-адрес для вызова методов API (если не указано иное):<br> <code class="language-plaintext highlighter-rouge">https://auther.quarc.me/v1</code>

                            <br>
                            <br>

                            Позволяет вашим пользователям, либо же администраторам сбрасывать HWID.
                        </p>
                      </div>
                      <h2 id="cursor-utilities">Параметры запроса:</h2>
                      <ul>
                        <li>
                          <code class="language-plaintext highlighter-rouge">type</code>
                          <code class="language-plaintext highlighter-rouge" style="color: #c42020;">Обязателен</code> - строка. Тип действия, в данном случае должен быть hwid_reset.
                        </li>
                        <li>
                          <code class="language-plaintext highlighter-rouge">private_token</code> 
                          <code class="language-plaintext highlighter-rouge" style="color: #c42020;">Обязателен</code> - строка. Приватный токен. Можно получить в вашем профиле.
                        </li>
                        <li><code class="language-plaintext highlighter-rouge">license</code>
                          <code class="language-plaintext highlighter-rouge" style="color: #c42020;">Обязателен</code>  - строка. Ключ активации у которого произойдет сброс HWID.
                        </li>
                      </ul>
                      <h2 id="cursor-utilities">После запроса я не получаю ответа:</h2>
                      <ul>
                        <li>
                           Скорее всего вы указали не верный <code class="language-plaintext highlighter-rouge">private_token</code>, либо пропустили один из параметров запроса.
                        </li>
                      </ul>
                      <h2 id="cursor-utilities">Пример запроса:</h2>
                      <div class="example no_toc_section">
                        <div class="example-content">
                          Content-Type: application/x-www-form-urlencoded
                          <br>
                          type=hwid_reset&private_token=WCMsnUfT4FBS&license=demo
                        </div>
                      </div>

                      <div class="hr-text hr-text-center">
                        <span>Возможные ответы</span>
                      </div>

                      <h2 id="cursor-utilities">Несуществующий ключ:</h2>
                      <div class="example no_toc_section">
                        <div class="example-content">
                          
                          {
                            <br>
                            "Status":"WrongKey"
                            <br>
                          }
                          
                        </div>
                      </div>
                      <h2 id="cursor-utilities">Успешный сброс HWID:</h2>
                      <div class="example no_toc_section">
                        <div class="example-content">
                          
                          {
                            <br>
                            "Status":"Success"
                            <br>
                          }
                          
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <?php }?>
               <?php if ($_smarty_tpl->tpl_vars['status']->value==5){?>
                <div class="card card-lg">
                  <div class="card-body">
                    <div class="markdown">
                      <div>
                        <div class="d-flex mb-3">
                          <h1 class="m-0">Отличия API версии V1 от версии V2</h1>
                        </div>
                        <p>
                          <ul>
                            <li>
                              Ответы от сервера шифруются при помощи RSA, для их расшифровки требуется использование данной библиотеки.
                              <br>
                              <br>
                              Помог с реализацией RSA - 
                              <a class="link-secondary" href="https://t.me/Sayner1399"> <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 10l-4 4l6 6l4 -16l-18 7l4 2l2 6l3 -4" /></svg> Sayner1399</a>
                            </li>
                          </ul>
                        </p>
                      </div>
                      <h2 id="cursor-utilities">Скачать библиотеку</h2>
                      <ul>
                        <li>
                          <code class="language-plaintext highlighter-rouge">Release x86</code>
                          - <a href="https://auther.quarc.me/builds/Release x86.zip">Скачать</a>
                        </li>
                        <li>
                          <code class="language-plaintext highlighter-rouge">Release x64</code> 
                          - <a href="https://auther.quarc.me/builds/Release x64.zip">Скачать</a>
                        </li>
                        <li><code class="language-plaintext highlighter-rouge">Debug x86</code>
                          - <a href="https://auther.quarc.me/builds/Debug x86.zip">Скачать</a>
                          </li>
                        <li><code class="language-plaintext highlighter-rouge">Debug x64</code>
                          - <a href="https://auther.quarc.me/builds/Debug x64.zip">Скачать</a>
                          </li>
                        <li><code class="language-plaintext highlighter-rouge">LibCurl</code>
                          - <a href="https://auther.quarc.me/builds/LibCurl.rar">Скачать</a>
                        </li>
                      </ul>
                      <h2 id="cursor-utilities">Установка и использование:</h2>
                      <ul>
                        1. Добавить файлы из архива в ваш проект.
                        <br>
                        2. Указать путь до библиотеки в параметрах линкера. (Картинка ниже)
                        <br>
                        3. Указать путь до библиотек LibCurl`а в параметрах линкера.(Картинка ниже)
                        <br>А так же добавить путь до файлов LibCurl в папке include в параметрах VC++ Directories.
                        <br>
                        4. Указать CURL_STATICLIB; в параметрах препроцессора.
                        <img class="d-block w-100" alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAxkAAAIoCAYAAAAFsiZDAAAgAElEQVR4Xuy9C5Qd1Xnv+T/CvAyOBX7IOM4NILWwWrIFxsah5YmRGRTT9iQtpy0/kolkrbiFNBg1sfoGNPIIregKT6SYFmYhq+EKKYsxWO6g9gzuJlKIOplIdmwDHls00N0gxYmMX1jkQoycBJ9Ze++qOrt27XqeOl11zvnXWr2kPmc/vv3bu6r3v77vq6pcccUVVRhHtRr4CLbPzHr8nQRIgARIgARIgARIgARIoDUJVCqVwMDCPqvoIkMXEnGiIu771kTLUZEACZAACZAACZAACZBAexCwCQh95Ob3+u+eyHBFQ1KhQZHRHouLoyQBEiABEiABEiABEmhPAlEiwycoNA+H+7kUGa5geOMb39ieBDlqEiABEiABEiABEiABEiCBzAR++tOfwhMYlQo8kSGExpve9CYcOnQoc+OsSAIkQAIkQAIkQAIkQAIk0F4ErrvuOvzkJz+RIsMTGpdffrnM8qbIaK/FwNGSAAmQAAmQAAmQAAmQQB4EhMj48Y9/7IkMKTaEyBACQ/y8+c1vpicjD9JsgwRIgARIgARIgARIgATahIAQGT/60Y8oMtpkvjlMEiABEiABEiABEiABEmg4ASEynn/+ecyaNasmNOjJaDh3dkACJEACJEACJEACJEACLUvAFRkiTMoTGhQZLTvfHBgJkAAJkAAJkAAJkAAJNJyAEBk//OEPPYEhhcbixYu9nIw5c+YwJ6Ph08AOSIAESIAESIAESIAESKB1CLgiw+fJoMhonQnmSEiABEiABEiABEiABEhgpgkIkXHy5EnpyfDCpSgyZnoa2B8JkAAJkAAJkAAJkAAJtA4BiozWmUuOhARIgARIgARIgARIYAYJvPTSS3j44Ych/hXHW9/6VixbtgxnnXXWDFqRrKuhoSF85CMfwRvf+EZrhZ/97Gd46KGH0NfXl6zBmFK5i4zjjw7hEK5D37WXZDTwOB4degwXfrQXV1yQsQlrtVN4Yvir+PbPnS8vfA8+2nsFLkDS/pKWi7ZZ8Hnswo+iVx/c8Ucx9Nylkpnk96xq48L3GOWMpu2shZ2H4DQhWsF7PJbiu+dwad+18M+OWQeYe10fMk9h3dOWlnXUmOs2ZgYaaHb7ZwARuyABEiABEiCBEhIQic3iMa3veMc7ZJLzwYMHcfXVV8vfy3YIETHyta+h5/d+LyA0or7LOo58RcapJzD86M9xAU7hwmuTigRzQ5l2g5lg6MKur34bF+gb51NP4IkXr8AVlyTtL2m5GHs0QeGWFGLhuUv7cO1s1ybxTUx/oaz99U49MYyvPjtXE1RhIqMRwi7B3FiLpGUdNeasNmStl9b24Fz75yyrHaxHAiRAAiRAAiQw0wT+6q/+ChdffDGuvPLKme46UX82MdEIgSGMyVVkiM3Ro7gW1+JR+a/vbn3o0BstMpQH4+dXht2ZT7opTFouZo6l4Pk5rvS8CWHeBWH3o0CIWAtnHcUzypPROiIjVqAlOg2zFsqyThp9DmQdC+uRAAmQAAmQAAkkJfD9738f3/jGN/D7v//7eMMb3pC02oyX00WF6DzMu1GvYTmKDG1TDOHREPtjEY4UvFNb2wReiZ9/VQvtmSvCrKDCpa6bi2cPfRsiuskXNuR4JVTU01xcJzfrapOGucCzz17gfOagCWzqTWT6Bi9ugx5hV+KZMESPxbOhmgoTBOK7LKyFZymNyFB2PjvXCdkSdj52oeMRgS+sC3LeRACWw0+bOxF29a4Xh/FVJ06tNpfBsoHv3DAv65zrwOPnzbc2fO3poWFRNgnsyiMWvvbcWDzHtrnvwXtOfdsvcA2OtbnWRZ5/PHoIXY21354L3/MeXPDtZ2thhlZb/SGDxYbEJT5hWJAESIAESIAESk9gcnIS4+PjuOaaazB//vzS2+sKDWGoLXwqjwHkJzJk+I4rLMy78PGbwFoOhhOf7uZMiE3ZIfjEhFf2+KMYfvFd6L3iRZmHcMqWw+Czy4Ysjcg4hGddu+Qm7lnMzZA74nohhKfHC5UyUlisuRuu+SlYJw+X0vM4dPEmwqsuxXPWXA5TQNrm7tmaSAzMZRjPiDnx5lxP2IkLEdPXhrIRbuicbx4N+wPfaUIgdO0Za90Qkfb5ThruZXKpjUPO87fh5N8EbZDnyezHvdyfPC4ebIMESIAESIAESEAR2Lt3rwyRKmMuhm2Omkpk6Btnea9dbHp+fqX/DrcvAdndsMWFimjfCw+JdyfZvVuseT9sG/68PRlaH9YNY+xdd+cOtBRkF+NEICTK8CBYVkY8a5tgcAVBypwMKQyeDSaCO58r89zk8hRzKb0q/hCtGs8kc66rMkcceKxckWSKIPfuvx6uprwyMifGkp+j58skW3s2Bi7z43h0+EW8y/PwuQZH2S8cRGoOfKyjvIVh58m7XpTnD2IeKMA/GCRAAiRAAiRAAukIiCc3ffjDH5ZPlyr70WThUuYmycXrD2fyeyuyigz/BlH1FNyw1iY4TU5GGo9LXLtRS8zx9Fw5F88+poeVRedh1Maqi4g41rodacKlnHo2keETbrrN9YgMnacpMmxzbo4rLKfEsMkiOsNFhmbTbDOXRhcI4aFOolR8rlLE+g1jHSsywpkpr8fPC36CWNkvwbSPBEiABEiABJITEE+Wet3rXid/ynw0X+K3Nc5c3zRa8hAOnbKHdgQEQzBEJBgWFbO5DdkoB58uFWenFnYT6yGJXmLuRs+XbxKan6G1Fcs6SnClFRlueSNcSrchKqQozVz6eCaZ84wiQ9pkhku5G3L1nbe+AjbZQvLihJXruYp66lrEnEWyjgqXCgkfdLCZ3rAyXxBpGwmQAAmQAAmUncBjjz2Giy66qNSejKZ8hG1Y/oAvZEoP+Zg7F3OfPeUlqXqJrXritzW0yky+FbnftnApy6bNSPZF2HsyQu1UbaoEYif1t553SVhyOlzhoZ9I5rsy4lk7ifPWXJEokeH3jlz4nusw99lDXuK3P7dDSyC+cC7meo8sjttwm+IhjKfN++AmXLtzboZLJfRkKNeCFnZnvkckYo7NNWRde1pSvJcQ73wW+v6YeE+czJv3sfaHUUUnfjvMLn1OC7vSQ8rKfummfSRAAiRAAiRQbgIiXEokfIvE77IeTf8yvrKCpV1lIxC1sS7K1sbZFJbgn9tI6/Ss5WYHGyIBEiABEiABEiCBvN+TQaIkkJxA4zb0yW0wSzbIptgnnGW32K0pvYGn3LfY198eWyABEiABEiABEiCBegjk9wjbeqxg3TYk0KANfV0k87bJDSvTQ7LqMlCr7H/nRe2dMXm1z3ZIgARIgARIgARIIDsBiozs7FiTBEiABEiABEiABEiABEjAQoAig8uCBEiABEiABEiABEiABEggVwIUGbniZGMkQAIkQAIkQAIkQAIkQAIUGVwDJEACJEACJEACJEACJEACuRKgyMgVJxsjARIgARIgARIgARIgARKIFBm48O3o/b0OfK5/K0mRAAmQAAmQAAmQAAmQAAmQQCICkSLjtf/TMnzsbT9D/y33JWqMhUiABEiABEiABEiABEiABEggOlwKZ+Odv/0u3P/FL5EUCZAACZAACZAACZAACZAACSQiEB0udc7Z+I0LX4//68HhRI2xEAmQAAmQAAmQAAmQAAmQAAn09vbi5MmTmDVrlvypVCqoLF68uFqtVnDRsqW47jfOxR+v/K8kRQIkQAIkQAIkQAIkQAIkQAKJCESIjCqq1SrmzJmD4WF6MhLRZCESIAESIAESIAESIAESIAFYRcYjj/x59WffOYj/8ys/psjgIiEBEiABEiABEiABEiABEkhFgJ6MVLhYmARIgARIgARIgARIgARIII4ARUYcIX5PAiRAAiRAAiRAAiRAAiSQigBFRipcLEwCJEACJEACJEACJEACJBBHgCIjjhC/JwESIAESIAESIAESIAESSEWAIiMVLhYmARIgARIgARIgARIgARKII0CREUeI35MACZAACZAACZAACZAACaQiQJGRChcLkwAJkAAJkAAJkAAJkAAJxBGgyIgjxO9JgARIgARIgARIoIQEHn300RJaRZNalcC1116bamgUGalwlaMwLyrlmAda0boE0l5IW5dEcGS8/rTTbHOsRRBIc/0R5+O73/3uIsxkn21G4Dvf+Q7SrE2BhyKjCRcJLypNOGk0uWkIZLmQNs3gcjCU158cILIJEgghkPb6w/ORS2mmCKRdmxQZMzUzOffDi0rOQNkcCWgEslxI2wkgrz/tNNsc60wTSHv94fk40zPUvv2lXZsUGU26VnhRadKJo9lNQSDLhbQpBpaTkbz+5ASSzZCAhUDa6w/PRy6jmSKQdm1SZMzUzOTcDy8qOQNlcyRAT0biNcDrT2JULEgCqQmk3cjxfEyNmBUyEki7NikyMoIuuhovKkXPAPtvZQJZLqStzMMcG68/7TTbHOtME0h7/eH5ONMz1L79pV2bDRYZz2HXsnfh1m85E3LV7Xj84FpcWs/8HOrH7I/uBURbXwJueNcBLH/8INbW1WgGg57bhWVF9Q2AF5UMc8YqJJCQQLoL6SH0z/4o9nptX4XbvWuS+G47Lkt7jdKvc/VeMxOOOU0xXn/S0GJZEkhHIN31J+t+4AT2fOT92PKYY9uVm/F3D63GxelM9Zc+fCt+c9WXAdHWF4A/ef/D+PDfPYTVdTWawaATe/CRXPs+jFt/cxW+/Mm9+KfblwYMOrHnI3j/FmBzEWPNgKeeKmnXZuNEhtyE34rOr76IweucIT23C7ueXYu17u+pR6r+mENvM3UbWStk3Cxk7S6mXvCPvHMSaPU+ufefYDkftBKizhfR0QYnRoOmgc22KIF0F1L/teG5XcvwrgPLnRsqSa4bZpkir3PJJtS8/hy+9TdxcJl+vbFcW8QG5OAy/NOa4wk3AP5NkH49E/2JvYw4rtz8d3hoxncxyTixFAlkIZDu+pNBZMhN+BZcpu8RTuzBnuOrsTq4h044BLUHQey+I2FzqYo1ei+j2n/mSuDDXzBFk7v3upIiI2TOrI+w/dBHe6ovP/Mcfl6tYs6cORgeHk4x5cqD8cyAJjBS1A4vmuQPdi4dWRopsu+gOXaRoQkGeUdBnO+3I/ya0egTs1FzwXZJoLEE0v2Rt4kE13uR5LoRVb+x48zaeuD64woI966Gs4mBJgDE3b4/wRdSCILDOHx4KZaKC5hsbwqfEdcz32aI17Csc8h65SWQ7vqTVmQo8T71mbibkGn5FHkuNrpv1T4+CTzTYVzD5LUP+OSXn2mLG7Zp16ZYRVaRsf2WP6o+cui7+Mm/ZxAZ0ovxDAZeHESo08LxdLiRVKs874TzB/f2Ttx6qwpAuOr2x3Fw7bO+kITaZ1oogtbmVbffjs5bDzhhCvGbAIgN+d5OfPXFQaB/NkREljxWfRXqIy0cwvvM3req5gqssPFcCoiQiO2XZQohixUZSHLSJSmT9kLD8iRQPgLf+9738M53vtNqmO27dBfS+OuLGy51KPbasgqr9u71Qq/Ude5SIOZ6Wbt+fQhfF+FZX12OAx+9FeL6Kq5FN00vw7ucuFWvzTyvP0IE/AnwBSfcQgiK3fgwnpm6BA9J4SE2NrJAxtAJca06iGWBmyb1tlu+tUqLWo9AY68/KUWGLtjDUDs3CdxIqpoX0dkzbL4MW7YoV6LyJB5X4UROe7XPtBufWptXbt6My7Y87GzKzX2I/nttc//lL18mb5pC82JChi+Jj2p91z6z9y1MjB+PGd/l2vQZTL1fvw651x/xea0/3dOq7BHXwDB2qi97HfcGyxaIufBz838nFJC6qRxkltk5ZVkf6f42qgbyfxmf+IN4A/Cl0FhiIxzAl9/gxDfLjfx1aiMuI6SEYIn7Y14LpZIhC7fCiY2Orzfh/jH3QdXrxbfhhXElHU+ef+RNUSHU9Rc7ajGWvouGfzF64VLWMmGLPySUIaSN1vuzwRE1C4GXX34ZW7ZswXXXXYdly5b5zD548CAOHTqEzZs34/zzz/e+S3chzRIulfTaIkyKv17Wrl/O9dPNf3NyO3zCwr2e5nr90Tf7+h9e9w+yLhKCm4iOwKbF+CNvekq8mQoTH82yOmlnqxNo/PUng8jQbggE+RthT778BiM3wRcxEScWaqFU/hyG+HrPWEMiLdcRL/Tb/E4L40o8Hp1Mrb1Ldmuhod7NlUuw2xp6HrTDy+sIjTYJtz2S2+Fb8ZHjazzBZ2dW/9mW7m9jI0VGlCfD4ukQd/i+/iFx9z9uM68nUWplYQqbpH/ELeEMbtKl5OMmcUbYJfo2xptsPNknPDYnw5egZJzEvsXoqu+wMvofe63McSe+2pf0kaSN7GNmTRLISsD2hz5MYIg+0l1IzcTvVc5NEVcgaNestNcW8UCLzNdLS/+BGzXZiNoSv2t5GYdx60eOY81Dq3H81o/g+JqHsNp3vUj+h1f9UX1M3Hq0JlyKPr/YwZyMbLPIWjNFoLHXnwwiww09tAGweDp857ZvM51wow+/p9O7qy9FQZzIMPJG3eRyabubBxHRhujbGG+y8dhFxmptLMe9XLTg3kcmwCe1UWyzbOOK4ibHpTwc3uF5dhqXa5vub2OEyLjlUx+sPvrYD3G6ETkZmf9oxmz0fd6TjCLDZ5vILZGNYu2lzSAynIVlnlSG61NOu7kYQxfs0vDFrx6nUIuxDu0nT2fdTP1ZYD+tRkD/Qy+33xYPhjvmdBfSqLwL40aIdzMi4bWliUSG/CMpEruXHVT/3r4Ubh7GF/AnWj5Gwo2J7/6GyDF7RkusVJ7Uhz9MgdFq52mrjqdx15+UIkOGLkbkZJRZZPhs072nMygyLnb6/cyH8fAX3RBRrX/f/iuLjVqdWJHh5Kn5ThqTRb5nVLq/jREi4w/W9VX/7R+/iWez5GTIv+DqUbO13AR1R049Xcrm/ndzODJ6MqQICAuXMhLRpW0T9lAqPYQgEPYU4kUx+vbfeYwYz7ONy8nwJVmGxmCGnRjaogw9qVUZ906jjHG8JHjHIN/lzdZIoD4C7h960YoZIqW3nO5CmlBk6Od74muLvJj6n6rnuxESlzQ+U9cfJz74T4DPfPhhHLzkIfVkO3H92A18+JmHtXyMDCLDiVlWT7BiHkZ9ZwFrF0WgMdeftCKjdtfc9wRK74EKtnApdzObxuuQNOzHED3yjr57Q8HiIXDDwANhT/rd+7hwqSTj0VeJ3VNRe7KdEeWR1kbh6Q2tExVmtgrBsKikc5RNjKT72xghMhYvXlytVqsQP+mfLuVMjpGsKN9t4eZp+L6Leq58Uo9ETdiI3v2J3/7vsEokV06EJIVr7/a4ahVWYQKXSU+G0E1OQnhs4nfC8TRQZATdkXGLUV1YAgtWz+0IefZ0TdCo5K9GxQIW9YeB/bYWAfGHXhx6DoY5wnQX0oQi49KM1xZhXKbrpStQQm6O5Hr9kbccnOfu649yVNeVL3tJiaJcQpFx/DAOL13qPB0vLlSztdYoR9O6BPK//mQQGeoOoT/cRn9Phu8783yO2syHfecPBwokMOuhQp/8pPakJnMjrOWCXvlJfBLPoMN5mISXOG0LGco0ngiRIa91u3HJQ+7TO3U7w2yM2vyHj0sPo4pO/LZEqEhvcNj1thVERpHXiSRPuCrSvjr7jn+6lONlePjDKvnbvKDEnojugr2k9sIe/aQWytuLOXQTyS0XrpBY6jqHz+ok0FAC6URGQ00pZeNhL+OTnk33muNYLv/4Q8+pSCgyjBBO966rl6ehkeG7Mkq5TGhURgJprz9N93LMJE+4ysiupauVgFvatSnmI/+nS5VglqXXYSKHN4yXYCw2E5ruolJSjjSLBGwEslxI24kkrz/tNNsc60wTSHv9abbzUd54eCaHN4zP9MQU3F8ZuKVdmy0kMrRQBLkQ9Ce8FLwyGtB9s11UGoCATZJAwwhkuZA2zJgSNszrTwknhSa1DIG015/yn4/+R97X3unQMlPWoIGUj1vatdlCIqNBc1zSZst/USkpOJpFAgkIZLmQJmi2ZYrw+tMyU8mBlJBA2usPz8cSTmKLmpR2bVJkNOlC4EWlSSeOZjcFgSwX0qYYWE5G8vqTE0g2QwIWAmmvPzwfuYxmikDatUmRMVMzk3M/vKjkDJTNkYBGIMuFtJ0A8vrTTrPNsc40gbTXH56PMz1D7dtf2rUZKjK23b+3+ot7v4CvvVDHI2zbdx4aPnJeVBqOmB20MYEsF9J2wsXrTzvNNsc60wTSXn/E+ciDBGaKwLXXXpuqK+vTpe6/95bqzjtHM77xO1X/LJyBAC8qGaCxCgmkIJD2Qpqi6aYvyutP008hB1ByArz+lHyCaF5iAlaRce8tV1XvHD1d38v4EpvAgiRAAiRAAiRAAiRAAiRAAq1EwCoyPnvV4uqh03W+8buVKHEsJEACJEACJEACJEACJEACiQlYRcZVixdXT1cpMhJTZEESIAESIAESIAESIAESIAGPQEu+8ZvzSwIkQAIkQAIkQAIkQAIkUBwBiozi2LNnEiABEiABEiABEiABEmhJAhQZLTmtHBQJkAAJkAAJkAAJkAAJFEeAIqM49uyZBEiABEiABEiABEiABFqSAEVGS04rB0UCJEACJEACJEACJEACxRGgyCiOPXsmARIgARIgARIgARIggZYkQJHRktPKQZEACZAACZAACZAACZBAcQSsImPb/Xurv7j3C/jaC1XMmTMHw8PDxVnInkmABEiABEiABEiABEiABJqKgFVk3H/vLdWdd45CvJAvrci4c9fepgJAY0kgC4Gb1q7KUo11SIAESIAESIAESKAtCFhFxr23XFW9c/Q0qhlFxmdv+nRbwOMg25PAX9x5Dygy2nPuOWoSIAESIAESIIFkBKwi47NXLa4eOl2lyEjGkKWahMBrX/ta/Ou//mtd1p555plIIzJGRkbq6o+VSYAESIAESIAESKAsBHp6ehKbYhUZVy1eXBWhUvRkJObIgk1AoCiR0fuxP2wCOjSRBEiABEiABEiABMIJDH/lftQtMhYvXlwVAoMig0utlQi0ksg4f8tUK00Nx0ICpSDw8uYOnHfOGaWwhUaQAAmQQJ4EHnroobqbe+mllygy6qbIBlqSAEVGS04rB0UCuRGgyMgNJRsiARIoGQEhMt797ndntuo73/kO2lBknMCe3m5sf7IqwVUWDmB0eDUuzowRwPhGLFh7QLW1A9jQPYru0WGsrqvRDAad2IPeXPsex8bOdThQdVhVFmJDEeOyoch9rMFOKDIyrEFWIYE2IkCR0UaTzaGSQJsRoMhIO+FyY7oD8++ewLZrnMon9mDPidVY7f6etk2ojTj0NlO3kbWC6PsuzGvYxt/f/ok9vege7a5flGUabqPHSpGRaVpYiQTamABFRhtPPodOAi1OgCIDwIIFC/DUU08lmGrlwZi+URMYCWrFF5n5zW/Npkb3bbbf6P6iaM9833GejP7+fgwODkYukSxPl2pE4ndUTkbfH74du/FDVO7/HxFj+TWM3v4GTO48jv4fmcW07/AmTK0/H1+3lXtLxHfxJ1pMiTD7xOdvxfVa7enDx9Fx8Jd191hfA1E862i5oYzrsKtFqzZCZEzvXIKO/qPoG61it75w62TYqHbtZk1j55IO9GMQU0fWY55ZaHonlnT04yhQ3zjddvpGUc0Tlm1QY2tQ6R5C1+AUjqwPjKhWI0u5+dtrbev/j+oHDmMBEX0Yre5W1znZ/zEMTh1BrfoY1lS6MaRzSjgHUevG9x1i+CTlkmWd+9qeUmM12omdtyz9ZqzT0HOxDs5jayroHqqtpbYXGUJgiCORyJBejGncOLENoU4Lx9PxpBMetHzXU47Hw9ngbpiP7dsPyD4XDoxhePUJXzhR7TPNu6C1uXBgAPN3jDqeh6gNvPoOPcDIyHzcPbEN2NiJtQecsKXlu6A+0kKZvM/sfQub48djxnels/GaOH53d2N03Q4IvoqV059Wr1JZLsd7jfQQKQYHDjzpO5UrMWOtteEPjauNP9mVIUpkCIHhHlFCo/QiQ2xKP3kWpnAWJr9sExDuKBOKDJ8AadBG2jp9USJDF0eO6HgyTlQlWyPZS80km+xWsmY0AYqMcD5qIwVjs6vKu5ss8f9Umz9nA+UJsDYWGZLh/hWYOvIhfH1JB/avEOIHUtyp/9eEkOK9qCZEUsxBZpFhzlUdm9/Y65BNZHTVBK633mZCjMYaW1v/ed9IkF3XxdkvRttaZLgCI5XI2ADsCM2/MMKefDH/6ruRnrsxIeKsxjdCRUjVNsO1kCV9Y+5vU4YbiZwNGd4Ut4Ffh8kNo7WNuLdwzfb1cKnwvpF4PPoZEhUupcZWszEBv84NKtQqYIs2hvGN6H2uzxNw/vajxmpp49IhdB5cpuYswxEmMnSBESc0yi4yupZdgn34IVbirfLf8Dv8rSIyAMi7/Wdh+60nA3e7MiyTjFUoMjKCK1U1ioyo6VAblmOBO/+ul6MPfRjCUJi3w9K0utOqeT9aRWToHouEm0SbyNiHlQExAdfjsUj39iSfg8Qiw/C6BeaqkWdujMjwGBztsoreRppma7uhnow6B6N7M15p18RvXWCkEhlRngyLp2N8YycOLhPhVXGCIGTziz3o9QmbNALByLVwksvFeCteAnaEXaJvY7zJxmOKDD3x2/UyiDJG36n4CZ3msL1Y5cm43iM5PpunwuxP/12O1dJG33Pyc1jFWvyZaBMZpgcjzqNRbpFxNgb/5K2A8GCIMKdPAiu/8FMZwiAPuRl/gwx1mD78AqaWnl8Llwr9zt08v4D567UwJek5gD/kSmtD3oD5ytPo/q74n9PG4X/H+qWvk6boIU4yvGuhY6PnkUjqyRD1xLgvwfy/dfrz2fES1kjx4bT3lZfxoY+5DLQwq6g6IXYn5QkYNoS154xj/ZsUC8XP4GC1U43fXy/+fGCJIAGryHA2PG5p7069Fp4iv7PdadW6CNytrzWoQpDM9i5Vq1UAACAASURBVPSQGaes7jFwqydut6sLXUePOteDLvT1AUNDztVBvyMcNl55U9UffqFOZhUqhcEpqE2x5u0wNtj6ZqxnRAkM7xA2DEyqsCvdVo2r25d3TXO/i2NnfC/nMCKkyRo2pIApfrpN7gD0sdrattUPCwuS7c/H9ko3YIbZabw970bUHBheDnPdhK4pLVxq00RHcK56RvzhZmHrxv3cNqdh51CsyLB4D+LaCpu/mHoIWYuZzsUoFtq55K7vwDoV4jX0uuN4LWoTrEIONQ/U77zif7rU9773Pbzzne+0/imwfdeUT5cyBYYYbaJwKcTkZKTaJCcUC3mJDJ9tYhxSuUR7Q3ITGWGJ5fWIDG0upMiwhbHF5YNo31vGqp8FwoN0/fYntXCxZNulKJGhh0i5QsMWNlVqkSFDpVxhoQkOGfKkworgbPyFx+PIUmCnzLWI+84NTzI3/vrv/jbUBtzN5TBCmi7/dVQ/Bmfzr8+d2Z4tZ8QmPnSRYXx/+a9j6s0/Q8fBs1Uux09fwBIhvAL2aX2ZdVzh47M7KTMAidpTY/jQMTO/JIKJ2+5P3ojqopdicnCSnSPtXiogMtxNgbMJD71jadlgwqnjvwNsxNLrd+7dDTZC7s4atqRu19kYw8kRUfZ1qFwL947wlIrDd20PjNcMmfE2sI6wcOp7QixCZKj9T4gnw7BVCamM7FzGpjAIEwXr53nhX7JfZ7PtCguXXyAsLEZkWOtH5GtINscsOTDOeBZp4sMXyhYyB9b16I7NtlaNnIzAXEWseZtIM8cfCC0KnQ8nJ8OYP7cPNQ9OGVcs6+eVI4bs85e+nm9NpD3HQ2yRbXY4eU1R6zRinKPoRveQ5doRIjJefvllbNmyBddddx2WLVvmu/QfPHgQhw4dwubNm3H++ed73zWdyLAJjOQio/aoWV9svvd0KVu4j7v5zejJkCFRtSdP+cOlDNEjQ7Am7aFU4ru75sWHGvnu9mcdj752opKtbUy0p2z5hJERWhX1ndd9CpHhcLaHl6kGBfsN2GEJPwvfJoWJDJuYCEsCL7PIcEOl3BApKSTe/ILafPoEiCs6nI11wOsRtrGNEBkyQdwfsiQ8FD3HLHfjXa+Cm0wuN+/KwwH8UhM+aUSG5sFxvDXeSrB5XURqpWvfj2oenug6RkK8z1NkJssrb0mq9qwhXwna/ZuzpYcKpUiAb26ZYoqM2HAeyx1y966vu4mybrhMTL67+PbkatOW1O0aQsndJKt21eZk/va48CUz4VhPVtYG5W6UsooMd7No28imZOffjGpnZUqREfBgmfkAcZ4MN8wsSUiYLLMfK6b2ASuFCBSDdjaQUJvRmsiInoMpQ8jZvElRa9W/TrTQNm285pr37rYLRu7GOmT9mXfmg3fvo0WGb9NvWxumx8UmQCLqmYJb2Jf5HI9gobyAR4M5TQnPganOrbK+XCl6SKMmSk1Phk1ohAkM0W7TiYxc/hwZycm+92T4EpD1d0JkFRk1YSNs9yd++7+rLF+OnpHJkKTwWgJzZeFy9GAS86QnQ4UdiYTw+GTopOPJKjLkTt4LW6qFdIn2gkncptDTw53s4VLJxyp6lG0sOyjfXyJ/9xLKk6+iuKdLJWmpvCIj+NQlNR4nVKesIsMnTnTvS4pwKT0nIzQ/w2xP835IkWHL6YgRVZEiI0N7cTZYhJy+ZpV36mwtTC3JimYZnUAakaHuHDp/0LU70lEbkIFJ9aQpa3J02B13x8AokZGo3VxEhhum4iQdB2x2N7zOhti4q256RmJFnLbBCt2ECT4R7NJ4n9x5iXzKUphIyE1kOAxFzoXYlG7tlOF0Qixs7ZzCkQ993QtPk+FSMXNgCscyiQz3XIkOX7OJDHedqScndTjeOet5ZebEaPPnbsyj6qUVGZHnYohnVPTvru8oD0/kOSDOAz1kzRD6ol1TZIgqutAQv9s8GO41sj1FRpF/I5M84apI+xrWd5RHpGGd1t1wS4sM4Q34wL+rUCCPlBlGNNPhUu5GO2Kz/hbN7qgQJm9MtrZq43LDwjoCd/WVCPM+94kR47vIvvTQsWiedhvMJ2O5vycNl9LGYDkjTG9W3SdNmzUQFi4V3HxOoXNrLczoQ1+viQf/RkA9HUjcYPSFRPgeUboTOzvWY71zh/qoLd5fi6tXtmRoN4HIWB8jCuRyCMT/+0WTz3PgiC976FhEXL3Nk+Fsro8mYOcLaXLrJQiXigwpsoRw+TaUYTkeLgNrCJjlBJMbRZGKsRvXi/+bIsOdeyfx2+ap0T+LWo/+DbGxpoxwqbDQOVvegNXLFlh/o1ixv9sL1dPPIV++jBsipM2fK06D+VH6o3+d88oNAbTxd0OUbGsqJHRQFwSpz8WINl3xGDj/dZEUdQ54TjrH2+iMV3myFJewxG9XaIjVaIZI6SuUImOG/yAKr8O6SecJSzPcd7HdUWTctHZVoikYGRnBTLwnQ4T+DPwk+L4IX8iUFpYUSPwO/c6/qfeStGMTv92wJ4EpKpdDS1r+6UsY8x69G+XJ0N+ToffjTImRgA7NVjwJXL/wbFmwlpjuT4qXX1pDrIL5Hm6YV1QifeL2nLwZ96Eu8Ynfjp3HXqeFm7lJ5omWJwsZBFIlfmt3Dbu6unD0aG2z7W6C9OZDE7SNMJgwkSHXrBP6kqndJCJDbFTCEni9To0nGZlP+PGSW0XYl3ocqxPFAZdT7W6tlqyqh4zZRIYt6TWEXSBvIi7xWxNtYpg+O928BT90mVRrE1Rhd+V9S80Yn7k2RBK9Suq2vzuj9gjbAUzqOTXuRtM3B8oL4kuy195nErqmAu/JMOYqbeK3bf25AkxjHhou5QNoyT0IJP/7vWlW/pport2cM+pFnjf+C0jsOR4lMizrO1Hit3MOuB4rZZHLJ/kjbIXQEIeeg2H+gaDIaPifTP97GrKE7DTcxBnpgCKjbCJjRqa9qTsJEy1NPSganzOBRjzCNmcTy9Gc3MSaL4grh2nNZIXtfRfJ7Le8jC9ZxfYrZYZLtREBvoyvjSabQy2eQEuHSxWPt+QWUGSUfIJKYR5FRimmoW2MkJtAzMDbzduGqGWgbSwyTBpt/TK+dj4HOPaZISBExuOPP565s7lz56K8id+Zh9UmFSky2mSi6xomRUZd+FiZBMpHgCLDmxOKjPItT1rUQgQoMlpoMjkUEmgAAYqMBkBlkyRAAqUgQJFRimmgEa1KgCKjVWeW4yKBfAhQZOTDka2QAAmUj4AQGfUeL730Enp6ehI309vbi5MnT2LWrFnyp1KpoLJ48eJqtVqF+JkzZw6Gh4cTN3jnrr347E2fTlyeBUlgpgi0ksiYKWbshwRIgARIgARIoPkJiD39r371K/kjNvvepr9SSTy44a/cT5GRmBYLthWBVhIZ551zRlvNHQdLAo0m8OlP8+ZYoxmzfRIggeIICJHx6quv4r777sNdd92Fxx57DGeccYYUHEmP973vfRQZSWEFykW9PTxzo1krNudjYrOOdibqUWTMBGX2QQLNSUCIjHvvvVd68MUfXf5LDlwHPA9a7Trwwx/+EBdddJG8SH/gAx/Aww8/jPPOO096N4RnI2q84hpJkZH175sUGKPoHh3G6otVI+MbNwLbtuGarG3WVY8ioy58lsoUGXkTZXsk0DoExB/Qe+65p3UGxJGQAAmQgEbglVdegRAZ4kmZ733ve/GP//iPeOGFF3Duuefi7LPP9sKnbNCE4P7jP/5jioxsK0q9ZG/6xglsK0ZRWMymyMg2l+G1KDLyJsr2SKB1CFBktM5cciQkQAJBAr/4xS/wz//8z7jsssukt/aqq65KJTToyci6qqQXYxo3TkR4LbRQqtqbvh0hsGE+tm8/IHtfODCGYdcVElEHPcDIyHzcPbEN2NiJtQeqsn5l+S5MSKVDkZF1OsPqtbbIEG+AHUFPdTeuzxtcDu3ZXzolbN6KzqkjWD9P/7/eofNmW+2jrsEpHFk/L94q5/no6BrE1JH1SFDDaDPMJrPrkHLTO7GkYz9WRI4vfhihJXzt19EOq0oCFBlcCCRAAq1MQIiMH/zgB3j729/u5WEkFRr0ZNSzMoQY2ADsGF4NESl1Yk8vrt/+JCqVhdggw6eMDf/4RvQ+14fh1SewsXMdRnruVsJgfCM610EKh2tMkWDUmdwwWhMjnu16PxQZ9UyprS5FRt5EE7YnNsMrJ7AIx9C5TwgKt15SkeEKEVHPER19cW/JVeUwWsXuzKoriX2uTbqNNi5JBUtCpiyWO4F0IiMofvusa02bd+iiM3fz2SAJkAAJRBKwiQxRIanQoCcj6wKzejK0TT6Ep2MHnqwqb4M4lMdBOCHuwjwvjyNLHZn8gQVrlSckVNhkHRvreQQoMopZDNM7l2Al9mEfVsp/a16IJJt4y+Zc3sGfwKZIr00em/ok9lFkFLOq8u81vciIE5ZRayOP9Zk/A7ZIAiTQugTCREYSoUFPRl3rwuY1MAWDLZzKrJehjk/giNwQ6VIJek/qGh8rCwJtJTLkRrwfRwF0DQ5iUf9+f1jS4CL09w/JheELP9Lqie9qd2fVpgh9wNDQIoyKDb6vbJ/6LLDUprFzyUpAeDDEnVz5Xzd0Kckm3rYZE212YGKT46UI2NGDkUo31Ohq45MhW+6HnifEbN9m0yZMdNTaQ8CLEhXqZYSDja7A/m53XtywryBbRNhamwMxTm2ja50PxapfLATffPKaYBKIExlja5ZgcsD1xCUVCUnWRtK5EHO5HfOPlDMkMukoWI4ESKAYAlEiI4nQoCejjnkTIVLdO1SOhMr9NkOX1iEY4hQhMmSIVYI6IsTqrnkYFaFavidcMVyqjum0Vm0fkeEPFRKehI5+YNDLDejGkLtRlnkLIqpIbFyMEKNATkE3jnn5EMbmaWwNlkwOBHMlZKiUKyw0wSFDpvIQGWF2TGn5HuZyiOo37LuoTWWSjaQTXuPmh0Sy1e017QmbgxAO87ejMtKDavaYsbxPw9K2FyoynNwefzhUxHqIE/hTcaI1CpGzjmLDBUuLmYaRAAkURCBOZEQJDfF4Wz5dqt6J08KWRFNhSdziu9hwKZXc4QuzstdRT7ba/mQVlYXL0YNJzKMno96ZbG+R4dvYx23mzZhxfxiSuPs/0iM8BsamyvB4SOCWjY8bKuWGSEnBM7HJ2fTWIzI074jjsfEmXdqBoMhwE8FlwS5NdJk5H7Zk9DxEhj+8JpStnDIh/jxfTLytMt5feUh8HAYm5edImizfkDOvORoNiAx3jVs39M5mvwbbKtSDAj/uQQcJWVmFT8K6LEYCJNCWBJKIDF1ovPjiizjnnHNw1llnycfb0pPRlsuGg05KoG08GTMmMpLkRWhhRtYNWdymKyYnIzQ/wyaKXHt1j0qScKmop1+ZIk5fjVEiSg/5ysFWKTLC50Ntdo9q4W9Jz5r2KWeKDBVe54pRk0OI6Ex87iUNtwrj74bBhYUpts+8caQkQALJCIQ9Xepb3/qWl/xttnTq1Cm87nWvw5lnnklPRjLMLNWuBNpGZBhhT+F3U80Nsi1cyt242jbjeuiOZVWJu61bO43Hx4ZtrpOEHLn26k+NUjbXwrhcO4LhQ54tvlAlI79D3iE+ZvEc5OHJ0Oz0iaOktsYJouj5ML1K7XodCBu3PVwqbDNflMhw7QkTP5xVEiABErATMEWGeKrUAw88gE984hMQQkP8v6OjA08//TTe8IY3yDeDv+1tb8Ov/dqv4TWveQ36+vr4Mj4uLhIII9A+IsMfbmNN/Jb5GZa78L4wKH0jE+ZR0EJ0jLAScSd4a2fwnRa1kCk9pClKZOjeEMvmygzdsoZLaQnQXX3o0x+nq4cm9fWhb+iY9d0dXuK4NfHb77FRyfR6Xogan0raVkFNZlK9el+I+CbM1iiRIaoZIVPCzp4RLeyKd72jro7Rid8x7L2G/UI9ebhUmNdL/9zMaeK1ngRIgASSE9BFhvvG729/+9uYmprCH/zBH3jejH/4h3/AG9/4Rrz+9a+XAkOETAmRwZyM5KxZsg0JtLbIiJjQRI98bcMFwSGTgEYg7ulSflhmTob2lDZNtEYJfL9oDRPc9YZVcYpJgARIQBHQ3/gtfv/yl78sw6A++tGPQogO4c0YHh6W3gqRg3H++ed7+RjiEbbMyeBKIoEIAu0qMuRm5ljWt15zSZFAexBIJzLagwlHSQIk0DoEXnnlFTz//PO49NJL8cgjj2D27NlycBdeeCEef/xxGTYlQqgOHjyIX/7yl7jgggukB0MIDL4no3XWAUfSIALtIzL870YQMTr2d1g0CDSbJYEmJNA0IuP0aeCcc5qQME0mARIokoAQDiKR+4UXXpDiQYRC/cd//Ad+8IMfSO+F682oVqv4l3/5F7zpTW+SngwhMMRBT0aRs8e+S0+gfURG6aeCBpJA6Qg0jci49Vbg9ttLx48GkQAJlJvAq6++Kj0Up0+fliJDCAjxu/BunHHGGTLpWxwnTpyQv7/5zW/2RAY9GeWeW1pXAgIUGSWYBJpAAiUl0BQi4+mngSuuAF55paQUaRYJkEBZCQgPxa9+9SuIf90QqP/8z/+U3o2TJ0/iJz/5ifxciIvf+I3fkInfbrgUPRllnVXaVRoCrSQySgOVhpBAixDo/8wNuOeee8o9mptvBgYHgSeeAC6/vNy20joSIIFSEnBFhvhX/AhvxssvvywTw8Uh9koi6fvss8+WCeDioCcjp6kc39iJdbgbE9uuiWhxHBs778K80WGsFm/2Ls1RVrvKAaiVRMZ555xRDqi0ggRahEDpPRkiF+OSS4Af/QjYtQu44YYWIc9hkAAJFEXAFRoilEr8iEOESokf19vh2sacjHpn6cQe9G6YxnxMYt6OKAFR1s18We2qd2LyqU+RkQ9HtkICrUig9CJjZARYvlyhX7UKuO++VpwGjokESKAAAkJs6Ieb7K1/RpFR58Sc2NOLDdiBHdgg/x0OdVOUdTNfVrvqnJicqlNk5ASSzZBACxIovcgQAkMIDXGIUCkRMsWDBEiABGaIAEVGXaBPYE/vBkB4MCA8GuK/q+FFQwkvR/cOPFmtYuHAAObvGMW80R3Ahm5M3zgBL7pqfCM675qH0eHVOLGxE2sPKHVYWb7LCcFyhMCG+di+/YD8buHAmCZohB3d2P6kqrd811Oqba3/SmU57p7YBhnQZbWrbGFcdU1MbpUpMnJDyYZIoOUIlFpkiBCpiy7yMz91CnCec99yk8EBkQAJlI5AbiJj/x3rqlvv+wfg9e/Fhz7YgT/93/oSD/bOXXvx2Zs+nbh8aQrKUClXWGiCQ6oMIQzWAXcrMSE8Ht1CX4icjBMb0XlwmZfDIXI6Di7TRIccoO5hUG2N9Dh5H0KUyKaFaFACY7R71PCiGB6K8Y3ofa4Pw6tPhNtVqlyRcsxya4sM8WbgEfRUd+P6cuBWVmhvP27I+zrk28z3Y8XUEayfp/XXNYipfcBK/btYLhFvcY6r645T9HtkPYQp6Y6kb3YOKefjkLStFBaanFNUbZaiqUTG9CC65No6iv7IyRZz8WdYEFsugtL0IHZ13IG1+IG/0OHDwDVG7qC7Dq++A1NH+zOsw2aZrRLbmXht1DuGhGur7jWRsJ96h8P6pSeQm8hYvHhxtVo9Axf//lq8+9RB3HRb8iduNKvIcEOl3BApKSSmb1TiwSdAbKLhIJZJkTCOjb3Poc/1gIxvxIK1yltRqSxUouRiM6RJ+114ULqncaPrpXCXnOatcD+SnpG+5wyPC8Olos5SiowZvobJjekENrnCZ3ondk6tx/qGqSAlEjBaxe5MfZibc0d09I2iGtlgvf1KNYY1la3olGIpSiQkERBJyszwWmiC7lKJjMTjyWmDtmABIB5fqx+bNwO33aZ9ksc6TDywggvmxLXgUQS7TzOuJGXzWBN6P0n6LB1UGpQTgZxFxrm46o9uwFsm78eGPx9ObGJzigzlXTgQSHxxwpIiRYbybARyOaQwcAWD7hnJKjJCxIcvrIsigyKjRJ4McQdta2fGO/uJLznGJsvdqOdU3xRK1mbz2NRTZGSZsTzrxImMsTVdeGYgznNhWpTDpmx8HFi6NDjUnh7ggLqJpY4c+soTaEPbatWxphlXkrJJysRNVFqRMY3Bru247GiJ/hbFDZHfJyKQs8g4Cws+vg4LfzLa+p4MLY+iFmWkQpdUvkVEuJSo4D2VClg27ORK6G1KwTGK7jhPxsVR4VLrMLnBFkYVEsbFcKnASdNWngy5Oe7HUQBdg4NY1L/ff5d8cBH6+4cko67BKRyRsUYAtHri1z7PK6A2wegDhoYWYVR4J3xl+9RnPurqLtoxvX1vM7QVnaMrsL/btTHMBr3daexc0oF+MSjPNndzvgkTHd1QI3LHNKV5B+TgLPV1g21iQdWZ2OR4RwJj7sFIxex3HsbWVNDtGuN5QmyeEtN74R8HAl6UMEFjESlWvsF5RISttfkW49QEnHXu4/gm+jtWWKFQkeGEm9TOBXND72zC7ngHbr5ZTfrVd0zhqIyjcr6Tc3EzvuH7TixJEXalPq+FE6o6iv078C+rjuPX9x4KcHnxrPMw+5cvO5+rc81dcqp/sf5r7ahzVu/PPL//DAs0O8V4B57pQsfNyrramMxzxl9PLxd+HkTZ5Z7zYVzFuGpjDZ4jJtfgOF22/mtW1Fz55yQRSzdEzjrH6no02NUBBy/6RkeB7uTjuvqOO/COm/fXQvEC/fivTe68RM1JLazPJiw+h6e0a6zi3mGMwfUiO+sx1gtc2OnOjjMQyE1kPPTgzurhL/53/N1r3o//5fr/goEbkudYNKMnQ+RR3DXP3MA7uRduyJQW+lRL/HYTrJU42DFff79GLYG7snA5erzH4kZ4MrT8D9erYkv8FmvDSySPtCvDKmrhKu0jMvwu8umdS9DRDwx6oTjdGHIv/nIDJSKMhEAwXOuBOH9dMBib3bE1WDI5UBMr3jqqbTz9gqUbQ27+QlQ+gdcu5GZ//wpNjOiCxRpmpNuo7AjWTyMywsZsipmwNpOIjKzhUqbIiOJrE37uxlkXPWHzHcJh/nZURnpiQsvKe4EJiAx302bdKJmbsOhzasjNkQicb1q+xtgadD0z4IiDbnxfCIUb3gZc8Hrg9L/bwR0/Dlzs3lEy71qr81m24wkeLZzQlzvgbAp9dg7VhIXPbnN9d8MbX2g+QpCX365wDuHXqrBcF/M6pufPmEySjiUtS9c2Y068OYbcnIvrkZob9zDnMGifGw46PSgEIHCHFDNh/Sihac8JsgkJ11MX9l2wn8hz3irQy3sNoGXRBHITGSonQ70JcM6cORgebvVwKS6tdiDQNiJDbNpXAvu8BGRzA6qHFGnfwcihkHnUFYz0iLtTxsbS8HjI9RN118opv0h6RszNttZPR80D461J0e7ApD+/w/dHOSyXIXpswTUftEt5PyRMrJd8lOfFZ9tuGB4TM+G9SxN4Iex9eRg2O/RNiC0kLGqOI+ZRagshND0fULytYRzkHEk1axGb5b/CmCJD3fG92tnEmfZn2aC5Qs7Z9MHvVaidQ2I9OWX+5kvA2rXh8B54APj4x53vbSJD22BKAfAUPqd5HP3nt74ZjWkrYlNca9NcWy5Lo23Du2LlIPfhUcw1RKnGaW7i/RvyUD5J+wib44FnAnOhLIkQGaLPPwL+0kvo18omWUuulvGd7yFzEsraPnfwhKy5VF1vjc3TXf5rAi30E6DI4IoggQgCFBm2u+T1iAwtqTvBypMelYlNqAY25VpIkhQZlnZDcyOyC6hEIkPvN5ENbsiZOwZNpAQSusNsz1tk6CFfNrGY0laLGNVZKs/ZUS3ULsHiKEERe7hU2CYpL5Hh3/QHNpr/69XAN78ZTqe/H7jjjhKJDMXrqc9VsbtDFzXic7lDDt51t2zY7RvumRYZ2ljkjZEMgk1u/i1znHjMhniKFBkxa0mIDF+/EXOSVGQ45imvyje0c949b8JEeglOeJqQmgBFRmpkrNBOBNpGZBhhT8Fwqai76Xo4hb7hNze+KnwgmG+hraixndjZsV49WtbJh1DhSiqm2qvr27yHtRsW7pRQZMzLEi6lbKk9rSrMNoONnvDuCwUz8jvkHcVjFs9BHiIjiq82/6G22uY7LJQqeBURa24l9jWVRyM68Tvqzn493+nhTC5Hrb1/GQdO/N949FMP4lo8Lwv8B2bhx+/9bbztXACnTwPfUDkTwbvgNrvMcCl3YxrnuQi7w67OCS/0Sd/EirX1ZwvUo3QDoVmm1ySGQxpPRiDsU9/oR3gKnHrWsQQ8DMa1wbd5N8WQbWxqE55vuFQChqFzogsq1wP1fUsoVjg/ITT+CH+Jo8KZ6QnKdtphtP5YKTJaf445wjoItI/I8IcpWBO/3fdK+B6daiZ+u2E+7gbGCNMxQ6asScq2REa1gVXJlyr4yJdUG9qu+sNey6c2Q6+iNsbuGMz6+oLytw/o43dv2RkhU3LMZriUlgDd1Yc+HEOnCLfS3+MhB92HvqFj1sfWesmZcUytSe5RfE1GYbbGsLTNUc+IFnbVfOERcU+X8l96cvBkeHeW3cRvN+RQC5dyNtdbK7dgE74nTfi32cD5L9rCE+OEgpkQrd9ljqsbJTLcJG4nfd17WISW2Hy1OA++jwU2T4a8B2GEjnnnVXgIV/g5kmac5vkfNhbL+H02R7C0jk08IsN2PVOhjTJ60RZ+qoU6RSd+h62lsDkxQtvkten7Ti6Hf+w++5r8nK9jO9GWVSky2nLaOeikBFpbZERQSPQY1qQU8ygXdac+j/bZBgmkJ5BOZKRvv64a+mNsxQv4xIv4SnFEeQZKYWAKI/Iai2inhC9GTUGCRUnARoAig+uCBCIItKvIkHeejmV9E3UjlhRFRiOoss36CJRaZOzdC3zqU2qAItFbJHyX4shrY16GweQ0Fj0kqQzDog0kkBMBioycQLKZ1iTQPiLD/76C2vP364Z9swAAIABJREFUyzKvFBllmQnaUSNQapExOAjcfLMy9oYbgF27SjJ1OW3MSzGaOsfihUUx2bkU00kjcieQm8jYdv/e6i/u/QK+9gIfYZv7LLHBwgi0j8goDDE7JoGmJVBqkXHbbcCWLYrt5s2A+J0HCZAACcwggdxExv333lLdeecoTvM9GTM4feyq0QQoMhpNmO2TQPMSKLXIEO/K+NKXFFzhxRDeDB4kQAIkMIMEchMZ995yVfXO0dNt9DI+8RbudXDfsi3mbOHAGIZXu29SDZtF8+3dDZ7tE3vQ2z2K7lH3TeMN7q/Fmm8lkdFiU8PhkEDhBPo/cwPuueeewu2wGvCJTwAPPqi+uu8+YNWqctpJq0iABFqWQG4i47NXLa4eOt1Ob/w2xYISHSM9d2Ni2zURC2aGRUbLLt2ZGVgriYzzzjljZqCxFxJoEwKl9mQsXQqIJ0yJQzxZSjxhigcJkAAJzCCB3ETGVYsXV0WoVLVtwqUsYkF6DaZx48Q2hF/OKTJmcH3X3RVFRt0I2QAJtCyBUouMBQuAp59W7J94Arj88padBw6MBEignARyExmLFy+uCoHR1iIDJ7CntxvTN05AOjOk6NiBJ6tVVCrLcbcUH47IuLsbo+vUd7UwK5t35C7Mc0OdtPYWDgxg/o7RBN/pbTr/3zAf27cfkCvSF+IV1X4512/DraLIaDhidkACTUug1CLjkkuAEycU2+PHgYvjQnmbdhpoOAmQQEkJUGRknhibR0IXGcb34xvR+1wfhlefUGFVnRswOrwaF/tyJqJEhgrHwt1KwJzY04vuHcAGKUDivnOFihHSNb4RqklX/IS1nxlS01ekyGj6KeQASKBhBEotMiqV2rir1YYxYMMkQAIkEEaAIiPz2ggTGRuAHcNYjZoXw+2isnwXJrYBGzs17wSA8Y2dOLhMiIcIkSHak02vhrofpZWN+k4KEF1k6H0nbSMzpKav2NoiQzzjvRtDfaOo7r4+MFfTO5egox8YnDqC9fPSTGXSd1okLef27dirmdI1OIUjSYwTL7vqHgK6BjG1D1jZsR8r4sYl33oeUi7quzSovLIhY/vQ1zUb0vLKZAgrpSBQWpHx4ovABReokcyeDZw6lWJULEoCJEAC+RCgyMjMMSYnIzQ/w6wX4f1IKiQoMjLPYlzF1hcZW3GsC1ixzxQS7qa3q2QiYys6PXEQLZJqc6vKYbQKi5aKWwLO943e4CdpP0mZhMNhsVwIlFZkiDApES4lDhEmJcKleJAACZDADBOgyMgM3P50KTecSXka1mFyw6jxWFvjc58YMXI6ZDjTZMKQqKhQqgSejMiQq8yQmr5iO4gM9AHHOvf5PQLizv8I0Dd0TNvUJ53OpJvhpOXcfi3lpUdhApuquxH0xUTUSzoUr1xaW9N2kKT9JGXS9svy9RAQf0DLeFz2/PPY8PWvS9Oee/Obcfvv/m4ZzaRNJEACbUDgfe97H3p6ehKPtLe3FydPnsSsWbPkT6VSQaU9E79r78moVBY6YkDjqCVSi0/1cCn0AAcOPCkLL9/1lEoUF8f4RixYq5KyK8uXo2dkspbcrX0XSPwO/S5huJSIwYpqP/HyaK2C7SAyOqc2YaJjBD3eRn0aO5esBPaJzzXPgdzQ9+OoM8V9umdA+65rcBCL+vc74sTcGOu/G9/52u/DaEA42DbZwtYOTGxyvBSBNnowIkLCHJtVeNUU1lTccTltDi5Cf78qVQvBcvsTHGptQIaXQWsDQCibqPb1cyVMQNTDq7XOxbKO5t9Ov4rSPR56ZARYvlwh++AHgbGxsuKjXSRAAi1OYN++fRQZTTfHUY/LTfQo3ZgR59FG00ENGtweIuMI5m+vYKRH26gLjXFkPrb7NuNayJEvJ8EfjuTP5UgqMoxyY2uwZHLAyLeIExlhbeiiQsyxuXHX8lJk7oaIrBKekYgNvqUNLxzLwsbLe/G1b4oMTcgAUCIuzIYkvFrgBGyCIZRSZOzdC3zqU4qeeAmfeBkfDxIgARIogABFRgHQ6+1SJIuvm3SeUGU0FvVd0n7zaCNpX2Uu1y4iYz12QjovjqzH1BpXcGgbWfG9EZY05pbrqNVV+eFpNueOR0G2X/OSyGYCCelhIkMaDjkGaxuG1yGLffMixFIUG59IMNmYIkPPN3G/C2GZiFeZz6zWsa2UIuPznwduvVVBvuUW4PbbWwc4R0ICJNBUBCgymmK6VL7G9ifVowhr790Qv0V9l3RwebSRtK/mKdc2ImOeEyK1aQX2b1ViY56+GZ8RkZEht0LPyQjNz0jqTYkSSGUUGXG8muc8a2ZLSykyhMAQQkMcQmAIocGDBEiABAogQJFRAHR22RwE2kdkCAeEesxrMCdBPHnKHxKlchDcTW5UuJSRMyH7OOY8sSoYtnQs8pG0to2+/tQoZUewjQaLjFg25hOx4jwW+rkRFS5lG2tznFetZGUpRYYIlRIhU+IQoVIiZIoHCZAACRRAgCKjAOjssjkItJXIgBAE2zH/iPukpqjEbOPRtu57KGTitJ74XRMvcsb7+rQnVkW1HxYupectWB6vayRgW5O0M4VLCQ1WgXjVRnzit25XlMAJExNJREYw2TwYXtYc51izW1lKkXH99cAjjyi0IulbJH/zIAESIIECCFBkFACdXTYHgdYWGc0xB7SSBMpMoJQi4+qrgW9+U2E7fBi4xn18YZlJ0jYSIIFWJECR0YqzyjHlQoAiIxeMbIQEWpZAKUWGeBGfeCGfOMSL+MQL+XiQAAmQQAEEKDIKgM4um4MARUZzzBOtJIGiCJRSZFxwAfDiiwrJqVPA7NlF4WG/JEACbU6AIqPNFwCHH06AIoOrgwRIIIpAKUVGpVIzuaqeSMiDBEiABIogQJGRgbp4j8Rd80YxvFpzQ49vROfBZZjwXt9tPBZ24QBGh1cjX8e1eKN37c3jYigLB8ZqdsmX6o2ie3QYuqkZhlxflbLYkXIUFBkpgbE4CbQZgdKJDBEmJcKlxCHCpES4FA8SIAESKIgARUYW8AFBAQjhcXDZBKTGkJvqHZh/t/O76OPEHuw5sRqrc83BEyLjLszzRIQSHSM9d2tiJ8sAbXXMvvJqt7zttJLIKC9lWkYCJJAXgVnf+/9w7nuvlM396p2L8co/PpZX02yHBEiABFITGP7K/ejp6Ulcr7e3FydPnsSsWbPkT6VSQWXx4sXVarUK8TNnzhwMDw8nbvDOXXvx2Zs+nbh8KQpKETGNGye2QWkGsQE/iGXyd+XBmL5RExgNM9qy8Q/YllfnFBlpSc6dOxdnnnkm/uLOe3DT2mTPqh8ZGUHvx/4wbVex5c8754zYMixAAiSQjkDpPBnj48DSpWoQ4qlS4ulSPEiABEigIAL0ZGQCbwgJ3bOReJMv2hjCpcOuUDENifveFTe6J0N8ptumCwP1f/QAIyPzcbcQRI7H5clqNfIt4st37QLW1cKyKst3KU+JVl/0vHzXU8qTI0WX3tcyHNQ9LtZ+/eFltbYyTVAulVrJk0GRkcuSYCMk4CNQOpHx4IPAJz6hbPz4x4EHHuCMkQAJkEBhBCgyMqI/sacXG7BD5j8EQqU2ADti8y/iRETc91lExjpMbnBzSQzPxPhG9D7Xh+HVkJ6Y0W4j58QRDmZoFtyQMF/ehQrbsvcV0u+lQ0ZOS8aJybEaRUaOMNkUCbQggdKJjC99CVi7VpG+4QZA3CDiQQIkQAIFEaDIyApebKqlmPgA/lb9RyVXx3kyjLv/bvfenfu473322kKYhDhx7Ql6MjyRYOlHeij6njNCwdwOjb4s46yJLVuuiONxgcpXEd4T96j1uwPwRFDWicmvHkVGfizZEgm0IoHSiYzbbgO2bFGoN28GxO88SIAESKAgAhQZmcE7m/kbuzF6l+65SJqTEeepiPteGB6XkxEnMvS8EgdEqEjKU2RY+vW678X125/UQq8yT1DdFdtFZIytqaAbo6juvj6C2RjWVLaic+oI1s8zi4V9Jz7vxlCfve3pnUvQ0Q8MWtuMmr4oW/R6ScvVvVS8BpKxzK+/YEtZ5qmR9rR226UTGcKLIbwZ4hBeDOHN4EECJEACBRGgyKgDvAiZEhti32Nj5d5/IxasPeDfKAeeLhUnIuK+t4kMFabkhTD5RIj9SVS1kCYXhBJJ2cKlXPEQ4cm42AylCk6AHopWx/TUXbUtRMb0TixZOYFFOIbOfTYB4WLMsnlVdY51ASsCbTsCBF0lEhl1ipLELOtemjmLwUba09ptl05kiHwMkZchDpGPIfIyeJAACZBAQQQoMuoBH/X+ByMcqTID78moVBZig++dGBGeDDFu00Y3oVuKk1qitxvKJcKh1h6owpb47e87SmSE9LvsoBRm4qhUlqvE9HrmJoe67SAyhDdhJfZhH1bKf48E3RQOyewiA33AsU6j7bE1qIwAfUPHQrwjUROYVAwkLZdESMUvqOQs49vKXiLLPGXvrd1rlk5kiCdLiSdMiUM8WUo8YYoHCZAACRREgCKjIPDstvwEWl9kTGPnkpWA8DJAeDTEf9fDi4YSd+Y7+nEUQNfgIBb1768JgqjvvKl1N7ybMNExgp7qbqiALLdf8bkWgqW1KUr1jVbhRXCF9mduqvXfje987fdh1LNH9OZ6Vhzj3RCvKJt8SziKpfiuA/0CpDcu22cCTY054NrojGN0BfZ3q/kQbAYmRbiZarRrcMoRiMGyge+m9gErOzCxSeMrRN/WTkzp81/+U7RwC0snMq64AvjudxWXJ54ALr+8cEY0gARIoH0JUGS079xz5DEEWl5kyPAeV1hom2SpMtSmG85G358/EfWdDrW2yZ+/vYKRHmdT6/U7H9u9PA9/m2qzvR8rZL5GnC16rkiYyDAEx9gaLJkcMDw3NsFSY+C3yVg8USyl16bHn/Ni+0wy18bi2Tilclu6BpUIEHW7h2rCQv4upkqIOEcsuWUDHJ32p/w2iVwSb354ZUhMoHQiQ7ztW7z1Wxzibd/ird88SIAESKAgAhQZBYFnt+Un0Ooiww3vcUOkpJCY2KQ2w75Nsys6nA1qwOsRlfgdrDPlbWi1eqLNjgls0rwL3sa3w/SyRHgrfBt1s33lBfCOQEK6zfMRYpORIx/LUmW410SN47GwfRa0EUbSfQrvjZCLNt5SuLnepTGsWTKJAXoxUl+USicyKpXaGLQn+KUeGCuQAAmQQA4EKDJygMgmWpNAa4sMIzyotvNWd8TzFhnzHE/JphXYv9X1nsy0yPALhuCqzSoyYlg6HSlv0FFfGJjvMyGmDKGlqkaJCvN7s6wKy1KhUf7vypFD0tzXjlKJjBdfBC64QAGdPRs4daq54dJ6EiCBpidAkdH0U8gBNIpAS4sMawy+uSHNL1xK5pObYT4Br4MZmuSKgqhwKd1mt49jzhOrTI9HN47p3oTAwkkSLmURKrEsax2ZHg/xTe0zFRYVtDGtyNDakB4TnaORA5PoyWKNOsOav91SiQwRJiXCpcQhwqREuBQPEiABEiiQAEVGgfDZdbkJtLLIECE0Wzu18B1nKnwhU44oEF8FEr+jvvOm1XZXfTvmH3ETwG2eAzekyXi0bUJb0NenPbEqqn2ZPR14N4h8z8WQ9p0vEdv+uN1Ylj0jModCHU4ytzaeWoK3mfjt2pE+XEo80WtoSAVe1RLog2Ftxb/Xo9zXgDjrSiUyxFOlxNOlxCGeKiWeLsWDBEiABAokQJFRIHx2XW4CrSwyyk2e1s0UASZ810e6VCLjkUeA651koQ9+EBgbq29wrE0CJEACdRKgyKgTIKu3LgGKjNadW47M8ZqYjy0mmFQESiUy9u4FPvUpZf+qVcB996UaCwuTAAmQQN4EKDLyJsr2WoYARUbLTCUH4iPgvqMjy9vWiVInUCqR8fnPA7feqsy75Rbg9ts5WSRAAiRQKAGKjLrwn8Ce3m5sf7IqW7G+1Xt8IzoPLsPENvfNqwnq1GUTK+dFgCIjL5JshwRak0CpRIYQGEJoiEMIDCE0eJAACZBAgQTaWmQsWLAATz31VDb8J/agt3sH5t89gZp+2IM9J1ZjtasnIATFBmDHMFaLdyIlqpPNHNbKnwBFRv5M2SIJtBKBUokMESolQqbEIUKlRMgUDxIgARIokEDbiwzBPr3QUN6I6Rs1gWGbRCEqhi7FsFQhCesUuBjYtZ9AK4kMzi0JkEBrEzhnxe/jjP/na3KQp7/2dby67Hdae8AcHQmQQOkJDH/lfvT09CS2s7e3FydPnsSsWbPkT6VSQWXx4sXVarUK8TNnzhwMDw8nbvDOXXvx2Zs+nbh8ngVdT0Zqj4b0SEzjxolt8JwWFsNO7OnF0KXDytORsI4SI0O4dDis7bjv8yTU3m21ksg475wz2nsyOXoSaACBUnkyxONrxWNsxSEeXyseY8uDBEiABAok0PaeDNeLkUpoCMEgo6BWQ0RB2Y9xbOw8iGWuEElUR7QUJyLivi9wNbVY1xQZLTahHA4J5EygVCJDvIhPvJBPHOJFfOKFfDxIgARIoEACFBlaTkZioZHEKzG+Eb3P9WFYJmMk8GQ4+RpPVlUSuXss3/WU5gnZgdDvC1xErdo1RUarzizHRQL5ECiVyLjgAuDFF9XATp0CZs/OZ5BshQRIgAQyEqDIcERGYoGhFENMToaR8J2ojjuDcZ6KuO8zrgRWCxCgyOCiIAESiCJQKpFRqdRMNW5WcRZJgARIoAgCFBlPPYV0AsOZpvGNWLD2ADxPg9QeztOlLtYTvrVpjarjeyIVczKKOBnMPltbZIxhTaUbQ9qg+0ar2O28MDgZf9HGVnROHcH6eclqBEuFteHY1zeKqsWo6Z1L0NEPDNbVd1ab4+rFjKku5nF9z9T3wfXTNTiFIx/6OpZ07McKOS95rI+ZGk+2fkojMkSYlAiXEocIkxLhUjxIgARIoGACbS8yBP/0T5dyZs0IcXLfkwE94duc4JA6jJ4t+EywdN/6IqNRAiHNXEZtyLfiWBewYp8pYtwNbllfJhc9Jk+Uja1BpRsYre5GKm2XBm/DyiYREEnKNMzAGWm4NCLj6aeBBQvUmC+/HHjiiRkZPzshARIggSgCbS8yMguMUKrj2Nj7HPoik8K5KJuBAEVG3CzlsYmM3pCjDzjWuQ9HdFeJ2JyPAH1Dx+r0osSNL+v3CUUG8uCX1cZ66yWxPUmZeu0otn5pRIZ4qpR4upQ4xFOlxNOleJAACZBAwQTaWmQUzJ7dl5xAe4oMZ2M4ugL7u/txFIAIoxqYFOFJ4jdAhsXITX+wbO07ANM7saRDtQH01e7Ya593DQ5iUf9+i1hwN6ibMNExgh7vbv80di5ZCewTn9c8MWNrKuh2Y7+8ECunjcFF6O9XX+r22ev47Q7Yl8uYHM+MEEtbOzF1ZD1ktJm1bTHeDjjo5VzI6DFfWTVHKqrM3Njrv6v/C+E2NLTImY8k7Wtz552zSYSUUSaMXcmvA1HmlUZkPPgg8IlPKFPFS/jEy/h4kAAJkEDBBCgyCp4Adl9eAq0vMvScDHcj6YQidQ2qza8M6Rmqbc59IT5GWbmJDInHH1uDJZMDOLJ+SuaCwNkUh+dW1Dao87dXMNKjba6FxjgyH9ut+SDmprobQ67oCA1PCtax22dsmjONSWPuyzcJaXv+dlRGeoy8FMXdtVEJjrA8iODYjnkiUQmM/Stc0eiei2Hj1BNvgjkZSugERY0KD0vSZnmvBWGWlUZkfOlLwNq1yswbbgB27Wo+mLSYBEig5QhQZLTclHJAeRFofZFhy8mIuhNu3ikP3s0W3gEpCDp0L4YzI2JTPTAJ6Yhw796HhgxpbWOnV2fKbd+3mRU38JUYUoebqxEzFlsdrS+1pTbs8DwzOYypYwKbXA+N4ZmQrbu8VIZ7LWRMltXqyuG7Qizek+HlhFjakf2G2eJLwE/pyRBcbezSPWkgr1M7t3ZKIzJuuw3YskWNa/NmQPzOgwRIgAQKJkCRUfAEsPvyEqDIMEVFnMhQd8YnNrkiw78R9jawaUXGPCdEatMK7N/qChRz8+/25YZT2Z5ulKBOrMjIa0xiL78EK+Hkm4Rt+J3TQ3l8jqqwKCngGi0yLOP0napZREZcm+W9FoRZVhqRIbwYwpshDuHFEN4MHiRAAiRQMAGKjIIngN2XlwBFRhKR0Q0v/Ma3UVbhNLXQHHee/aE+ScKlVPqHEbaleximtNyGpKFDkXXCwrlyHpPPixPWdu38qIkSf8iZ8jzoIssReiJHQ3I75jzq1xQGUeFStrnTz9WUIkOGS8W1Wd5rQelFxqc+Bezdq8x84AHg4x9vPpi0mARIoOUIUGS03JRyQHkRaH2R4X9PhkqKFhtYPYwqPvxGJRI76d36uzbMsBtfboSbiB2X+O0+vlZsiLdj/hH3ca+6XVryclcf+nAMnfKxt1G2h9Xxh15FJ347IU0i5EcLvYpPZq89kleKrP0rVP6LjVfPiBYGZk+er4WHOStfDwPr69OewmUTBv7cirDEchm6VU+4lBCKYeshrxO2gHZK48kQT5YST5gSh3iylHjCFA8SIAESKJgARUbBE8Duy0ugtUVGebmXyrKYMKZS2UpjZpxAaUTGFVcA3/2uGv9TTwFvf/uMs2CHJEACJGASoMjgmiCBEAIUGVwa8jG3x5wnbREHCRgESiMyxNu+xVu/xSHe9i3e+s2DBEiABAomQJGRaQLGsbHzLswbHcZq/Vou3+Y9im7z80AfIfUz2cJKjSJAkdEosmVu1//eCN/7PcpsNm0rhEBpREalUht/tVoIC3ZKAiRAAiYBioxMa6JekVBv/UxGs1JKAhQZKYGxOAm0GYFSiIzTp4Fzz1XkZ88GTp1qs1ngcEmABMpKgCJDm5kFCxbgKRHPGnvUKxLqrR9rIAvkQIAiIweIbIIEWphAKUSGCJMS4VLiEGFSIlyKBwmQAAmUgABFhjMJQmCIoz6RoYsH5/8b5mP79gOy7YUDYxiW8VVmuXUY6bkbE9uuAWTI1Q48Wa2iUlmOuye24RqnPHqAkZH5zmclWD0tbkIriYwWnyoOjwTalsCsb/0jzn3/Ejn+V3/7/Tj914+2LQsOnARIoFwEhr9yP3p6ehIb1dvbi5MnT2LWrFnyp1KpoLJ48eJqtVqF+JkzZw6Gh4cTN3jnrr347E2fTly+EQVdgZG/yNDEw/hGdK6DTzTMG90BbOjG9I0TEPrCLz7ErxvR+1wfhlefwMbOdZjcMOqIlEZQYJsmgVYSGeedcwYnmARIIGcCpfBkPPIIcL14KQoA8cf8gLqpxYMESIAEiibQ9p4MXWDkLzL05PCgl2OycwLo1oSD5sVwF0Zl+S5MbIM90bzo1dPi/VNktPgEc3gkUCeBUogM8RI+8TI+caxaBdx3X52jYnUSIAESyIdAW4sMU2DMrMhYh8nOTkzMv1GFSYlDioxp3ChDpPSDORz5LPd0rVBkpOPF0iTQbgRKITI+/3ng1lsV+ltuAW6/vd2mgeMlARIoKYG2FRk2gTGzIkN5OS4d6sRd81xvhhATtrAoiowizh+KjCKos08SaB4CpRAZt90GbNmioAmBIYQGDxIgARIoAYG2FRn1sVdi4ID2PHKV1C1yJ9wQKVMYWJLC5fs0TmBPbzd2YANGh1fjYiNkiuFS9c1UPbVbW2SMYU2lG0MaoK7BKRxZP68eZOnqjq1Bpdu1oA+j1d1wIsvTtRMoLca2FZ1TR5BuOGH1gqz6RqvYHWesO74uvsyvzgktbfVSiAwRKiVCpsQhQqVEyBQPEiABEigBAYqMEkwCTSgngdYXGVk24jnN1fROLOmYwCZXWEzvxM6p9Vgft3FP1H0jRIbGSooHxIgiJUyQRIwkGhMLlZFAKUTG8uXisYMKz9gY8MEPlhEVbSIBEmhDAhQZbTjpHHIyAhQZyThlKiU26ls7MXVkPfL3nTRYZCBJ+0nKZCLHSiUiUAqRsXQpMD6uqHzjG8Bv/VaJCNEUEiCBdiZAkdHOs8+xRxJoW5EhvQz9OOrQqYUGqY0z+oChoUXOnfxp7FzSgX6nsFfW14YtFErd6T/mC9FSbU1s0kKRPDEyH9tFCNToCuzvVraJvgYml6DD6bwW7uVs8LWyvlCwmPEFw6wMwWAKpMBYezCihaJ5fVuZWJhGlOscXIT+fhVi5g9vSzMPIWV5PUhNoBQiQ7yIT7yQTxziRXzihXw8SIAESKAEBCgySjAJNKGcBFpfZPhzMpRAMMJ85IZ3P1bI/AZTGKjN6v4VZi5HcFO+ZHLAku9R2+x64kRs4Ed6UHUSHsbWVDDSU7NryM1vcPIdvI22L4TJyaFwy1rG4IUxBb6zhZAZORl9o559ML0aY2ugxjpl5IWEMRHldLEVXW7I7ds33pTzMH+7j3E5z77msKoUIuOCC4AXX1TATp0CZs9uDni0kgRIoOUJUGS0/BRzgFkJtL7IsGyozVwJEebt2+hrdSxlJWvDUyA/823MjRlxyi/yRM4IemSuxhjWLJnEgAypMsOPon4Phip5Y+gwckGixueZqbWHYC6J7vWpjRV+kRHKJGM5nYdpk2t3WJ8Dk9JThZlO9M96Ipa4XilERqVSI6Q9jKTE2GgaCZBAmxCgyGiTieYw0xOgyFDMsokMLak7AfrpnUvQMbFJegjE/1diH/ZhpfxXPfGqHpGhhWHVKzLmCQ2l7JN2hQkt0968yyUWGeHzIJn3H5VhZ7FPykowh+1YpHCR8aMfARddpNCLMCkRLsWDBEiABEpCgCKjJBNBM8pHoC1Fhty8ak9F8m2OzY1+VJiOmW9hzO/YTuzsWO88YtZoR/S5cgKLcAyd+9zH0KYVGVr/gTEkHZ9rc5zXxDZWW528y7lepezz4BNM5TsFS29R4SLj6aeBBQsUp8svB554ovTMaCAJkED7EKDIaJ+55khTEmhPkWGGO3Vh0HvfhO2JSf58BXvity1cKirPQXlPuhGR+xDp2dCTqVVGuu9uvS+MKG6vqQ9OAAAgAElEQVR8onZw3NILsH+FejqWGZYkQ8OMMCjRTK7l7CLGe+uI652w9dkz0qD3k6Q8wVqgeOEiQzxVSjxdShzXXAMcPtwCVDkEEiCBViFAkdEqM8lx5E6gtUVG7rhybbAWopVrs2yMBHIlULjIePBB4BOfUGMSL+ETL+PjQQIkQAIlIUCRUZKJgPmm74UD6g3ghdhnvq28ECMK75Qio6ApkOFSwL6GvEOjoDGx25YkULjIEG/6Fm/8Fkd/P3DHHS3JmYMiARJoTgIUGWWYNykwRtE9OozVjqoY37gR2LYN1xRiH0WGwE6RMdOLz32krR7CNNM2sD8SSE6gcJFx223Ali3K4M2bAfE7DxIgARIoCQGKjMIn4gT29HZj+sYJbCtGUVgIUGRQZBR+YtAAEig9gcJFxs03A4ODitOuXcANN5SeGQ0kARJoHwIUGUXPtfRiTOPGiQivhRZKVaksx92yrCMENszH9u0H5CgWDoxh2HWFRNRBDzAyMl+2g42dWHugKutXlu/ChFQ6FBkUGUWfGOyfBMpPoHCRIUKlRMiUOB54APj4x8sPjRaSAAm0DQGKjKKnWoiBDcAOJ//ixJ5eXL/9SVQqC7FBhk8ZG/7xjeh9rg/Dq09gY+c6jPTcrYTB+EZ0roNfgLjhV0adyQ2jNTHijV/vhyKj1URG0cuc/ZMACeRP4JzfuRZn/P3fyYZP//WjePW3359/J2yRBEiABDISGP7K/ejp6Ulcu7e3FydPnsSsWbPkT6VSQWXx4sXVarUK8TNnzhwMDw8nbvDOXXvx2Zs+nbh8yxW0ejK0TT6Ep2MHntTe5Ko8DsIJcRfmeXkcWeoIp8VGLFirPCGhwqbloCcbEHMyknFiKRJoVwKFezKuuAL47ncV/qeeAt7+9nadCo6bBEighAToySh8UmxeA1Mw2MKpzHoZ6vgEjsgNkS6VoPekcEbFGECRUQx39koCzUKgcJFxySXAiRMK1/PPA295S7Ogo50kQAJtQIAiowSTLEKkuneoHAmV+22GLq1DMMQpQmTIEKsEdUSI1V3z1KNyfU+4YriUmAWKjBKcHDSBBEpMoHCRce65wOnTipDm7S4xMppGAiTQRgQoMsoy2VrYkjApLIlbfBcbLiUeg2u+d8MaYqWebLX9ySoqC5ejB5OYR0+GtyIoMspyctAOEigngUJFhhAXQmSIY/Zs4NSpckKiVSRAAm1LgCKjbaeeA48j0NoiYwxrKt0Y0iB0DU7hyPp5MVhEva3onDqC2KKRLeXVjq2TLG2H1YnjpNfL0m/cKuT3ZSZQqMgQYVIiXEocF18MHD9eZlS0jQRIoA0JUGS04aRzyMkItL7I0MWCs5nuG0V19/URgPLaSOfVzkyIjChOFBnJzqbWLFWoyPjmN4Grr1Zgr7kGOHy4NSFzVCRAAk1LgCKjaaeOhjeaQHuJDADTO7GkYwKbqrsRLjPyEgd5tTPTIsPkRJHR6POwzO0XKjIeeQS43jlTxSMiD6inBPIgARIggbIQoMgoy0zQjtIRaDuRgWnsXNKBiU1VSGeGFB39OCpnpg+jUnz4xcHYmgq63Zgr6QXp8Lchqo6tQWVrJ6aOrEctGCtCZPj6BfpGHXtkU2Z/ziZLq9M1OIhF/ftrIV3WcfjHF6jjrUabnTqnMJGhyvQreL4xlG6h06DMBAoVGeIlfOJlfOJYtQq4777M42BFEiABEmgEAYqMRlBlmy1BoL1FhrG5HluDJZMDOLJ+KiQnQys/tQaVkR4v7EoIg5GemlBQiyM6BwKusJACYT9WBHJAzM19N9w60zuXoKMfGJR1osYRVkdfvhlFhsGgJU4IDiJAoFCRMTgI3HyzsmnzZuC22zhDJEACJFAqAqURGU8988NSgaExJHDlFfPw+OOPZwYxd+5cnHnmmfiLO+/BTWtXJWpnZGQEvR/7w0Rl0xQ675wzjOJhm+eVwL4jWA/di+FUlZ4K+EWG8FJ4rowubWM/gh7X87FkEgM+L0aEyLCEbPlEiq0/Yas02/WUaGMLG8fAZHgdX+57DCefiAn2i0TJ9GlmkmXLRKBQkSFExZYtCsfttwO33FImNLSFBEiABECRwUVAAiEE2k5k6Bv80PwMcyPt5nCI8CBHoMwTkVZLsBL7sA8r5b/Bp1aFeDKiREaHnjOi9RcrMix5JqKfMGESJzJ8NkbnZCivylGGS7XoVaZQkSFCpUTIlDhEqJQImeJBAiRAAiUiQJFRosmgKeUi0F4iQz1dygtTkuFM3TgWuBNvhEW5uRZmWJPcxE9gEY6hU3hGAk/GTRMu5YgEPbfD15/f9mC4VNg4soRL2Ti5T5+yj8kVXPGPBy7X+qc18QQKFRnLlwMjI8rIsTHggx+MN5glSIAESGAGCVBkzCBsdtVcBFpfZOjvyXBDnbQ5MhKwEQiX0pKbu/rQZwgKmaSNsEfiOo/M1brz3tPh61e3K6I/LYwqOvFbZmGrfJGoOp5dpp0mpxBPhsjJqGXEO0nzzbX+aW08gUJFxtKlwPi4MvIb3wB+67fiDWYJEiABEphBAhQZMwjb3tU38MXl/y+uPvBf8e7CbaEBOoHWFhmNn2t7wnfj+2UPJDBTBAoVGQsWAE8/rYYqXsQnXsjHgwRIgARKRIAio/DJaLTIEO3/Jf7LXbvwe79e+GCbygCKjDqmK5DzUEdbrEoCJSVQqMi46CLgRz9SZF55BTjnnJJSolkkQALtSoAio/CZp8gofApCDKDIyDIzbkiTJfwqS3OsQwIlJlCoyKhUamSq1RJTomkkQALtSoAio/CZ10WG43VYeQn27f1radncVfuwvedtIuhWeSQ2XoN/2HYPnq1Wg9953grXe/FH+MGNn8Nh5w9Q5QNb8Vc3XV34iJvFAIqMZpkp2kkCxRAoTGQID4bwZIhDhEmJcCkeJEACJFAyAhQZhU+IKTI+h/Glf6bEwLf/HL+/DbhV5muIcp/D+NxP44s7Poa3nvwKBm4cx/uksDBDovTfGS6VdYopMrKSYz0SaA8ChYkMkYshcjLEcfnlwBNPtAdwjpIESKCpCFBkFD5dFk9GwCNhExLAd+78n/GNq/8Gn3kPRUYjprGVREYj+LBNEiCBYgic8fd/h3N+51rZ+au//X6c/utHizGEvZIACZBABIHhr9yPnp6exIx6e3tx8uRJzJo1S/5UKhVUFi9eXK1WqxA/c+bMwfDwcOIG79y1F5+96dNo3zd+ZxUZ/4KvbViFH3yMIiPxYktZsJVERvCN3ylhsDgJkECAQGGeDPF+DPGeDHGIl/CJl/HxIAESIIGSEaAno/AJSSMyPocfrNyrcjRkuNQ/4WMylEoXHHDCrI7jj6yhVIUPuGkMoMhomqmioSRQCIHCRIZ407d447c4+vuBO+4oZPzslARIgASiCFBkFL4+0oiMvwSWAof/dlJavfR/fxSfeY8zgG//OT7y31SyeOUDv4NrDh/3Hlsrwqq2/W0VeuL3rH//JX511tmFj77MBlBklHl2aBsJFE+gMJFx223Ali0KwObNgPidBwmQAAmUjABFRskmJNycfBO4f+3o3+PMn/0ML/zuR5qGwEwbSpEx08TZHwk0F4HCRMbNNwODgwrWrl3ADTc0FzhaSwIk0BYEKDKaZprzFRlnvvBTvPO6Lhy//Q78/Hc+3DQUZtLQdhEZ4s3c3RhFdff1M4lX62sMaypb0Tl1BOvnmSZEfWczN6S8eDlgx36ssPaht5OkP1GmG0Natb7RKgrDV9CssVugMJEhQqVEyJQ4HngA+PjHOR0kQAIkUDoCFBmlm5Iwg/IVGaKXy99/JSq//CWe/cLd+B9dv900JGbK0LYQGfLN3BNYhGPo3Gfb5M8E7RkQGYmHkVRkaKJobA0q3cBodTeKkmmJh8eCuRIoTGQsXQqMj6uxHD4MXHNNruNiYyRAAiSQBwGKjDwoNmkbb1/5UZz3/e/K3Izpu/47Xnr3e5t0JI0xux1ExvTOJViJfdiHlfLfI0FXQmPg+lptcpGBJMJkBjCyixknUJjIuPpq4JvfVON96ing7W+f8bGzQxIgARKII0CREUeohb//L9v+D7xp+AE5wldf92uYHLofv7jMecFTC4876dBaX2RMY+eSlYDwYEB4NMR/10NFLInvOtB/VNFS4UC2z0RREYrUD1W0z7mj72y8R1dgf7f6TrQxMLkEHU6jXYNTjqgJlg18N7UPWNmBiU1aWJLwIGztxJRns+g/bMOvf+78f3AR+vtV0FOwP+HVccKi+sxQMqMP0w4rjyTsXM62cQTtRx8wNLTI4Z2kfXdukp4BLBdHoDCRccklwIkTyrznnwfe8pY4U/k9CZAACcw4gdKIjBkfOTvEa+69F2etX++RqL7+9fjl+Dh+NX8+6QB47Wtfi8cffzwzi7lz5+LMM8/EX9x5D25auypROyMjI+j92B8mKpumkPU9GTJUyhUWmuAQKkNsnEd6/Hkats/MTf3YGiyZHMCR9VMqb6FrUIkAGVI0VNvM+0KMnM28W9aXP6Ftrqf8NolckpEeMxciqcjoxpArHgK2iFAoi6jxgBs5GT4REhQgksf87UGekp2Ms1L5HGHjlqrPFBndOOaJNCUw9q9wRZtraIgthXir0qzW5ilbmMg491zg9GkFqlptHmC0lARIoK0IUGS01XT7BzvrW9/COSK2Vzuqv/mbOD02BvFvux+tLjLcUCk3REr83jGxSQkL5248vI1szWNh+8xxeKglIzfdMJK5zc2/xbOgJWXXBIRZbgQ9MvdhDGuWTGLA58UwN+P6Co7qL/jdsa6jQGDTbtm8Cw9QxwQ2ufkYPi+GU17wGJiU3p4gO62u1HaucErBS/bpb0f2HGYLM9Rzu7QVIjKEuBAiQxzCgyE8GTxIgARIoIQEKDJKOCkzZVLlX/8V5771rYHuKDQUktYWGcEnJDkKwZfALIVH/1EnXEqV8H3WEbLBDYQtpdg0O6FaKjTKXy8+hySpJ0N/mpXFS9DVhaOLHMEVOEPsNkmxFrbhd9qIY5e/yLCIj5m6wLRBP4WIDBEmJcKlxHHxxcDx421AmkMkARJoRgIUGc04aznafO6ll6Ly4x8HWvzVO9+JXz7yCEQIVbseLS0yrPkMKuzGl/fgiAozKbzmBVFhUbXQHXe1RIkKUSYi/Me3UTfaiX0aVh4iQwmQ+dsr2NpphiCZtseMxXLymOz84VKuKDDmQoZ0HcOg9PaYY4wKl7LNTbue0fmPuxCR8d3vAldcoQYjniolni7FgwRIgARKSIAio/BJGcfGznUY6bkbE9uCjyE8sacX3TuADaPDWH1xBmNP7EFv9yi63frjG7Fg7QFUFg5gdHg1LuvpwRmHDlkbTi401BgOaLHBCwfGMPyBv9X6FmXuwrys48gw9HqrtLLIEHfMbRtoL2SqZ0TmUKjDSRh28ip8n4lfzLCcjOFSKpHZSR/33jsRFA3R7/UIemhUUrcQQ673IqlXxUmmhpNX4i2ooE2S2/4VKv/ExsPGM8CuyxERTkc6774+9A0dc94lYhNS/nF77+2wzg0ftFvvtcGtX4jIEI+udcNce3qAAwfyGg7bIQESIIFcCVBk5IozS2Nq8z3ZCXTvMIWEI0DQmV1k+ExS7eHuCbh65qw//VO85q67Qg1/9brr8MsHHwTO+WaESEgiIJKUycKvcXVaWWQ0jlrjW7YnfDe+X/ZAAiaBQkSGeAmfeBmfOFatAu67jxNDAiRAAqUkQJFR+LSozTd6gMl5OzCsuyvGN6LzINAzMpmTByC40T/jq1/F2eIPleWozvn/23sb4MjO8s7338POXrOsjfkItlNQaGfEeEdKADvEu2azMLaxErfxjeTIFeOt7Expw1ykEl4HNNlYWWLDLnKIRPA1Woka16pmE9brLSuRasE9RL4YQZGQMrl2oK40IOSJco2xzfJh8DokxSV96z0f3e85ffr06aPuPqe7f13l8qjP+/G8v+dt6f338zznXKIfv+99+v9+/dcRGSn2Se7vLpViTZl3CdwRK3NrMKDPCWQiMu69V/qN33DJ33WXdPfdfe4Flg8BCOSVACIjc8/4B/9p7RY3NLI9Jzdpak8r4zPSgnm/mma0OTukyTX3loWFsWUvxcobY+aI5ufd0LmTruQIFnv8akqTf/3AZz6kC37lIzUUvnPRP9RbX36J/q5Q0NjysjRV7Vud1+9WL0phvx9q46RxLWirXFahMKalyrozd0jFACIZ+fFF9bkdoZSiPJmILX1HIBORYUTFBz/osv7Yx6Q77ug77iwYAhDoDgKIjMz9VD18Hzo9pI0RL5XJHMKNxlg9pNORtQzhA7xV12EiIE5WlBEsMQd9bequo/dp/v/9E4dC+RX/SIXv/02FyN9+6UsydRnuKy7dqbYmY2z5nOaO1Zs7NNbmrMbPnwxGcTL3S6/fXSoHgDEBAl1OIBORYVKlTMqUeZlUqTqR6C5Hi/kQgEAPEEBkZO5E68AtX1hMaG/WFxy1B3JTuG1ehcKwV6sRFgAJD/deNOF3nntOGy99qT75j/+xFv/hazXy5Jec8b/0xuv0pi/9j4QiI6qou44dZp1eFMPHXxsdydwxPX4L2+z5YgEEup1AJiLjXe+STJ2ceZ09K/3SL3U7RuyHAAR6lAAiI3PH2gdxL0VquqjSooliTGjAjiA4h/NdTTsRCj+dyhSL70dk+OO5IA589au64OqrK1RuuPRSXf6fnwxFJcLQmkyXCqwjcwfUNaCX0qXySxnLIACBZghc8IvX6SVf+LzT5Uef/1P9/VX/rJnutIUABCDQMQKr//2TGjV3wUv4Gh8f19NPP60DBw44/xUKBRXe9KY3lcvlssx/l1xyiVZXVxMOJ923fEbvv/3didv3XsPoSEVtTcWqJvZmNbQ46Nx6diBwa9qUIsMRMFPamSkFUpX+t1tv1Us+9SkH9QtvvES/+u5HtTqxl+LuUnERldp58+bbrETG8ePH84YCeyAAgbwQOHpU+trXXGvMg/jMA/l4QQACEMghASIZmTslLBBMhOK0Dq36BeDhSEdR81tlFYbHNKodDTq3vU0rMkx9eTB1yaQtfW3wv+qC9z5QIfPFL31JV77xjfKLzltd+G0mIl3Kxb2+vi5ERuYfSgyAQH4JXHaZ9Oyzrn0/+pF0wQX5tRXLIACBviaAyOhr99dfvB3N+MlNN7nPyuizF5GMPnM4y4VANxAoFFwrjbgwIoMXBCAAgZwSQGTk1DFZmxWuzQjeaSpr6zozPyKjM5yZBQIQSEjARDBMJMO8TJqUSZfiBQEIQCCnBBAZOXVMHszq92gGIiMPuxAbIACBCoG9Pemf/BP3xze/WXriCeBAAAIQyC0BREZuXZO9Yf0ezUBkZL8HsQACELAIbG5K11zjvnHsmPS5z4EHAhCAQG4JIDJy65p8GNbP0QxERj72IFZAAAIegfV1aWzM/cE8hM88jI8XBCAAgZwSQGTk1DF5MaufoxmIjLzsQuyAAAQcAuZJ3+aJ3+Z1xx3Sxz4GGAhAAAK5JYDIyK1r8mNYv0YzEBn52YNYAgEISLr7bumDH3RR3HWX+zMvCEAAAjklgMjIqWPyZFa/RjMQGXnahdgCAQjozjul3/1dF4RJlTIpU7wgAAEI5JQAIiOnjsmbWf0YzUBk5G0XYg8E+pyASZUyKVPm9d/+m3TrrX0OhOVDAAJ5JoDIyNw75mndU1orlyuWDJ86q9WJgQaWhZ/y3d6FHPjMh3TBr3ykMkk/PDcDkdHePcXoEIBAkwRuuEH6zGfcTubOUuYOU7wgAAEI5JQAIiNzx4TFgis61keXtD0X9weksyLDYOq3aAYiI/MPBwZAAAI2gauvlv78z913zp2T/uk/hQ8EIACB3BJAZGTumgixsLei8eKuprfnVF9mdF5k9FttBiIj8w8HBkAAAjaBo0elr33NfeeZZ6RLL4UPBCAAgdwSQGRk7poosbCnlfGidqe35QQzHNGxoK1yWYXCmJYc8eH1WyqqNOVeq6ZZRUVHFjVYWpWThWWNN3zqlI4slBJcc8e8ffAf6NBnP+VQO//Gw7rm+R87/w6keMWNnznv5AYgMpKzoiUEINABAv7dpUwthqnJ4AUBCEAgxwQQGZk7p5HICF3fnNX4+ZNandhz06qGZlRandCAc7AvqegIiTiR4aZjackVMHsr4youSDOVfnHXFvXPf/93dOuvXF2h5tRmfO9BuUP64qfeGJnDbsoAREZTuGgMAQhAAAIQgAAEKgQQGZlvhnoiY0ZaWNWEqlEM39TC2LK25+REFirRCUmbs0PaGDHiIUZkmPGcoSfklpZbbeOuWcJl8rfeoZd86ktO75/cdJP+7sH3VG2JHSNz2E0ZgMhoCheNIQABCEAAAhCAACIjP3ugQU1G3fqMcD87xaq9IuPXf7iiC65+rxXN+Lh+61Yv5QqRUeFy+PBhHTx4UB+9737dPpnsfvbr6+s6fvx4frYnlkAAAhCAAAQgAIEUBIhkpIDW2i7Rd5fy05ncSMOUdmZKodvaht4PiJFQTcfmrIamdhKmRMWnS7mRk009+VMT+tm/ec6LZlyt93/1Yi+qEpeO1Vpy7R6NSEa7CTM+BCAAAQhAAAK9SgCRkblng8/JKBSGPTFgGWYVUpt37XQpjUpra1tO47Hlc26huHltzuro5Jrzz8LYmEbXd6qpVda1msLvutdsMbSp/zQ4p1PP/GnFyPnL/oVe+n9tuIXlceNnzju5AYiM5KxoCQEIQAACEIAABGwCiIx+3w9xt8ttcCvdRM/NSHQ73nw6AZGRT79gFQQgAAEIQAAC+SeAyMi/j9pqoSkWn9rx7lAVminummma5LkZjcZo6+L2OTgiY58A6Q4BCEAAAhCAQN8SQGT0nevdeo35rbKz8upzN8xPcdeiQdVGM343Zvzugo3I6C5/YS0EIAABCEAAAvkhgMjIjy+60pIk0YyuXJgkREa3eg67IQABCEAAAhDImgAiI2sP9MD8iWozunCdiIwudBomQwACEIAABCCQCwKIjFy4obuN6NVoBiKju/cl1kMAAhCAAAQgkB0BREZ27Htq5l6MZiAyemqLshgIQAACEIAABDpIAJHRQdi9PFUvRjMQGb28Y1kbBCAAAQhAAALtJIDIaCfdPhu716IZiIw+28AsFwIQgAAEIACBlhFAZLQM5T4Gsp/OXRjT0vac/Ad372PUjnfttWgGIqPjW4gJIQABCEAAAhDoEQKIjKwdGX4i9t6KVvYmNNGUytjU7NCiBkurmhjIdkG9FM1AZGS7l5gdAhCAAAQgAIHuJYDIyNp3m7MaWhxUaXVC6fVBfkRGL0UzEBlZfziYHwIQgAAEIACBbiWAyMjcc0YgTGlnpqTVShjCffL27vS25vyIRkWMXKtHrSd2jy0vS1NTWit7T/AeW9a26eRESBa0VS5bT/X2xMhSUaUp99rY8jmdPD+uG+a3HBLDp85adqSD0yvRDERGOv/TCwIQgAAEIAABCCAycrEHXFExv+Ue+h1hYUTFxogrGJwfh7Qxsq05Bd93zQ9HMkI/b85q/PxJrU7sOYJmfWjGjZx4tSAVYWHmnNK+a0J6JZqByMjFhwMjIAABCEAAAhDoQgKIjDw5zYs+HFkyEQwjFDY04hSBb2p2/LxOGmHgtVEg8hESFVYUw19ewYlwKFS70UCc7INNL0QzEBn72AB0hQAEIAABCECgrwkgMnLm/r2VcRV3p50Ihvn3jBa0oBnn/9V0KpMN5aY4uZGPKJGxq+mau1Q1EhWtq+3ohWgGIiNnHw7MgQAEIAABCECgawggMrJ21eaKVgYmvLtCuWlTpaJXn2EiEjO7OqIdDS7U3jnKFyFuGpR9d6moOg+z0M6JDDNbt0czEBlZfziYHwIQgAAEIACBbiWAyMjcc64gqCnc9uwytRhTWqrUZphajaOTa87VgvVMDdNucq0sNy0qWPjttO1wupSZs9ujGYiMzD8cGAABCEAAAhCAQJcSQGTk3HGVgu+mnpuRn0V1czQDkZGffYQlEIAABCAAAQh0FwFERp795aRLSQv7eoZGtgsMRzP+5sUXszWoidkRGU3AoikEIAABCEAAAhCwCCAycrkd3NqMhe0hzeTgKd77RXTwwx/Wwbk5/eSmm/R3Dz643+E61h+R0THUTAQBCEAAAhCAQI8RQGT0mENZTusIIDJax5KRIAABCEAAAhDoLwKIjP7yN6ttggAiowlYNIUABCAAAQhAAAIWAUQG2wECdQggMtgaEIAABCAAAQhAIB0BREY6bvTqAwKIjD5wMkuEAAQgAAEIQKAtBBAZbcHKoL1AAJHRC15kDRCAAAQgAAEIZEEAkZEFdebsCgKIjK5wE0ZCAAIQgAAEIJBDAoiMvDjFepK3MWn41FmtTgw0b515tkaxpGKzt75N2y9sYavGaX7lLe+ByGg5UgaEAAQgAAEIQKBPCCAy8uDozVkNTe1Yz8Rwn5NRKpYSCI1NzQ4tarBZUdGydWc9f8sWUjMQIqN9bBkZAhCAAAQgAIHeJoDIyNy/rqDYnd7W3DHLGCcisKvp7TnZb9eam/UhP+v52+dAREb72DIyBCAAAQhAAAK9TQCRkbV/64oJIz5mpIVVTQx4B/mlokpTC9oql710qj3NDk1prVx2VlEYW9b2nKzIRm2/seVzOnl+XDfMbzl9qmlZVbFw7aPV69Vxj2lzdkiTa+G54uaX5KzPtdm8zPyumPLmmzmi+fm1kC1ZO8WdH5GRDz9gBQQgAAEIQAAC3UcAkZG1z8wh3NESEwpWYNgRDnMgn9L60IxKpl2g7iEcSbB/DvXz6j4qwsJJ05KWnGhJVETCvLehkZpoSngOO12rdn4teVGaGruntD66pG2jOgK2ZO0UREY+PIAVEIAABCAAAQh0KwFERtaeayaSYdVdmKjCxog5vDcSGfUEgBVNcMatFRnVOTxIVnF6oTDs1ZDEzK/alK9kdmftFNLlo6gAACAASURBVERGPjyAFRCAAAQgAAEIdCsBREbmnktSkxE+yIejHHGRhJQiw0QWNkbcKIN5BcRQRCpXRQBZtiIydPDgQX30vvt1++SJRDttfX1dx48fT9SWRhCAAAQgAAEIQCCvBBAZefBMTaqQm+a0M+PfXSr0c+DA345IRkSalLFxcTBVulYwXcovZo+zOw9OoSYjH17ACghAAAIQgAAEupEAIiMvXgs9J6NaIG0MdA/kGpXW1tyCbfu6X5Bdt/A7KsrgFIBE11YcOl0t8DatCsOnVFq9Vo+OFzW/VVZheEyj2tGgU5Ruyinc9rXzBwu/qylW4bmjfs7eMRR+Z+8DLIAABCAAAQhAoDsJIDK6wm+9e5vYPONHZOTZO9gGAQhAAAIQgECeCSAy8uydim2IjCzchMjIgjpzQgACEIAABCDQCwQQGV3hRURGFm5CZGRBnTkhAAEIQAACEOgFAoiMXvAia2gLAURGW7AyKAQgAAEIQAACfUAAkdEHTmaJ6QggMtJxoxcEIAABCEAAAhBAZLAHIFCHACKDrQEBCEAAAhCAAATSEUBkpONGrz4ggMjoAyezRAhAAAIQgAAE2kIAkdEWrAzaCwQQGb3gRdYAAQhAAAIQgEAWBBAZWVBnzq4ggMjoCjdhJAQgAAEIQAACOSSAyMjcKeb2tFNaK5crlgSf9p3EwFbc4jZujDTj1+tj3t/QyPacjjlPHA+uffjUWa2ax4g7rzTzJuGVrA0iIxknWkEAAhCAAAQgAIEwAURG5nuiFQfpdo+RZvykImNRg6VVubrCFR3ro0vanjuGyMh8b2IABCAAAQhAAAIQSEcAkZGOWwt7pTnAh6dv9xhpxk8jMiTtrWi8uKvpSqTDFiEtxJ5gKCIZCSDRBAIQgAAEIAABCEQQQGRkvi3iDuOLGlwqqjS1oK1yWSaN6uT5cd0wv+VYXU0t8saw2gbSjpyDuztGoTCmJecA7x/o3feHT53SkYVSNapg9Ym7lni8CudwulRYROxpZbyo3eltzR1LI25a51BERutYMhIEIAABCEAAAv1FAJGRub+DdQnVQ7uXOjQ0o9LqhAY2Z3V0cq0qLDZnNTQlTzCE2joCoaSik4YUOqhvzmr8/EmtTuw5qUlaMod5E0AYV3FBmqn0ibtmCYNE49mQERlxW259fV3Hjx/PfFdiAAQgAAEIQAACENgPAUTGfui1pG+DSEagXiFcv+D/XDvG5uyQNka2NTdQjWL45hbGlrV98rzGZ6QFI2CcC9YYWom/5kVFEo/n13FX5rELv6MiGY5htQKpJbyTD0IkIzkrWkIAAhCAAAQgAAGbACIj8/3QDpFhpRw5IsOvcbAWa6IdqUVGk+M1IzKoySCSkflnEgMgAAEIQAACENgvAUTGfgnuu3+rRMaUdmZK7u1faw7q1rWKvW6KVbp0qWbHsyHFpUsFbeIWtvveXAwAAQhAAAIQgAAEMiGAyMgEe/jQHfWsCFMzUS89yvS3xYn7b41Ka2tuUXjgWRtWEbe55qRLmUIMr87DvFdT3B13Lc14AXET/ZyMQmHYqwnxGzd6jkZ7nUe6VHv5MjoEIAABCEAAAr1LAJHRu75lZfskgMjYJ0C6QwACEIAABCDQtwQQGX3rehbeiAAioxEhrkMAAhCAAAQgAIFoAogMdgYE6hBAZLA1IAABCEAAAhCAQDoCiIx03OjVBwQQGX3gZJYIAQhAAAIQgEBbCCAy2oKVQXuBACKjF7zIGiAAAQhAAAIQyIIAIiML6szZFQQQGV3hJoyEAAQgAAEIQCCHBBAZOXQKJuWDACIjH37ACghAAAIQgAAEuo8AIqP7fIbFHSKAyOgQaKaBAAQgAAEIQKDnCCAyes6lLKhVBBAZrSLJOBCAAAQgAAEI9BsBREbGHt+cHdLGyLbMA7jdl/0kb/+tWQ1tjGj75HmNF0sqllY1MdCM4RFjNtO9qbbuU7rXR5fcp4qHXnsr4youKPRk76YmiGnc2nUiMlrlF8aBAAQgAAEIQKDfCCAysvb4picg/AP53orG3VO4Vj0lYQ7mM1qo/Ny8ya09fMfP7861MyQVF8JiyBMgGmogMtLam6RfkjbuChEZze80ekAAAhCAAAQgAAFDAJGR9T4womJGWlidkAlOGEFxWkXt7B7SqiM89rTiNmgyemEvLPnBev843Lk0Ku0MhoSRI6ik0fUdDcZGY9Lam6RfkjaIjP3vA0aAAAQgAAEIQKCfCSAyMve+LSL8f09rt7ihke05HXPSp+x/L3oHdO+wPHNE8/NrziqGT52tRju8iMhWuazhU6d0ZKFUPdhb10y/seVzTrpWMHUrdBg3fU4b4TOglfGi5rfKzpx+3ypGv5+9BnPVXpu/BkdVOZEbY2ehMKal7RFtDE1preyOXxhbdtKujG2Ta8H3nAYx66ztIyeVK+nYRDIy/3BgAAQgAAEIQAACXUoAkZEDx1UP95uaHT+vk6sT2psd1/mTq5rYs9Op7IN/qPbBRAmmpKWKMHF+cMRDsA7C7edfcw/pXp2HPdfmrMYXd0zOkyNcKilbh0679SER9RYuyqqNh05b9SaViM0hnR4KCSU/qmHmPH9SqxN7TjQkOtpRyyB6nbZjw32SjE26VA4+GpgAAQhAAAIQgECXEkBk5MFxfl3GyEblAO8f6hc0Y9VjxB2WrWsKpmAFisnNteKuph0x4skCv/h8oNrPETkjRZUWTabWtXrUT9ly+gdrRoIIo+3YqxS4h657UQx/DDdyYSIOISGwOaujk27EplAYdms64tZpcs+i+gxEF9bXjD2AyMjDRwMbIAABCEAAAhDoTgKIjDz4zfuWf7pY0sahVfdOU056klTcKVn1GG0WGceslKYZE1Ex4uK0Di0MatGqGzHIjAi6YX4rJl3K1JB44037YsXUnYRFRlDwhKMhTu27E23x21npZYnFlJ2SFpEGFjU2IiMPnwxsgAAEIAABCECgSwkgMnLhOHMILmph277rkn8nplEvBcoYmlBkON/WN5MuVT3oOxGUkgJpUqd3j2hn0KQxBe+bG33Xq9Ah3osmVOtFatOddqw7aUWKDBPpWRxUyRTH2+ldces0qV91+1hRkrpjE8nIxUcDIyAAAQhAAAIQ6EoCiIycuM2pmygV3YO0Z5Op1ZiS/byJpCIjmCoUV/hdST3yJw0c4v0ogvVsjkAKkinUrqZdRQoEp+D7tA6t+u2iIglu4bd5hQu93Z+rxeaF4TGNakeD/t22LHuC63SFmylQD/fxC8IbjU3hd04+HJgBAQhAAAIQgEDXEUBkdJ3LMLhTBBAZnSLNPBCAAAQgAAEI9BoBREaveZT1tIwAIqNlKBkIAhCAAAQgAIE+I4DI6DOHs9zkBBAZyVnREgIQgAAEIAABCNgEEBnsBwjUIYDIYGtAAAIQgAAEIACBdAQQGem40asPCCAy+sDJLBECEIAABCAAgbYQQGS0BSuD9gIBREYveJE1QAACEIAABCCQBQFERhbUmbMrCCAyusJNGAkBCEAAAhCAQA4JIDJy6BRMygcBREY+/IAVEIAABCAAAQh0HwFERvf5DIs7RACR0SHQTAMBCEAAAhCAQM8RQGTkyKW1T/iOMi70xOzc2J9Xu9IDQmSkZ0dPCEAAAhCAAAT6mwAiIy/+31vR+MyujmhHgwurmhioZ1heD/N5tSu9gxEZ6dnREwIQgAAEIACB/iaAyMiJ//dWxjWjBS1oxvn/al2VkdfDfF7tSu9gREZ6dvSEAAQgAAEIQKC/CSAycuH/Pa2Mz0gmgiET0TD/nFAlmGGiHMUFbZXLGj51SkcWShosLUgzRe1Ob2vumLeIzVkNLQ6qtDqhvdkhTa6VnQuFsWVtO408ITBzRPPza8614VNnLUFj7ChqfsvtN7Z8zh3bmr9QGNPS9pycKSPtiovC5AJ2YiMQGYlR0RACEIAABCAAAQgECCAy8rAhnFQpX1hYgsNRGUYYTElLrpgwEY+i0RelVU3szWpoY8QTEJKp6dgYsUSHszY7wuCOtT665PYxosQZ2ogGV2CUiqVQFCUUodic1fj5k1qd2KtvV91UrzzATm4DIiM5K1pCAAIQgAAEIAABmwAiIwf7wU+V8lOkHCGxO+0KgYAAiRINGxpxRMKmZsfP66QfAdmc1dFJN1pRKAy7omQgnNJk/WwiKMVdTftRCp+LFa3w33IiIyfPhyIupEuFt9Lhw4d18OBBffS++3X75IlEO219fV3Hjx9P1JZGEIAABCAAAQhAIK8EEBmZe8aNLqyV3RSlykHeT0uKFRluZKOmlsMRBr5gsCMjaUVGHfERSOtCZCAyMv8wYQAEIAABCEAAAjkhgMjI2hFWHUU1y8hNXXLrLWLSpUyHyl2ppJFVr1bCHtMRHCUVG0UyBuLSpaa0MxOVRlUnjYt0KWdXEcnI+sPF/BCAAAQgAAEIZEUAkZEVeW9eU0exOBg+wHu1F37KlJX6VC389gusXXGwcMSrs3DGrRZwF4bHNFq5LW5MJMOq//CjKlGF32b0SiF5rF0Zg23B9NRktAAiQ0AAAhCAAAQg0JcEEBl96XYWnYQAIiMJJdpAAAIQgAAEIACBWgKIDHYFBOoQQGSwNSAAAQhAAAIQgEA6AoiMdNzo1QcEEBl94GSWCAEIQAACEIBAWwggMtqClUF7gQAioxe8yBogAAEIQAACEMiCACIjC+rM2RUEEBld4SaMhAAEIAABCEAghwQQGTl0CiblgwAiIx9+wAoIQAACEIAABLqPACKj+3yGxR0igMjoEGimgQAEIAABCECg5wggMnrOpSyoVQQQGa0iyTgQgAAEIAABCPQbAURGv3mc9SYmgMhIjIqGEIAABCAAAQhAIEAAkZGjDWGe/j0l+8ndxjj7Kd3hJ3aHjLeewG2uDJ86q9UJ51Hezb32VjReLKlY8p8q3lz3XmmNyOgVT7IOCEAAAhCAAAQ6TQCR0Wni9eYzB/uZXR3RjgYX7MN9QpGxOauhqR3NVITBnlbGiyoVSwmERgPxkhdGHbYDkdFh4EwHAQhAAAIQgEDPEEBk5MSVeyvjmtGCFjTj/L8agUgiMlxBsTu9rblj1oKciMSuprfnZL9du2RERtQ2QGTk5MOBGRCAAAQgAAEIdB0BREYuXGZEwoxkIhgyEQ3zzwm5iU4JREZdMWGNO+CNs1RUaWpBW+Wyl061p9mhKa2Vy85shbFlbc9Js0OLGvSjIs74bh/zGls+54kZb8yZI5qfX3OuVVO0XOEzvxXukwvgiYxAZCTCRCMIQAACEIAABCBQQwCRkYdN4aRK+cLCFgZNiIyAMPEXZUc4jCCY0vrQjEpGwATqLsKRjLCwmZKWvChJTb8prY96dSROypZpOqdj5t8bI9oOhFbyADu5DYiM5KxoCQEIQAACEIAABGwCiIwc7Ac/VcpPkTI/F3envQN6iyMZVjG3KTTfGDHiIUZkmMhKKOUqeb8FaSZJTUgOnBBhAiIjn37BKghAAAIQgAAE8k8AkZG5j9wIg5+u5JtTKIy5EYEk6VJKUpMRFhLhKIeVHmXPmVZkeDe1MoLphvktK8Uqc+CJDUBkJEZFQwhAAAIQgAAEIBAggMjIekOYtKLFQTeFqWJLPQEQU6Btpyo547jiZacSSQj9HKjjaDZdyi8mj+tXBRuO1GSNPOn8iIykpGgHAQhAAAIQgAAEggQQGRnvCJN6tDhYm1JUTZmyi7Cbe05GtUDbFx2L0qi0trblrNq+buyYXCs3LPwuFIat2+TGiIy9WR2ddIvBq1GZjGE3OT0io0lgNIcABCAAAQhAAAIeAURG32wFblPbrKsRGc0Soz0EIAABCEAAAhBwCSAy+mYnIDKadTUio1litIcABCAAAQhAAAKIjD7bA4iMZh2OyGiWGO0hAAEIQAACEIAAIoM9AIFYAogMNggEIAABCEAAAhBIR4B0qXTc6NUHBBAZfeBklggBCEAAAhCAQFsIIDLagpVBe4EAIqMXvMgaIAABCEAAAhDIggAiIwvqzNkVBBAZXeEmjIQABCAAAQhAIIcEEBk5dAom5YMAIiMffsAKCEAAAhCAAAS6jwAio/t8hsUdIoDI6BBopoEABCAAAQhAoOcIIDJy49I9rYwXNb9VdiwqDJ9SaXVCA7mxr1lD6t0yt877eysaL5ZULK1qIieLRmQ063PaQwACEIAABCAAAZcAIiMPO8E5YC/oyNK25o55Bu2taGVvQhP+z3mwsykbmhQZTY3dmcaIjM5wZhYIQAACEIAABHqPACIjc5+6EYzdaUtgZG5TKwxAZBw+fFgHDx7UR++7X7dPnkgEdX19XcePH0/UlkYQgAAEIAABCEAgrwQQGVl7xoli7Gp6e051gxZepGOr7KZSjS2f8yIe3kF+qajS1ILMdXPt5Plx3TC/5bQdPnVWq07+UTNtpc3ZIU2uealbY8vadkIs3hgzRzQ/vxYaX5Jl5/CpUzqyUNJgTfpTEvGRfJ5CYUxLcez24V8iGfuAR1cIQAACEIAABPqaACIja/ebg/mMtFC3/sIcuKckP5UqULvgXlsfmnHrNzZndXRyrSosNmfldjUCppm2NhRbFHhjjC65oiNifN/OvZVxFRekmdQiY0rrdedZrIqXzVmNnz/pCanWOhOR0VqejAYBCEAAAhCAQP8QQGRk7etGkYyI6ybKsDFi0qvCUYG4n5tpa4IWrmAxr0Jh2BMLMWMoLJaSRCzixIwlJPwIihEsZp6iG7XxX4VKpKW1zkRktJYno0EAAhCAAAQg0D8EEBmZ+7pBTUYWIsM5yPspXMY+J9SiiYG8iIwG6WUt8ikio0UgGQYCEIAABCAAgb4jgMjIg8u9qEG11sKtb3DvLhWVLuUfspuJTjTRdm9WQ4uDbgpWTXpWnQiDI0CqaV37T5eKn2dnptSWFCl7OyAy8vDhwAYIQAACEIAABLqRACIjL14LFXcHnpNhXaumLhnDmxAOcVEI57kU9ljVZ3YUhsc0qh0NNopkOLXl1RSr+MLvKa1Z6U5ucfqeZod8YdFgXWFWpEvlZRdjBwQgAAEIQAACEHAIIDLYCBCoQ4BIBlsDAhCAAAQgAAEIpCOAyEjHjV59QACR0QdOZokQgAAEIAABCLSFACKjLVgZtBcIIDJ6wYusAQIQgAAEIACBLAggMrKgzpxdQQCR0RVuwkgIQAACEIAABHJIAJGRQ6dgUj4IIDLy4QesgAAEIAABCECg+wggMrrPZ1jcIQKIjA6BZhoIQAACEIAABHqOACKj51zKglpFAJHRKpKMAwEIQAACEIBAvxFAZPSbx1lvYgKIjMSoaAgBCEAAAhCAAAQCBBAZbAgI1CGAyGBrQAACEIAABCAAgXQEEBmpuJknUk9pfXRJ23PHakbYWxlXcUGaKa1qwnmadpMv54nWJRX9/t6TtANPAW9yyHDzzdkhTa6Va0Zxn76dxujwU7r3aWAOuiMycuAETIAABCAAAQhAoCsJ9LXIOHr0qM6dO5fCce6BemdIKi6EhYQnQDSUXmQELHLH09K2IvRMA9uTHPyTtEmCqFXjJJmrM20QGZ3hzCwQgAAEIAABCPQegb4XGcalzQsN90CtUWlncCH4zf/mrIY2pNH1HQ2mjWTUiIzFlGMlOfgnaZNk47dqnCRzdaYNIqMznJkFAhCAAAQgAIHeI9D3IsMIjOYjGv6Belq7xQ2NbM/JTZra08r4jLRg3q8KAzs1qTC27KVYeWPMHNH8/JrTu5qqZI8/pbWym9ZUue6kUy1oq1xWoTCmJWd+M3dR81tu27HlZWmq2rc6b3gTR4gDa3x3rHPVKErda4iMMNnDhw/r4MGD+uh99+v2yROJfnusr6/r+PHjidrSCAIQgAAEIAABCOSVACLDS5dqTmhUD9SHTg9pY8RLZTIHcKMxVg/p9FBU9ME+iIfqOkwExMmKMoIh3M4eK3SY35zV+PmTWj10WkMbI6EakSQH/3CbUHpWoD6k0bW0EZd8fjyIZOTTL1gFAQhAAAIQgED+CSAyrJqM5ELDOpjLFxYT2pv1BUetEDg66UYrCoVhr1Yj6nDvH9JjREYokuCMaaIjJ8870Q3NlKz0rRQiwxl/V9OV6IxkIjGOkBqIuXYsyVz5/0DYFiIyustfWAsBCEAAAhCAQH4IIDL2GcmYGPBSpKaLKi2aKMaEBuxIhBEhlUO7n05lisX3IzKCIsDeTubOVjfMb3kpTkkO/qE2iIwKTkRGfn5RYQkEIAABCEAAAt1FAJGxr5oM785S3i1ma2sqVjWxN6uhxUGVjPioST2qlwbVKF1qSjuBiEVw0xmhMSNTkL7nFKjHF6AnSZfyRU1UupR9rdFc3fXhQGR0l7+wFgIQgAAEIACB/BDoe5FhXJH27lLVw7uJUJzWoVW/ANw+uFcLsgvDYxrVjgad296mjGQYg0MpU0661MiGqilZfjG4m+pknoeRtvC7mt7lbdpA0bmf+mWuJYma5GfjJ7EEkZGEEm0gAAEIQAACEIBALYG+FxnNCwy2Ub8QQGT0i6dZJwQgAAEIQAACrSbQ1yKj1TAZr7cIIDJ6y5+sBgIQgAAEIACBzhFAZHSONTN1GQFERpc5DHMhAAEIQAACEMgNAURGblyBIXkjgMjIm0ewBwIQgAAEIACBbiGAyOgWT2FnxwkgMjqOnAkhAAEIQAACEOgRAoiMHnEky2g9AURG65kyIgQgAAEIQAAC/UEAkdEffmaVKQggMlJAowsEIAABCEAAAhCQhMhgG0CgDgFEBlsDAhCAAAQgAAEIpCOAyEjHjV59QACR0QdOZokQgAAEIAABCLSFACIjDdbNWQ0tDqq0OqEBr795svbiYEmrE3uaHZrS+uiStueO1Yy+tzKu4oI0U4p66neUMeZJ2lNaK5crF4dPndXqhD9zmgXkvE/4iebDpwKsO2U9IqNTpJkHAhCAAAQgAIFeI9DXIuPo0aNK+8RvIyo2Rrbl6AhzKJ6RFhzRYUTBonaGpOKCERL2lnEFw7qGmhQZixp0RIkZyxujjojJ/wZ1+VTXE7LYERglFSvrlTZnZ6W5OdVKtvauFpHRXr6MDgEIQAACEIBA7xLoe5FhXJtKaFjCYs8WHJ7I0Ki0M7gQjDiYCMiGNLq+4x2yGxy4nX0X0cY5iO9qervzB+/9fxTi1rynlfGidqc98bb/yfY1AiJjX/joDAEIQAACEIBAHxPoe5FhBEbaiIZJfZopSdtHpq3UKP8QPa3d4oZGKkLAHKBNuMO873+Tn1JkKHQYD6UXjS2fcyMszsttO7/lplu518Lz2j97/14qqjS1oK1y2elz8vy4bpjfcsYIpGtZcxcKY1py1uuNMXNE8/NrVh83lcxP/SqMLQdTypKIp6bm88JIMX2MGFxfP+LYrdkhTa65nIxte/cW9fjjj6f+9XD48GEdPHhQH73vft0+eSLROOvr6zp+/HiitjSCAAQgAAEIQAACeSWAyDh3zvFNOqERJRKq7x06HZVSdUinK+lCrRAZbvqUlqzUrUq6kSswSkVTK2LnbTUSGVNaH5px6yA2Z3V0cq0qLEw0xpnOEhN+atPmrMbPn6ytS4nrY38yAmlnJgvNFTaFwnB0elma+UJ9dmbCbIxBLp9790qIjLz+5sIuCEAAAhCAAARyTQCR4YmMNELDqcvQqNZ37CJw6wCvaq1GNaUqImpg1R/U7pYoIeJHRVY1YeYIpU5V6kUG6qVVNRIZ4RqQOj87c7vRDv/lRidMUKDeGDHCKjKSEeLZ7HyJbTTawhVUTiSjMKw9REauf3lhHAQgAAEIQAAC+SWAyEgbyajcYepaPRqoI7AP0Z4YmC6qtBgsDHcLn1NGMuzDeMTBvLMiI6o2pBkRY3844iNDUYLK7R0zX4QIi+wT4Oj6bbpU0g9+8IN9fXpJl9oXPjpDAAIQgAAEINClBBAZqWoyrEiCyUIKHFBDB95wulHgQJxGZITSo7y7TQXTpfyDf710qVBNh5POtFPnjleNBMOUalOOGvWpf3cp9xa/bo2EW1YSjvykmS9BH/u2xN4drkp7iIwu/b2G2RCAAAQgAAEIZEyg70WG4d/s3aVMpGBKwedgVN8LpwqZA/1pHVqtf2iOfwaGKyoqxdKV+gRr5wQKm/36Bf96sH+lKNxODRobi7njVZxg8AVWNWWqcbqUyUpyC6xrCr8rJlfTlsxb9QrNzbUk87kisJGN1QL5wvCYRrWje4lkZPzriekhAAEIQAACEOhWAn0vMpoVGN3qaOxunoC5hS3pUs1zowcEIAABCEAAAhDoa5GB+yEQRwCRwf6AAAQgAAEIQAAC6QggMtJxo1cfEMhKZPQBWpYIAQhAAAIQgEAfEBgdHU28yvHxcT399NM6cOCA81+hUFDhTW96U7lcLsv8d8kll2h1dTXxgPctn9H7b3934vY0hECnCGQhMjq1NuaBAAQgAAEIQAACeSKAyMiTN7ClrQQQGW3Fy+AQgAAEIAABCECgQgCRwWboGwKIjL5xNQuFAAQgAAEIQCBjAoiMjB3A9J0jkIXIWF9f79wCmQkCEIAABCAAAQi0kQA1GW2Ey9DdSyArkdHMB7J76WI5BCAAAQhAAAK9TMB8cdrMmYZIRi/vBtYWIIDIYENAAAIQgAAEIACBdAQQGam4BZ+ibYaoPEk71Xjt6GRs3NDItv+k8Zg5vKd/F4ZPqbQ6oYF2mJN0TOfp3CUVS6uayNQQCZGR1Gm0gwAEIAABCEAAAkECfS0yjh49qnRP/DYH+EUN+gdh52C8q+kkB/qO7cCkIsMVTFra1tyxjhlnTRRimYUJdeZEZOTIGZgCAQhAAAIQgEBXEeh7kWG81bzQCB+M83hQbkZkWIKp49s3j+xcCIiMjm8GJoQABCAAAQhAoEcI9L3IMAKj+YhG6GC8OauhjRFtO6EA95pGpfX1I1oy0Q0n0rGgrXLZ2TZ+atXm7JA2RvwIQkR05PQhrc4NaGW8qPmtYF9Zf8Xw6QAAIABJREFUYxYKY+48gU1piwxv7Jkjmp9fc1oNnzqr1Yk9J4qx5tnlvjcge2zb3tq1jWjDRHSWiipNueszazt5flw3zG9Z87h5T2a9k2vuOgpjy9qeU2D+6nvhKFEtO9+WwZo1tS7HKpci4/yyRq68U49JOvHQ87r3+ujfROeXR3TlnY9Ftglc0x26+JYzuuqex7Uxeah2sEcaXN/PL8K6Yz+iOy6+RWdCY9e1cT82pOwbxzflkNVu7WS+b+MYAAIQgAAEIJCMACLj3DmHVHNCI1iTETzku9d2Zkrugd0RHVY6kl1zsGeJk81ZjS/uSMUFp9/eyrhmtKDVQ6ctAeM7tVbkjJ8/6c1nt/FrMlwb1keXXCFkRJFjkhEmUVGZOvYORK9tfWjGreXwajsqYiUwj70h7TnjokIx7DxboteUbPM3apVHkeEfbo3tcYfu1CLDO+BWBEw7D7yNRMZV9+jxjUkZ6VNZ94mH9Hw9ZdXIoS28jshoIUyGggAEIACBniSAyPBERnNCI6omwy9WblyvUYlgDKxofEZaWJ3Q3uy4zo8UVVo0P1+rR90LmpAbBVFFtKgm0mBsd6MAdiwjIpJRKaaOOeRH1JdUIy6N0sQaXPdEiGNvYVgzjj0xfZy1B2tdktuy/89r/kTGeS2PXKk7dUIndEZnVD2Eh1ebWGSEIiGP3HGxbjkTHyXZP1lvhCZEhuSt/bGrdM/jG4oKurTMrgQDtVVkJJifJhCAAAQgAIG8E0BkpI5k2HUMe05K0+60SX1qQmQcM/2MmJjW7sx5nXTExWkdWhjUoic+/OQfE9kwKUhOqpURJw0LzXMmMgKCwV83IiP8CyL2A+mlSumex/UJvUdX3qnAgduOcvjj+hGJutesdKlTX7/SERiVl4ka3PhwMJ3KEwZ+m0o0xX//qqt01WOPOelc8iMRVoqX089/vymRUY1mVKIsjcY9cUI6cyZoi5m/QT9FrcGOpgQQeSlrKccM2+LwHLwvyLze2AqlleUkypP3P3rYBwEIQAACnSGAyGhFTUbgtqtJ0o+q3847aVElBdKkTu8e0c5gOP3JBDC8FCqvlqKakhW1WVKKjMj0Lt/efUQyTGrY4qCbVtWQly/gotKlktqy/w9Q3iIZrlDwhMWToVoJ/5DvHTQDEQlPSCjmmi8WaiIZthDwDr/+OFG1Hb6AUL2akIjxatO+vMOzlS7lagO3zsRt/6Rbt+EfrP2DuCWMwrak7eeImjiG13v2NmGLM+Zhr74mtE4FxFf9dT6kW3TLmXxEdvb/aWMECEAAAhDoNQJ9LzKMQ9PdXapaMF1N/TGjRdwtKVCk7acJeVsp/FyI8M+BFCOrwDtUTN6ydCljVl179yEyBtxojylgLwyPaVQ7GjTpYAPVgvBGhd/xnFt/l6p8iQw/XSj0K8g7oD4ZSnOyBcCNDwdToOIKv+NEhh/pqIkk2Ad776AdFASHaqIHkd/YV5YWLzICh/7wb+So6EuUAInpFxZRxtbw2iMFVpNjutEoXzRZRfdRwi5i7Mcvn3f6u8GhOoX7vfYXi/VAAAIQgEDXEOh7kdG8wOga32LoPgnkSmT4B+XKt97BGoXB++oLiaxFhn9ArxEW4bSgWJHhr/eEHnr+Xh0ORDVCd8UKp2FZIsM/mEceykPRIFsoxYmM23ftCEu0LVHCxRcZNXcJs+yvK0R8Vnb6Wjgiss/9T3cIQAACEIDAfgj0tcjYDzj69j6BPImMmshAKH0oeBiVWyD+mFvAHTwEB6/5aUD+obumoDkmvSny2/yaSMZDGlu7RXd6Bdu/+CfWgbwJkeFHWCrioFKn4IoOp379kWUtH57UpJdKFpm65acoKaZfRDQmjm8l7anJMTd+8U/c2xHHpUv5baLGruiZ6MhP739CWSEEIAABCOSZACIjz97BtkwJ5Edk1LmzUqXY2r3LlJ8yZUPzvyX3D+k112qek2EVE6cp/I5Kl/JrOUxaz1VX6bHHvBShRiIj4P2I2oNwQbS8Nr7ICC62euvbRv3qpHzVZWgUTsoxUxV+e+v0o1fuMqnNyPSXBZNDAAIQgEANAUQGmwICdQjkR2TgoqYItPPZHk0ZQmMIQAACEIBA/xJAZPSv71l5AwKIjC7dIoiMLnUcZkMAAhCAQC8RQGT0kjdZS0sJIDJairNzgyEyOseamSAAAQhAAAJ1CCAy2BoQqEMAkcHWgAAEIAABCEAAAukIIDLScaNXHxBAZPSBk1kiBCAAAQhAAAJtIYDIaAtWBu0FAoiMXvAia4AABCAAAQhAIAsCiIxU1M3TpatP/DZDjC2f09yxBoMFnuYd94TqetdSzptqjXRCZLAHIAABCEAAAhCAQDoCfS0yjh49qnRP/A6JAEc87Gp6e06NdEbVTWlFxqIGS6uaGEjn8Ma94uxq3LuXWiAyesmbrAUCEIAABCAAgU4S6HuRYWA3LzTCB/E0B3NERic3epq5EBlpqNEHAhCAAAQgAAEISH0vMozAaD6iERIIm7Ma2hjRtpMvFSdA7GtR0ZAFbZXLGj51SkcWShERiyhhsqeV8aJ2p7er6VrGnsVBlVYnNOBEWdxxC4UxLTnRFm+cmSOan19zPgfDp85qdWIvkAZWGFvW9tyAM/78VtlplygtrEc+WbkTGf4Tvh2+J/TQ8/fKPGy6ZS/nqdVrGnt8Q5OHJNlPFP+E9B77WssmjRrIPHV8Xpf7dgSaWNcUstduF15LS+2tY19b52zpAlIOltAvZu+0/BU3d5LJEu6benutLWtKYnen29TjnIZfs7abOW7RGf/p9XGf76aG3u/eaWoyr7E953ktj1ypOx9zL5146Hnd6/3ifuSOi3XLGff9q+55XBvOL177VY97zJoqfyfa8DciDQr69DUBRMa5c84GaE5oBGsjqod3M1IakeGOpyVXKOytjKu4IM3UpEXVmTcgcqTN2SFtjJixasXQ+PmTFTGxPrrkCiPT35neEiD+3KGx++nTkiuR4Rxgv65TvrA4v6zlJyc12VKVEf7jdotk/UHsnO/THGY7eZBIMleSNq0m2u45O+mX8Fz7XVua/mn6tNqnnR4vgchom+Aycz+sG1v95Ymy8KM95yN65JHrdb35XW3/Hg/8Dm+We6M1tYtlp/cj83U7AUSGJzKaExpRUYiSis7BPIXI0IrGZ6QFE3lwdlRc4XdUTYZpv6ERXySMn9fJUBTD36hudEKaHbLHaRxh0UxJq+0rBMnl5yhXIsN8OzV/uR7fmFTb/sbX+watMxNas3fyMJtm6zX6A2/GTNImzdxxfdo9Zyf9gsho9e5INl6zh91koyZr1a6Dcbs/F1Gri+MYJaRMtOM90ie8KHJlyLT+aBfLZJ6kFQR8AoiM1JEM+5BupyxlITLc6MeMFrSgGef/jiCoW5Ce1MbqB8WMf8P8Vt+nS91xxx269957a36D1Hv/4MGD+uh99+v2yROJfuvU/0CaPxq3aLsmpO79EXpoTGu33CkTkQ+E3Z1vztz3gylWUSF8/w/aKX39SpO24L7c8Z4MpjBFjls/LcBfvJ0eoBMP6Xk/b8Aa76p77tHQnWvVdKm616LtdcdVjL12yoI3xj1DuvNOd8U2v2h7G/3hD/KrrDOSWa3/TDrF7bsjutLLr6jaE8fX3R++z6LnDKZq2BuytX6peDulTVFr8fzZ9D63bfFT8ILfMjupeZH+D7e7RWfsPVsBWMcvAX9H7DlrLfV93sz+MBmO1fSb6ucrfo+73677vztCn73Iw25Sfv4391G/f+odzO0DeIw4qPt7rdGB39tbvh9jPpM6IZ05M6SHnr9RD9fdI/XWWMd282XRwzdWf+8F+EaJjwjWThppg9/7zpcc7YgKJfozRiMIVAggMlpRkxG4NW2oRsJJRdrxUp/qRQyaSZeqc3cpY8PMro5IGln173LljrtTE4VoXmSYHeMLmX6JaERFMoyYMC9baES953/CWicyzIjVw0w1r9f7o3nVPW6UI1AXEPpD98gdGtm9XRuTcnKE18bCOcD1/qCZuWOu+eMO3lfnD2iyP/x+atb5ZXPAlu6p/DGtpm3VXos6OEbZa6V+1TCyDo9OPrPJEgvXu8SxaXSQDdvj1ru4vjDi7Rad8f3n5VNXhIVtT90DStT8/pz11l3vr2Dtwbp5vwTkS6i+xt2vlTS8unUs4UNaaJ8H/FRvn9shuLjDWj3/+32cgiR9/VQ1l766QvczGf1ZarDnkvjc+dwl3B8Bl8YIpBp29T5f9fzYzNhWbVVlz9cLjYYPxo3EfLV2zP0sxY1r7Aj7sd6+cT+T1S90QsIk0d4Lfinj/t56zCjNCIHhisP5yxvUZPjCwvq9WPm9UfM5QmRwzs8Hgb4XGcYN6e4uVX1ORqEwHKyf2JzV0Um3oLowNqbR9R2viDsmLcnqE1/4HXw+h1uwbZKsXHGzcMSrs/D3l1X47drTKF3KremYXCu7bUc2qmupFI7nY/O224o4keELDV9ghIVHe0SGN6r37duQUy9R+4fY/MF6+Mbnde9hO4rh9TV/5G7fDdZ3VEAmFBlOQab/7WR4XEcd1P+DHyhev8oVEmY8J1PATwWz7Ii7VvNH1y4WD41h17M4Z3yPUQ2/2oPHxX5lpl+QGpg3yUEs/G2nxSwccalJswqvI45vyPZwHU9g3aFPT0v9EiMyEtsUJTLi/BuxH/0omWNOg2+EKzcZqG23fdVjUo0gtz+LVq2Uv/TYdTaxtpq91qBvlB/jxoj9fCXZ2zH21Ps9EfBLeI4EkYxQhMgZoc7h3R3dtbHGj3XHCUVBE3wmvZpud7qoSKq/TMc/294XKObNeiK10sES6fFfdFR/p/lrJpLR7jMC4zcm0Pcio3mB0RgqLXqDQL2aDFtY+CuNSqEy11obyahydb4Z+/qp2rQg74+W862rIzKSHYDsP8buXZ0aHR4ixq2cu9xv7ey7qDiXAgcvKwc5ryLDOST567RzppN8w9r4wF/LPHwYjvrZYKzDN3wYSnqgb7lf6h1Ow3vAI1ARfDH9Gh706u/H+L0dd2h3v8HevuoqPTZkPmsRd1mIYFy718PrbJPISLxfk4r4ev5o5suIRn4Jz5FUZDQ7boQf6/kubq85wZL4LzCiP9fVdVbFQL06jDTcXbFSjbYRyeiNU0j3r6KvRUb3u48VtJNAXOF3owiGb1fLRMYjy1o+POneWjbw7VcotB/4w+kdkmoiC3EpHsnTj2rrQ4Ii6D36RDCiYRevR6QsNZ+Wk/Cw4wimcOqKf0iJOfA9aRXbx6WhVZbdyJ6YmprIb9KjRYar10ZUwzfycFRv3dYnp+V+aSQWEtjUzEHP82/cftxPJMOI7sH76qWzNJMulWDPhQ+xzUQyEu/X8D7db7pUnQhTXb/EifR6IqPW5rr1aTW3vq72Dfqx3u/HZkVgg8/1k4/okeuv9243bo1t/FW3PiOmfshKl6owqBFMiIx2ng0YOzkBREZyVrTsMwKN7i5Vr9jbxtQykeHnZvuDV9ID3D9abpGiV95t33Y2nBIQ6FctFHajDo0OydZhImrcGx9WNbUo6h7tVoHsVSd0Qtu63L+bipXmUVP4Xfda8DBQKXptWPjtpWnVHOjCh/p69iaJZFhFuJFFpvXSKhqInkrqVvQ98IMMrveiR34qkb1ue5e22i/BXxTpbArza5DCUnef+7bU29uNIhn+nvcYyat9CizRPaz6RfeVCF7ApqR7LrwHmznwJt2voTHjPnsNBXQD+yL9Eval7aMkIiMi/TAuRSkgWEN+TGTfPtcYShvz90elTsPaS7U32Yjft3V/71P43WenlfwuF5GRX99gWcYEGomMJOa1TmTUm63egTeJdbSBAAQgkBcCfPveOk/AsnUsGWk/BBAZ+6FH354mgMjoafeyOAhAIFcE/IhQvYhbrozNrzE88Tu/vulDyxAZfeh0lpyMACIjGSdaQQACEIAABCAAgTABRAZ7AgJ1CHSHyMB9EIAABCAAAQhAIH8EEBn58wkW5YQAIiMnjsAMCEAAAhCAAAS6jkBuRIY50PGCQJ4I/OAHP9i3Oe0v/N63iQwAAQhAAAIQgAAEWk4gNyLjxz/+8b4X9+STT+57DAbIH4HDhw/nz6iEFiEyEoKiGQQgAAEIQAACPUUAkdFT7uzNxSAyetOvrAoCEIAABCAAgd4lgMjoXd/2zMoQGT3jShYCAQhAAAIQgECfEEBk9Imju3mZiIxu9h62QwACEIAABCDQjwS6RmTccccdFf/ce++9kb6iJqM3t3ArRUaSfdRKitRktJImY0EAAhCAAAQg0C0EWiIyrr76X5bL5bLK5b/Xq171Sj3wwCcTr/++5TN6/+3vVlzhd9KDISIjMfauathKkWEWnnQ/tQISIqMVFBkDAhCAAAQgAIFuI9CsyHjXu/6Vnnvu2zpw4IAOHHiJ8/9CO0VGMwdCREa3bb9k9rZaZHRSaCAykvmYVhCAAAQgAAEI9BaBXIuMZgSGcQsio7c2p7+adoiMTgkNREZv7klWBQEIQAACEIBAPIFci4xmD4KIjN7c7u0QGc0K2LRkERlpydEPAhCAAAQgAIFuJpB7kdGM0EBkdPNWrG97q0VGpwSGWREiozf3JKuCAAQgAAEIQKDLIxm++UkOhoiM3tzurRQZSfZRKykiMlpJk7EgAAEIQAACEOgWAl0RyUgKE5GRlFR3tWulyOj0yhEZnSbOfBCAAAQgAAEI5IEAIiMPXsCGWAKIDDYIBCAAAQhAAAIQ6C4CiIzu8ldfWovI6Eu3s2gIQAACEIAABLqYACKji53XL6YjMvrF06wTAhCAAAQgAIFeIdBTIqNXnMI6eocANRm940tWAgEIQAACEIBAcgK5ERnJTaYlBLqLwEfvu1+3T55IZHSzH8hEg9IIAhCAAAQgAAEIdJhAs2ead73rX+m5576tAwcO6MCBlzj/L1x99b8sl8tllct/r1e96pV64IFPJl7GfctnErelIQS6lQAio1s9h90QgAAEIAABCKQhkLnISGM0fSDQqwSa/UD2KgfWBQEIQAACEIBAdxNo9kzT8khGd+PDegi0loD5QPKCAAQgAAEIQAACvUBgdHQ08TIQGYlR0RACEIAABCAAAQhAAAIQSEIAkZGEEm0gAAEIQAACEIAABCAAgcQEIkXGW996TdkUfZvi71e+8mI98MAfJB6QhhCAAAQgAAEIQAACEIBAfxO47bZf03PP/c/g3aWGhn7Gu7tUWZdddpnW1v6ovymxeghAAAIQgAAEIAABCEAgMYGxsZv11FNP68CBggoFcxvbggqIjMT8aAgBCEAAAhCAAAQgAAEIhAggMtgSEIAABCAAAQhAAAIQgEBLCSAyWoqTwSAAAQhAAAIQgAAEIAABRAZ7AAIQgAAEIAABCEAAAhBoKQFERktxMhgEIAABCEAAAhCAAAQgECkyuIUtGwMCEIAABCAAgbQEPvvZz6bt2lf9rrvuuqbWC9dkuJrl+sQTTyQbuM9bXXHFFU0R4Ba2TeGiMQQgAAEIQAACjQiYw/Bb3vKWRs36+vpf/MVfqNnDMFwbb5k0XI3IuPDCCxsP3sctXnjhBTUrMkiX6uMNw9IhAAEIQAAC7SDAYbgx1TSHYbi2hysiozFXREZjRrSAAAQgAAEIQKDNBDgMNwaMyGjMKE2LNFwRGY1JIzIaM6IFBCAAAQhAAAJtJoDIaAw4zWEYru3hishozBWR0ZgRLSAAAQhAAAIQaDMBDsONASMyGjNK0yINV0RGY9KIjMaMaAEBCEAAAhCAQJsJIDIaA05zGIZre7giMhpzRWQ0ZkQLCEAAAhCAAATaTCDTw/Dn7tTrTzxQWeHP3fV5/fHEgPfz53Tn6z+uN3z+j+W+taeVm9+uD15+Rn99zzVtphIcPj8iw2Pwf3v2/dxd+vwfT8gn1l4oYX/sf7Y0XNstMp79ylk9oSt0w5su3f8C9ay+cnZXL3vbL2jwZS0YLuEQiIyEoGgGAQhAAAIQgED7CGQmMhyB8XXdFRIRn36nLzSCh9rP3fl6ffwNtghpH5PwyGkOwy3nureim9/+QV1+5q9V0Vh7K1r5qwlNdERz9YHIeHFXX3ziRV2oF/SyK1ohDHpEZPzUT71GL3nJAa2t/VHnPnXMBAEIQAACEIBAVxNo+WE4EQ33G/lvvNc6MDvBCnOQ/obe+9f36BpVD7XXPnqz3v6N93Y8guEvJXuRUYdXItatatT7IuPF3S86UYwr9ITz/1/Yd/ihe0TGr/3acZ079zUdOFBQoXBAl156mQpDQz9TLpfLMv9ddtlliIxWfZYYBwIQgAAEINAHBDIRGQExYUM2h+n3Sb9vUqS8Q+1dl+uDn35DB9OCap2eucioy6tqq4n0VDLPbvNTyiyGH3TT0oIpacH0q9v8KIkXNXGzsm7TmZDoq2S07fPzkYZr+9KlXtTuF5+QTARDJqJh/jkoN8vJEwtXXKpnn/iGXpB04Rve5omQBNfedoX0xBf04uANqmRhPfsVnd19md5WmWOfMK3uLUuXuuaad5SfffYZREbrfMNIEIAABCAAgb4hkJnIcLREuJ7A/sbeHJBPyByNK4ffjLyS5jDcUq7m0B/JKwqIHXHwGPqiw0lRkycaXNbV9DR/rFDE4nN36ua/+j/0xxN/FaqR2b8z0nBtm8hwUqV8YWEJDkdlGCHxhL514RtcUWDafuFZXerUWjS65tVkvPAVnX3ukkqth6n9eO4SS3TsH2dlhP2IjNe85hJ997vfcSMaRDJa6BWGggAEIAABCPQZgZYehpOyayaScead+vSJT+udldqNpJO0rl2aw3BLuSaIZChQRP9zXq1LOMXJ+ll2aprFKhDF8N53RIp6WmT4qVJ+ipT5+QsvDnqioDbtqSoSkl4z7Z7TJTe8SZca0fLF/6XBNkQxjMf2IzL8dKmAyKAmo3W/TBgJAhCAAAQg0C8EWnoYTgytuZqMib+yv4FPPEnLGmYuMrw7a9XUsPgrDIiQiJSzikBLKjL8uhgbYS/XZHjRiJod89O6whcFgbtEmUiHn/4UFhn1r7W+5iN6i6cRGdRktOzXBQNBAAIQgAAEIGAIZCMyJPebdz91x1jipvZ8vXIb2+Chdm/lZr390+/MpDYje5Hh83ogmDrm311Kd+r1H/fqVhzB4Ud+YiIZA3HpUrYf/M9JD4uMyPqIsFh4Qi/4dRhOutSLGqwIkLhr1i1sW373qtaJjLGxm/XUU09XCr9Jl+LvAwQgAAEIQAAC+yKQmchwdEXwORnB2ovaQ61T3Pz1Tj4bwkWbC5FhDAmnMlWek2EVcP/cbbpNX9cb7OL5qEiG83CNat2L+Sm68Nu50NPpUib1afdlfiF39eNUTZmS87wL/bT0rW+Zsm/pp6/w6yncSEbcNfs5Ga19DgciY1+//OgMAQhAAAIQgED7CGQqMtq3rJaOnBuR0dJVZT9YGq5tK/yOxRF3K9rmblPbzoJvfwlp0qWIZGT/ecACCEAAAhCAQE8RQGQ0dmeawzBc28O1q0VG4A5WjfmkbYHISEuOfhCAAAQgAAEItIwAh+HGKBEZjRmlaZGGa3eKDLe+4xsvXKg3OLe9TUMreR9ERnJWtIQABCAAAQhAoE0EEBmNwaY5DMO1PVyzERmN15KnFoiMPHkDWyAAAQhAAAJ9SoDDcGPHIzIaM0rTIg1XREZj0oiMxoxoAQEIQAACEIBAmwkgMhoDTnMYhmt7uCIyGnNFZDRmRAsIQAACEIAABNpMwByGeTUmcN111zVuZLWAazJczXI1IoNXYwJXXHFF40ZWC+4u1RQuGkMAAhCAAAQgAAEIQAACjQggMhoR4joEIAABCEAAAhCAAAQg0BQBREZTuGgMAQhAAAIQgAAEIAABCDQiECkyrrnmHeVnn31G5bJ02WWXam3tjxqNw3UIQAACEIAABCAAAQhAAAIOgToi43pPZJQRGWwUCEAAAhCAAAQgAAEIQKApArbIOHDggAqFggrXXIPIaIoijSEAAQhAAAIQgAAEIACBCgEjMr75zacdcYHIYGNAAAIQgAAEIAABCEAAAvsmUBUZB3TgQEGFwgEiGfumygAQgAAEIAABCEAAAhDoYwKRIuPaa68vP/PMM5LKuvRSCr/7eH+wdAhAAAIQgAAEIAABCDRNwBUZ3wqmS1177Uj52We/pXIZkdE0UTpAAAIQgAAEIAABCECgzwn4IqOSKmUKv12RYW5ha0TGJdzCts83CcuHAAQgAAEIQAACEIBAMwQQGc3Qoi0EIAABCEAAAhCAAAQg0JCAERlPP23Spbzb15pIxnXX/WL5mWf8dKlLGg5iajekgtPuzW9+o173utfpqaee0l/+5Ved92666Ubn/5/61MMJxqIJBCAAAQhAAAIQgEBSAi996cv0ox+9GNk87prp8LKXvUx/+7d/a/Ud1HXHr9ZrK+88rT/7L4/qG/Le/+aX9F8+uyu94Vodf6usaz+jHz68ri9/x3Q0bf2f3X4XbZe09uXvhq7JGWfs4q941+wlvEo/P1bU0EXSN//sD/XZb/jjXi35P7/6LRq78bX6pjNveM44e+JtrT/+1Xpt5PqTeqo32r3uda/Va17zU85ivv3t/6mnnvpmYGEXXHCBXnzR3Y9GZLjpUt7dpWyRYRqYtKly+e+9/0sf+MCsfvKTnzg/z839rvNkcPN65ztv0Bvf+EZ99atf1ac/fbYy4ezsv3P+PTf3kd6gyyogAAEIQAACEIBATgi8/OWv0A9+8P1Ia+KumQ6vfOUr9MIL/8vq+881tTSi5z7yIf3RX9tDht+3f27i2utv1t3/7hq9xh76//mvmlr682iaXvtvf/K9Wnra9H2NNqY+oT/zWr916uN681++V0t/ltIeWf2UdHwzeT1OOdkUbTbjZ3/2Z1QoSF/96pbzf/t10UUX6nvf+77zvisuPIHhRzL8mgwjJEykwhUa5j/p7rs/oLvu+pA1Xlm//Ms3OQIj7vWJClf7AAACn0lEQVQf/sOH27xkhocABCAAAQhAAAL9ReCii16pH/7we5GLjrvmioxXhkTGW/Xe+39Jz/7H39FDAZERft/+uYlrrx/Xf/z3l+jsu/+T/jShm15/y4f07y/9jN79P366pu+/eO8ndOXj79HH/zSlPbL6qda26PGN4fU4JVxUzzVzlYYRFhdeaETG9wIiw2Q8OWLjHe/4JSddyhUXfiTDDVcYofHhD39Iv/3bH6hEMMz7N9/8y7riiitikX3gA3f3HFIWBAEIQAACEIAABLIkcPHFr9Lzz5tUpNpX3DXT+lWvepV++MMXrI6/oPf9wY169u479cB5e7zw+/bPzV6b0KWf+ZB+84G9aGxv/1Xd9tR/9+Yf0G2/9zt681+a9q/V+/5gQvrPE/r9z0s69Kv6vbsv1cP/+v/U52Xb4Pa59GGv3dv/rf7g31yqzzhramRrkvGN2fU4ZbkTOjt3OILhzl6QG8kw+9EIC/e9SkSjKjIcWVERGm7nsj7ykXsqkY3f+q3fdt4zr/Hxm/WWt7xFX/ziF/XpT5c6u1JmgwAEIAABCEAAAn1I4OKLX63nn3eKIWpecddckfHqkMh4m37zwZO60hrpmYc/oN/4w9fpNx/83/XM7Iz+0BEfpl3152O/+Um9x3R6/LRu/T1Z14LtnGEP3aaPzRV1mT+H0+cL1owhG+zrgb7P6uE69ujY+/Xge7wvvx9/Qo9feVnF9vq2hm2LGT+0/j7cdjVL9kXHRRddpO9+1xW9tshwfjYiw0+X8kdw06bMyxUd9stcMwrFvG699Rb9/M//vL785S/rwQcfgjkEIAABCEAAAhCAQBsJvOIVr9b3vx8tMuKuGZNe/WojMn7YRusYuj8IVAszXv7yi/Sd77j70RcZ7r8L+v8B7+IER6Ehv1UAAAAASUVORK5CYII=">


                      </ul>
                  </div>
                </div>
                </div>
                <?php }?>
                <?php if ($_smarty_tpl->tpl_vars['status']->value==6){?>
                <div class="card card-lg">
                  <div class="card-body">
                    <div class="markdown">
                      <div>
                        <div class="d-flex mb-3">
                          <h1 class="m-0">Инициализация библиотеки</h1>
                        </div>
                        <div class="example no_toc_section">
                          <div class="example-content">
                            
       
                            #include "AutherLibrary.h"
                            <br>
                            <br>
                          	AutherLibrary::Initialize(PUBLICTOKEN, PRIVATETOKEN); //Вызывать один раз, например при запуске приложения.

                            
                          </div>
                        </div>
                      </div>
                      <h2 id="cursor-utilities">Аргументы</h2>
                      <ul>
                        <li>
                          <code class="language-plaintext highlighter-rouge">Public Token</code>
                          - строка, можно получить в профиле.
                        </li>
                        <li>
                          <code class="language-plaintext highlighter-rouge">Private Token</code>
                          - строка, можно получить в профиле.
                        </li>
                      </ul>
                  </div>
                </div>
                </div>
                <?php }?>
                <?php if ($_smarty_tpl->tpl_vars['status']->value==7){?>
                <div class="card card-lg">
                  <div class="card-body">
                    <div class="markdown">
                      <div>
                        <div class="d-flex mb-3">
                          <h1 class="m-0">Авторизация</h1>
                      </div>
                      <h2 id="cursor-utilities">Аргументы функции AutherLibrary::Auth()</h2>
                      <ul>
                        <li>
                          <code class="language-plaintext highlighter-rouge">License Key</code>
                          - строка, можно сгенерировать в профиле.
                        </li>
                        <li>
                          <code class="language-plaintext highlighter-rouge">HWID</code>
                          - строка, идентификатор компьютера, можно получить с помощью библиотеки.
                        </li>
                      </ul>
                      <h4 id="cursor-utilities">Возвращает bool. true - при успешной активации/авторизации, false - при иных ответах от сервера.</h4>
                    </div>
                    <h2 id="cursor-utilities">Пример использования</h2>
                    <div class="example no_toc_section">
                      <div class="example-content">
                        
   
                        #include "AutherLibrary.h"
                        <br>
                        <br>
              
                          std::string key; std::cout << "Enter key: "; std::cin >> key;
                          <br>                            <br>
                          if (AutherLibrary::Auth(key.c_str(), AutherLibrary::GetHwid()))
                          <br>
                          {
                            <br>
                                std::cout << "Loggined" << std::endl;
                            <br>
                          }
                        
                        
                      </div>
                    </div>


                    <div class="hr-text hr-text-center">
                      <span>Получение HWID</span>
                    </div>


                    <div>
                      <div class="d-flex mb-3">
                        <h1 class="m-0">Получение HWID</h1>
                    </div>
                    <h4 id="cursor-utilities">Возвращает string.</h4>
                  </div>
                  <h2 id="cursor-utilities">Пример использования</h2>
                  <div class="example no_toc_section">
                    <div class="example-content">
                      
 
                      #include "AutherLibrary.h"
                      <br>
                      <br>
                          std::cout << AutherLibrary::GetHwid() << std::endl;
                      <br>
            
                      
                      
                    </div>
                  </div>

                  <div class="hr-text hr-text-center">
                    <span>Получение даты конца подписки</span>
                  </div>


                  <div>
                    <div class="d-flex mb-3">
                      <h1 class="m-0">Дата конца подписки (Человеческий формат)</h1>
                  </div>
                  <h4 id="cursor-utilities">Возвращает string.</h4>
                </div>
                <h2 id="cursor-utilities">Пример использования</h2>
                <div class="example no_toc_section">
                  <div class="example-content">
                    

                    #include "AutherLibrary.h"
                    <br>
                    <br>
                    // Функция работает только после успешной авторизации.
                    <br>
                        std::cout << AutherLibrary::ExpireDateHumanReadable() << std::endl;
                    <br>
          
                    
                    
                  </div>
                </div>

                <div class="hr-text hr-text-center">
                  <span>Получение даты конца подписки (Timestamp)</span>
                </div>


                <div>
                  <div class="d-flex mb-3">
                    <h1 class="m-0">Дата конца подписки (Timestamp)</h1>
                </div>
                <h4 id="cursor-utilities">Возвращает string.</h4>
              </div>
              <h2 id="cursor-utilities">Пример использования</h2>
              <div class="example no_toc_section">
                <div class="example-content">
                  

                  #include "AutherLibrary.h"
                  <br>
                  <br>
                  // Функция работает только после успешной авторизации.
                  <br>
                      std::cout << AutherLibrary::ExpireDateTimeStamp() << std::endl;
                  <br>
        
                  
                  
                </div>
              </div>

              <div class="hr-text hr-text-center">
                <span>Создание лога</span>
              </div>


              <div>
                <div class="d-flex mb-3">
                  <h1 class="m-0">Создание лога</h1>
              </div>
              <h4 id="cursor-utilities">Возвращает bool.</h4>
            </div>
            <h2 id="cursor-utilities">Аргументы функции AutherLibrary::CreateLog()</h2>
                      <ul>
                        <li>
                          <code class="language-plaintext highlighter-rouge">License Key</code>
                          - строка, можно сгенерировать в профиле.
                        </li>
                        <li>
                          <code class="language-plaintext highlighter-rouge">Message</code>
                          - строка, сообщение которое будет добавлено в логи.
                        </li>
                        <li>
                          <code class="language-plaintext highlighter-rouge">Tag</code>
                          - строка, тэг лога, не обязателен.
                        </li>
                      </ul>
            <h2 id="cursor-utilities">Пример использования</h2>
            <div class="example no_toc_section">
              <div class="example-content">
                

                #include "AutherLibrary.h"
                <br>
                <br>
                    AutherLibrary::CreateLog("key", "message", "tag")
                <br>
      
                
                
              </div>
            </div>

              <div class="hr-text hr-text-center">
                <span>Ответ от сервера</span>
              </div>


              <div>
                <div class="d-flex mb-3">
                  <h1 class="m-0">JSON-ответ от сервера</h1>
              </div>
              <h4 id="cursor-utilities">Возвращает string.</h4>
            </div>
            <h2 id="cursor-utilities">Пример использования</h2>
            <div class="example no_toc_section">
              <div class="example-content">
                

                #include "AutherLibrary.h"
                <br>
                <br>
                // Функция работает только после попытки авторизации.
                <br>
                    std::cout << AutherLibrary::GetFullJsonResponse() << std::endl;
                <br>
      
                
                
              </div>
            </div>

                  </div>
                </div>
                </div>
                <?php }?>
              </div>
          </div>
        </div>

        <footer class="footer footer-transparent d-print-none">
          <div class="container">
            <div class="row text-center align-items-center flex-row-reverse">
              <div class="col-lg-auto ms-lg-auto">
                <ul class="list-inline list-inline-dots mb-0">
                  <li class="list-inline-item"><a class="link-secondary" href="https://t.me/pers0na2tg"> <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 10l-4 4l6 6l4 -16l-18 7l4 2l2 6l3 -4" /></svg> pers0na2tg</a></li>
                </ul>
              </div>
              <div class="col-12 col-lg-auto mt-3 mt-lg-0">
                <ul class="list-inline list-inline-dots mb-0">
                  <li class="list-inline-item">
                    Copyright © 2021
                    <a href="." class="link-secondary">Quarc.me</a>.
                    All rights reserved.
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
</body><?php }} ?>