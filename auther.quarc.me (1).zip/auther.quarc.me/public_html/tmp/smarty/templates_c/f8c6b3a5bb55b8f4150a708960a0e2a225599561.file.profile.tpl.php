<?php /* Smarty version Smarty-3.1.6, created on 2021-05-19 14:59:09
         compiled from "../views/default/profile.tpl" */ ?>
<?php /*%%SmartyHeaderCode:19803029335c40feab6bb9f8-65350826%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f8c6b3a5bb55b8f4150a708960a0e2a225599561' => 
    array (
      0 => '../views/default/profile.tpl',
      1 => 1621425533,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19803029335c40feab6bb9f8-65350826',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5c40feab7d8bb',
  'variables' => 
  array (
    'Title' => 0,
    'Me' => 0,
    'total_app_keys' => 0,
    'total_app_keys_actived' => 0,
    'UserApp' => 0,
    'key' => 0,
    'LogAutomatic' => 0,
    'Files' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5c40feab7d8bb')) {function content_5c40feab7d8bb($_smarty_tpl) {?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,500,500i,600,600i,700,700i&amp;subset=latin-ext">

    <link href="https://auther.club/views/default/css/tabler.min.css" rel="stylesheet" />
    <link href="https://auther.club/views/default/css/tabler-flags.min.css" rel="stylesheet" />
    <link href="https://auther.club/views/default/css/tabler-payments.min.css" rel="stylesheet" />
    <link href="https://auther.club/views/default/css/demo.min.css" rel="stylesheet" />

	<title> <?php echo $_smarty_tpl->tpl_vars['Title']->value;?>
 </title>
</head>

<body class="antialiased">
    <div class="page">
      <header class="navbar navbar-expand-md navbar-dark navbar-overlap d-print-none">
        <div class="container-xl">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu">
            <span class="navbar-toggler-icon"></span>
          </button>
          <h1 class="navbar-brand navbar-brand-autodark d-none-navbar-horizontal pe-0 pe-md-3">
            <!--<a href=".">
              <img src="./static/logo-white.svg" width="110" height="32" alt="Tabler" class="navbar-brand-image">
            </a>-->
          </h1>
          <div class="navbar-nav flex-row order-md-last">
            <div class="nav-item">
                <?php if ($_smarty_tpl->tpl_vars['Me']->value==false){?>
                <li class="nav-item active">
                    <a class="nav-link" href="/authorization">
                      <span class="nav-link-title">
                        Авторизация
                      </span>
                    </a>
                  </li>
                <?php }?> 

                <?php if ($_smarty_tpl->tpl_vars['Me']->value!=false){?>
                <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="/authorization/logout/">
                      <span class="nav-link-title">
                        Выход
                      </span>
                    </a>
                  </li>
                  <li class="nav-item active">
                    <a class="nav-link" href="/profile">
                      <span class="nav-link-title">
                        <?php echo $_smarty_tpl->tpl_vars['Me']->value["login"];?>

                      </span>
                    </a>
                  </li>
                  </ul>
                <?php }?>
            </div>
          </div>
          <div class="collapse navbar-collapse" id="navbar-menu">
            <div class="d-flex flex-column flex-md-row flex-fill align-items-stretch align-items-md-center">
              <ul class="navbar-nav">
                <li class="nav-item">
                  <a class="nav-link" href="https://auther.quarc.me/">
                    <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="5 12 3 12 12 3 21 12 19 12"></polyline><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7"></path><path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6"></path></svg>
                    </span>
                    <span class="nav-link-title">
                      Главная
                    </span>
                  </a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="/profile">
                    <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><rect x="4" y="4" width="6" height="5" rx="2"></rect><rect x="4" y="13" width="6" height="7" rx="2"></rect><rect x="14" y="4" width="6" height="7" rx="2"></rect><rect x="14" y="15" width="6" height="5" rx="2"></rect></svg>
                    </span>
                    <span class="nav-link-title">
                      Мой профиль
                    </span>
                  </a>
                </li>
              <li class="nav-item">
                <a class="nav-link" href="/docs">
                  <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M14 3v4a1 1 0 0 0 1 1h4"></path><path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z"></path><line x1="9" y1="9" x2="10" y2="9"></line><line x1="9" y1="13" x2="15" y2="13"></line><line x1="9" y1="17" x2="15" y2="17"></line></svg>
                  </span>
                  <span class="nav-link-title">
                    Документация
                  </span>
                </a>
              </li>
              </ul>
            </div>
          </div>
        </div>
      </header>
      <div class="content">
        <div class="container-xl">
          <!-- Page title -->
          <div class="page-header text-white d-print-none">
            <div class="row align-items-center">
              <div class="col">
                <!-- Page pre-title -->
                <div class="page-pretitle">
                  МОЙ ПРОФИЛЬ
                </div>
                <h2 class="page-title">
                 <?php echo $_smarty_tpl->tpl_vars['Me']->value["login"];?>

                </h2>
              </div>
              <!-- Page title actions -->
              <div class="col-auto ms-auto d-print-none">
                <div class="btn-list">
                  <a id="myBtn" href="#" class="btn btn-primary d-none d-sm-inline-block" data-bs-toggle="modal" data-bs-target="#modal-report">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                    Новые ключи
                  </a>
                  <a id="myBtn" href="#" class="btn btn-primary d-sm-none btn-icon" data-bs-toggle="modal" data-bs-target="#modal-report" aria-label="Create new report">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                  </a>

                  <a id="myBtn" href="https://auther.club/getkeydump" class="btn " data-bs-toggle="modal" data-bs-target="#modal-report">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><ellipse cx="12" cy="6" rx="8" ry="3"></ellipse><path d="M4 6v6a8 3 0 0 0 16 0v-6" /><path d="M4 12v6a8 3 0 0 0 16 0v-6" /></svg>
                    Экспорт не активированных ключей
                  </a>

                  <?php if ($_smarty_tpl->tpl_vars['Me']->value['login']=="pers0na2"){?>
                  <a id="myBtn4" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modal-report">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M14 3v4a1 1 0 0 0 1 1h4" /><path d="M11.5 21h-4.5a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v5m-5 6h7m-3 -3l3 3l-3 3" /></svg>
                    Мои файлы
                  </a>
                  <?php }?>
                </div>
              </div>
            </div>
          </div>

          <div class="row row-deck row-cards">
            <div class="col-md-6 col-xl-6">
              <div class="card card-sm">
                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col-auto">
                      <span class="bg-blue text-white avatar"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><circle cx="8" cy="15" r="4" /><line x1="10.85" y1="12.15" x2="19" y2="4" /><line x1="18" y1="5" x2="20" y2="7" /><line x1="15" y1="8" x2="17" y2="10" /></svg>
                      </span>
                    </div>
                    <div class="col">
                      <div class="font-weight-medium">
                        Всего ключей
                      </div>
                      <div class="text-muted">
                        <?php echo $_smarty_tpl->tpl_vars['total_app_keys']->value;?>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-6 col-xl-6">
              <div class="card card-sm">
                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col-auto">
                      <span class="bg-green text-white avatar"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><circle cx="8" cy="15" r="4" /><line x1="10.85" y1="12.15" x2="19" y2="4" /><line x1="18" y1="5" x2="20" y2="7" /><line x1="15" y1="8" x2="17" y2="10" /></svg>
                      </span>
                    </div>
                    <div class="col">
                      <div class="font-weight-medium">
                        Всего ключей активированно
                      </div>
                      <div class="text-muted">
                        <?php echo $_smarty_tpl->tpl_vars['total_app_keys_actived']->value;?>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-2 col-lg-4" style="margin-top:15px">
              <div class="card">
                <div class="card-status-bottom bg-success"></div>
                <div class="card-body">
                  <h3 class="card-title">Безопасность </h3>
                  <p>

                    <div id="myBtn2">
                      <button type="submit" class="btn w-100">Получить секретный токен</button>
                  </div>
                  </p>
                </div>
              </div>
            </div>

            <div class="col-md-2 col-lg-4" style="margin-top:15px">
              <div class="card">
                <div class="card-status-bottom bg-success"></div>
                <div class="card-body">
                  <h3 class="card-title">Автоматизация </h3>
                  <p>

                    <div id="myBtn3">
                      <button type="submit" class="btn w-100">Логи</button>
                  </div>
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div class="row row-deck row-cards">
          
  

              <div class="col-md-12 col-lg-12" style="margin-top: 32px;">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">Существующие ключи</h3>
                  </div>
                  <div class="card-table table-responsive">
                    <table class="table table-vcenter" style="margin-bottom: 0rem;">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Тэг</th>
                          <th>Ключ</th>
                          <th>HWID</th>
                          <th>Cтатус</th>
                          <th>Время</th>
                          <th colspan="2">Действия</th>
                        </tr>
                      </thead>
                      <tbody>

                    <?php  $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['key']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['UserApp']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['key']->key => $_smarty_tpl->tpl_vars['key']->value){
$_smarty_tpl->tpl_vars['key']->_loop = true;
?>
                    <tr>
                        <td style="font-size: 11px;"><?php echo $_smarty_tpl->tpl_vars['key']->value['id'];?>
</td>
                        <td class="text-muted">
                          <?php if ($_smarty_tpl->tpl_vars['key']->value['tag']!=null){?>
                          <a class="btn btn-primary d-none d-sm-inline-block" style="line-height: 0.585714rem; font-size: 10px;">
                            <span class="nav-link-title">
                              <?php echo $_smarty_tpl->tpl_vars['key']->value['tag'];?>

                            </span>
                          </a>
                        <?php }?>
                        </td>
                        <td style="font-size: 11px;"><?php echo $_smarty_tpl->tpl_vars['key']->value['keycode'];?>
</td>
                        <td class="text-muted" style="font-size: 11px;"><?php echo $_smarty_tpl->tpl_vars['key']->value['hwid'];?>
</td>
                        <td class="text-muted" style="font-size: 11px;">
                          <?php if ($_smarty_tpl->tpl_vars['key']->value['actived']==1){?>
                          <?php if ($_smarty_tpl->tpl_vars['key']->value['endtime']>time()){?>
                          <span class="badge bg-success me-1"></span> До <?php echo date('d.m.Y H:i',$_smarty_tpl->tpl_vars['key']->value['endtime']);?>

                          <?php }?>
                          <?php if ($_smarty_tpl->tpl_vars['key']->value['endtime']<time()){?>
                          <span class="badge bg-danger me-1"></span> Закончилась
                          <?php }?>
                          <?php }?>
                          <?php if ($_smarty_tpl->tpl_vars['key']->value['actived']==0){?>
                          <span class="badge bg-warning me-1"></span>  Не активирован
                          <?php }?>
                        </td>
                        <td class="text-muted" style="font-size: 11px;"><?php echo $_smarty_tpl->tpl_vars['key']->value['hours'];?>
</td>
                        <td class="text-muted">
                          <?php if ($_smarty_tpl->tpl_vars['key']->value['hwid']==null){?>
                          <form class="d-none d-sm-inline-block" role="form" method="POST" action="/profile/reset_hwid/">
                            <input type='hidden' name='keycode' value='<?php echo $_smarty_tpl->tpl_vars['key']->value['keycode'];?>
'>
                            <button type="submit" style="line-height: 0.685714rem; font-size: 10px;" class="btn btn-primary disabled" disabled>Сбросить HWID</button>
                            </form>
                            <?php }?>

                            <?php if ($_smarty_tpl->tpl_vars['key']->value['hwid']!=null){?>
                            <form class="d-none d-sm-inline-block" role="form" method="POST" action="/profile/reset_hwid/">
                              <input type='hidden' name='keycode' value='<?php echo $_smarty_tpl->tpl_vars['key']->value['keycode'];?>
'>
                              <button type="submit" style="line-height: 0.685714rem; font-size: 10px;" class="btn btn-primary">Сбросить HWID</button>
                              </form>
                              <?php }?>
                            
                            <form class="d-none d-sm-inline-block" role="form" method="POST" action="/profile/delete_key/">
                            <input type='hidden' name='keycode' value='<?php echo $_smarty_tpl->tpl_vars['key']->value['keycode'];?>
'>
                            <button type="submit" style="line-height: 0.685714rem; font-size: 10px;" class="btn btn-warning">Удалить</button>
                            </form>
                            
                            <a class="btn btn-primary d-none d-sm-inline-block" style="line-height: 0.685714rem; font-size: 10px;" href="https://auther.quarc.me/app?keycode=<?php echo $_smarty_tpl->tpl_vars['key']->value['keycode'];?>
"><span class="nav-link-title" >Логи</span></a>
                            <a class="btn btn-primary d-none d-sm-inline-block disabled" style="line-height: 0.685714rem; font-size: 10px;" disabled><span class="nav-link-title" >Конфиги</span></a>
                        </td>
                    </tr>
                    <?php } ?>
                      
                    </tbody>
                    </table>
                  </div>
                </div>
              </div>

          </div>
        </div>
        <footer class="footer footer-transparent d-print-none">
          <div class="container">
            <div class="row text-center align-items-center flex-row-reverse">
              <div class="col-lg-auto ms-lg-auto">
                <ul class="list-inline list-inline-dots mb-0">
                  <li class="list-inline-item"><a class="link-secondary" href="https://t.me/pers0na2tg"> <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 10l-4 4l6 6l4 -16l-18 7l4 2l2 6l3 -4" /></svg> pers0na2tg</a></li>
                </ul>
              </div>
              <div class="col-12 col-lg-auto mt-3 mt-lg-0">
                <ul class="list-inline list-inline-dots mb-0">
                  <li class="list-inline-item">
                    Copyright © 2021
                    <a href="." class="link-secondary">Quarc.me</a>.
                    All rights reserved.
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>


    <div class="modal" id="myModal">
      <div class="modal modal-blur fade show" id="modal-report" tabindex="-1" role="dialog" style="padding-right: 17px; display: block;" aria-modal="true">
        <form role="form" method="POST" action="/profile/create_key">
        <div class="modal-dialog modal-lg" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Новый ключ</h5>
              <button type="button" class="btn-close" id="closeBtn" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3">
                <label class="form-label">Тэг ключа</label>
                <input type="text" class="form-control" name="tag" placeholder="Ваше название">
              </div>
              <div class="mb-3">
                <label class="form-label">Длина ключа</label>
                <select name="key_distance" id="select-users" class="form-select">
                  <option value="1">8 символов</option>
                  <option value="2">16 символов</option>
                  <option value="3">24 символа</option>
                  <option value="4">32 символа</option>
                </select>
              </div>
              <div class="mb-3">
                <label class="form-label">Длительность подписки (в часах)</label>
                <input type="text" class="form-control" name="hours" value="24" placeholder="24">
              </div>
              
              <div class="mb-3">
                <label class="form-label">Количество ключей (максимум 20 за раз)</label>
                <input type="text" class="form-control" name="total_keys" value="1" placeholder="1">
              </div>
   
            </div>

            <input type='hidden' name='username' value='<?php echo $_smarty_tpl->tpl_vars['Me']->value["login"];?>
'>

            <div class="modal-footer">
              <button type="submit" class="btn btn-primary w-100">Создать ключи</button>
            </div>
          </div>
        </div>
      </form>
      </div>
    </div>

    <script>
      var modal = document.getElementById("myModal");
      var btn = document.getElementById("myBtn");
      var span = document.getElementById("closeBtn");

      btn.onclick = function() {
        modal.style.display = "block";
      }
      
      span.onclick = function() {
        modal.style.display = "none";
      }

      // When the user clicks anywhere outside of the modal, close it
      window.onclick = function(event) {
        if (event.target == modal) {
          modal.style.display = "none";
        }
      }
      </script>


<div class="modal" id="myModal2">
  <div class="modal modal-blur fade show" id="modal-report" tabindex="-1" role="dialog" style="padding-right: 17px; display: block;" aria-modal="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Информация о приложении</h5>
          <button type="button" class="btn-close" id="closeBtn2" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label" style="color: rgb(37 110 197);">Публичный токен.</label>
            <input type="text" class="form-control" name="name" value="<?php echo $_smarty_tpl->tpl_vars['Me']->value['token'];?>
" disabled placeholder="<?php echo $_smarty_tpl->tpl_vars['Me']->value['token'];?>
">
          </div>
          <div class="mb-3">
            <label class="form-label" style="color: rgb(37 110 197);">Приватный токен. </label>
            <label class="form-label">Пожалуйста, будьте аккуратны. Никому не показывайте данный токен. </label>
            <input type="text" class="form-control" name="name" value="<?php echo $_smarty_tpl->tpl_vars['Me']->value['secret_token'];?>
" disabled placeholder="<?php echo $_smarty_tpl->tpl_vars['Me']->value['secret_token'];?>
">
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  var modal2 = document.getElementById("myModal2");
  var btn2 = document.getElementById("myBtn2");
  var span2 = document.getElementById("closeBtn2");

  btn2.onclick = function() {
    modal2.style.display = "block";
  }
  
  span2.onclick = function() {
    modal2.style.display = "none";
  }

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == modal) {
      modal2.style.display = "none";
    }
  }
  </script>

<div class="modal" id="myModal3">
  <div class="modal modal-blur fade show" id="modal-report" tabindex="-1" role="dialog" style="padding-right: 17px; display: block;" aria-modal="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Фильтры автоматизации</h5>
          <button type="button" class="btn-close" id="closeBtn3" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">

          Отправляя лог вы можете указать определенный тэг к нему, по этому тэгу можно автоматизировать действия с ключем.
          <br>
          В данном меню вы можете создать новое действие к определенному тэгу.

          <div class="hr-text">
            <span>Новый фильтр тэга у лога</span>
          </div>
          <form role="form" method="POST" action="/profile/create_log_action">
          <div class="form-group mb-3 row">
            <label class="form-label col-3 col-form-label">Фильтр лога</label>
            <div class="col">
              <input type="text" class="form-control" aria-describedby="Filter" name="Filter" placeholder="Например [Debug]">
            </div>
          </div>
          <div class="form-group mb-3 row">
            <label class="form-label col-3 col-form-label">Действие</label>
            <div class="col">
              <select class="form-select" name="Action">
                <option value="0">Деактивировать подписку</option>
                <option value="1">Удалить ключ активации</option>
              </select>
            </div>
          </div>
          <div class="mb-3 row">
            <button type="submit" class="btn btn-primary">Добавить новый фильтр</button>
          </div>
          </form>
            
          <div class="hr-text">
            <span>Список фильтров</span>
          </div>

          <div class="card-table table-responsive">
            <table class="table table-vcenter" style="margin-bottom: 0rem;">
              <thead>
                <tr>
                  <th>Фильтр по тэгу</th>
                  <th>Действие</th>
                  <th colspan="2">Управление</th>
                </tr>
              </thead>
              <tbody>

            <?php  $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['key']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['LogAutomatic']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['key']->key => $_smarty_tpl->tpl_vars['key']->value){
$_smarty_tpl->tpl_vars['key']->_loop = true;
?>
            <tr>
                <td style="font-size: 11px;">
                  <a class="btn btn-primary d-none d-sm-inline-block" style="line-height: 0.585714rem; font-size: 10px;">
                    <span class="nav-link-title">
                      <?php echo $_smarty_tpl->tpl_vars['key']->value['tag_filter'];?>

                    </span>
                  </a>
                </td>
                <td class="text-muted" style="font-size: 11px;">
                  <?php if ($_smarty_tpl->tpl_vars['key']->value['action']==0){?>
                  Отключение подписки
                  <?php }?>
                  <?php if ($_smarty_tpl->tpl_vars['key']->value['action']==1){?>
                  Удаление ключа
                  <?php }?>
                </td>
                <td style="font-size: 11px;">
                  <form class="d-none d-sm-inline-block" role="form" method="POST" action="/profile/delete_log_action">
                    <input type='hidden' name='id' value='<?php echo $_smarty_tpl->tpl_vars['key']->value['id'];?>
'>
                    <button type="submit" style="line-height: 0.685714rem; font-size: 10px;" class="btn btn-primary">Удалить фильтр</button>
                    </form>
                </td>
            </tr>
            <?php } ?>
              
            </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  var modal3 = document.getElementById("myModal3");
  var btn3 = document.getElementById("myBtn3");
  var span3 = document.getElementById("closeBtn3");

  btn3.onclick = function() {
    modal3.style.display = "block";
  }
  
  span3.onclick = function() {
    modal3.style.display = "none";
  }

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == modal) {
      modal3.style.display = "none";
    }
  }
  </script>





<div class="modal" id="myModal4">
  <div class="modal modal-blur fade show" id="modal-report" tabindex="-1" role="dialog" style="padding-right: 17px; display: block;" aria-modal="true">
    <form role="form" method="POST" action="/profile/file_upload" enctype="multipart/form-data">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Мои файлы</h5>
          <button type="button" class="btn-close" id="closeBtn4" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="form-group mb-3 row">
            <label class="form-label col-3 col-form-label">Название для файла</label>
            <div class="col">
              <input type="text" class="form-control" aria-describedby="Filter" name="Filter" placeholder="Например BinaryX">
            </div>
          </div>
          <div class="form-group mb-3 row">
            <label class="form-label col-3 col-form-label">Шифрование</label>
            <div class="col">
              <select class="form-select" name="Action">
                <option value="0">Шифровать через RSA-512 (только при использовании API V2)</option>
                <option value="1">Не шифровать</option>
              </select>
            </div>
          </div>
          <div class="form-group mb-3 row">
            <div class="form-label col-3 col-form-label">Выберите новый файл</div>
            <div class="col">
              <input type="file" name="Executable" class="form-control">
            </div>
          </div>
          <button type="submit" class="btn btn-primary w-100">Загрузить файл</button>
          <div class="hr-text">
            <span>Список ваших файлов</span>
          </div>
          <div class="card-table table-responsive">
            <table class="table table-vcenter" style="margin-bottom: 0rem;">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Имя файла</th>
                  <th>RSA-ключ</th>
                  <th colspan="2">Управление</th>
                </tr>
              </thead>
              <tbody>

            <?php  $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['key']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['Files']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['key']->key => $_smarty_tpl->tpl_vars['key']->value){
$_smarty_tpl->tpl_vars['key']->_loop = true;
?>
            <tr>
                <td style="font-size: 11px;">
                 
                    <span class="nav-link-title">
                      <?php echo $_smarty_tpl->tpl_vars['key']->value['id'];?>

                    </span>
                </td>
                <td class="text-muted" style="font-size: 11px;">
                  <?php echo $_smarty_tpl->tpl_vars['key']->value['filename'];?>


                </td>
                <td class="text-muted" style="font-size: 11px; width: 40%;">
                  <input type="text" class="form-control" name="name" value="<?php echo $_smarty_tpl->tpl_vars['key']->value['rsa_key'];?>
" placeholder="<?php echo $_smarty_tpl->tpl_vars['key']->value['rsa_key'];?>
">
                </td>
                <td style="font-size: 11px;">
                  <form class="d-none d-sm-inline-block" role="form" method="POST" action="/profile/delete_file">
                    <input type='hidden' name='id' value='<?php echo $_smarty_tpl->tpl_vars['key']->value['id'];?>
'>
                    <button type="submit" style="line-height: 0.685714rem; font-size: 10px;" class="btn btn-danger">Удалить</button>
                    </form>

                    <form class="d-none d-sm-inline-block" role="form" method="POST" action="/profile/delete_log_action">
                      <input type='hidden' name='id' value='<?php echo $_smarty_tpl->tpl_vars['key']->value['id'];?>
'>
                      <input type="file" style="width: 100px; line-height: 0.685714rem; font-size: 10px;" class="form-control">
                      <button type="submit" style="line-height: 0.685714rem; font-size: 10px; width: 100px;" class="btn">Обновить файл</button>
                      </form>
                </td>
            </tr>
            <?php } ?>
              
            </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </form>
  </div>
</div>

<script>
  var modal4 = document.getElementById("myModal4");
  var btn4 = document.getElementById("myBtn4");
  var span4 = document.getElementById("closeBtn4");

  btn4.onclick = function() {
    modal4.style.display = "block";
  }
  
  span4.onclick = function() {
    modal4.style.display = "none";
  }

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == modal) {
      modal4.style.display = "none";
    }
  }
  </script>

</body><?php }} ?>