<?php /* Smarty version Smarty-3.1.6, created on 2021-04-27 19:48:44
         compiled from "../views/default/authorization.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11585350535c40fe969e2cf2-81481800%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'be53720de1cc687b9e3b5c0cb61d42d7bb0cea92' => 
    array (
      0 => '../views/default/authorization.tpl',
      1 => 1619540886,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11585350535c40fe969e2cf2-81481800',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5c40fe96a17be',
  'variables' => 
  array (
    'Title' => 0,
    'site_key' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5c40fe96a17be')) {function content_5c40fe96a17be($_smarty_tpl) {?>﻿
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,500,500i,600,600i,700,700i&amp;subset=latin-ext">

    <link href="https://auther.club/views/default/css/tabler.min.css" rel="stylesheet" />
    <link href="https://auther.club/views/default/css/tabler-flags.min.css" rel="stylesheet" />
    <link href="https://auther.club/views/default/css/tabler-payments.min.css" rel="stylesheet" />
    <link href="https://auther.club/views/default/css/demo.min.css" rel="stylesheet" />
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<title> <?php echo $_smarty_tpl->tpl_vars['Title']->value;?>
 </title>
</head>

<body class="antialiased border-top-wide border-primary d-flex flex-column">
    <div class="flex-fill d-flex flex-column justify-content-center py-4">
      <div class="container-tight py-6">
        <form class="card card-md" role="form" method="POST" action="/authorization/auth">
          <div class="card-body">
			<h2 class="card-title text-center mb-4">Вход в аккаунт</h2>
            <div class="mb-3">
              <label class="form-label">Имя пользователя</label>
              <input type="text" name="login" class="form-control">
            </div>
            <div class="mb-2">
              <label class="form-label">
                Пароль
              </label>
              <div class="input-group input-group-flat">
                <input type="password" name="password" class="form-control"   autocomplete="off">
              </div>
            </div>
            <div class="g-recaptcha" data-sitekey="<?php echo $_smarty_tpl->tpl_vars['site_key']->value;?>
"></div>
            <div class="form-footer">
              <button type="submit" class="btn btn-primary w-100">Авторизоваться</button>
            </div>
          </div>
        </form>
        <div class="text-center text-muted mt-3">
         Все еще нет аккаунта? <a href="/authorization/register" tabindex="-1">Создать</a>
        </div>
      </div>
    </div>
  </body><?php }} ?>