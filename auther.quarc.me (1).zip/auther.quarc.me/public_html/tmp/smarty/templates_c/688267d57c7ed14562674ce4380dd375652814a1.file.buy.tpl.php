<?php /* Smarty version Smarty-3.1.6, created on 2021-05-19 01:03:15
         compiled from "../views/default/buy.tpl" */ ?>
<?php /*%%SmartyHeaderCode:523293585c40ff603c3f56-17105290%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '688267d57c7ed14562674ce4380dd375652814a1' => 
    array (
      0 => '../views/default/buy.tpl',
      1 => 1619540886,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '523293585c40ff603c3f56-17105290',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5c40ff6053055',
  'variables' => 
  array (
    'Title' => 0,
    'Me' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5c40ff6053055')) {function content_5c40ff6053055($_smarty_tpl) {?>﻿
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,500,500i,600,600i,700,700i&amp;subset=latin-ext">

    <link href="https://auther.club/views/default/css/tabler.min.css" rel="stylesheet" />
    <link href="https://auther.club/views/default/css/tabler-flags.min.css" rel="stylesheet" />
    <link href="https://auther.club/views/default/css/tabler-payments.min.css" rel="stylesheet" />
    <link href="https://auther.club/views/default/css/demo.min.css" rel="stylesheet" />

	<title> <?php echo $_smarty_tpl->tpl_vars['Title']->value;?>
 </title>
</head>

<body class="antialiased">
    <div class="page">
      <header class="navbar navbar-expand-md navbar-dark navbar-overlap d-print-none">
        <div class="container-xl">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu">
            <span class="navbar-toggler-icon"></span>
          </button>
          <h1 class="navbar-brand navbar-brand-autodark d-none-navbar-horizontal pe-0 pe-md-3">
            <!--<a href=".">
              <img src="./static/logo-white.svg" width="110" height="32" alt="Tabler" class="navbar-brand-image">
            </a>-->
          </h1>
          <div class="navbar-nav flex-row order-md-last">
            <div class="nav-item">
                <?php if ($_smarty_tpl->tpl_vars['Me']->value==false){?>
                <li class="nav-item active">
                    <a class="nav-link" href="/authorization">
                      <span class="nav-link-title">
                        Авторизация
                      </span>
                    </a>
                  </li>
                <?php }?> 

                <?php if ($_smarty_tpl->tpl_vars['Me']->value!=false){?>
                <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="/authorization/logout/">
                      <span class="nav-link-title">
                        Выход
                      </span>
                    </a>
                  </li>
                  <li class="nav-item active">
                    <a class="nav-link" href="/profile">
                      <span class="nav-link-title">
                        <?php echo $_smarty_tpl->tpl_vars['Me']->value["login"];?>

                      </span>
                    </a>
                  </li>
                  </ul>
                <?php }?>
            </div>
          </div>
          <div class="collapse navbar-collapse" id="navbar-menu">
            <div class="d-flex flex-column flex-md-row flex-fill align-items-stretch align-items-md-center">
              <ul class="navbar-nav">
                <li class="nav-item">
                  <a class="nav-link" href="https://auther.club/">
                    <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="5 12 3 12 12 3 21 12 19 12"></polyline><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7"></path><path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6"></path></svg>
                    </span>
                    <span class="nav-link-title">
                      Главная
                    </span>
                  </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/profile">
                    <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><rect x="4" y="4" width="6" height="5" rx="2"></rect><rect x="4" y="13" width="6" height="7" rx="2"></rect><rect x="14" y="4" width="6" height="7" rx="2"></rect><rect x="14" y="15" width="6" height="5" rx="2"></rect></svg>
                    </span>
                    <span class="nav-link-title">
                      Мой профиль
                    </span>
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/docs">
                    <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M14 3v4a1 1 0 0 0 1 1h4"></path><path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z"></path><line x1="9" y1="9" x2="10" y2="9"></line><line x1="9" y1="13" x2="15" y2="13"></line><line x1="9" y1="17" x2="15" y2="17"></line></svg>
                    </span>
                    <span class="nav-link-title">
                      Документация
                    </span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </header>
      <div class="content">
        <div class="container-xl">
          <!-- Page title -->
          <div class="page-header text-white d-print-none">
            <div class="row align-items-center">
              <div class="col">
                <!-- Page pre-title -->
                <div class="page-pretitle">
                  МОЙ ПРОФИЛЬ
                </div>
                <h2 class="page-title">
                 <?php echo $_smarty_tpl->tpl_vars['Me']->value["login"];?>

                </h2>
              </div>
              <!-- Page title actions -->
            </div>
          </div>
          <div class="row row-deck row-cards">

            <div class="col-sm-6 col-lg-4">
              <div class="card card-md">
                <div class="card-body text-center">
                  <div class="text-uppercase text-muted font-weight-medium">Бесплатно</div>
                  <div class="display-5 my-3">0 ₽</div>
                  <ul class="list-unstyled lh-lg">
                    <li>До <strong>25</strong> ключей активации</li>
                    <li><strong>Нет</strong> системы логирования</li>
                    <li><strong>Нет</strong> облачных конфигураций</li>
                  </ul>
                  <div class="text-center mt-4">
                    <a type="submit" class="btn w-100 disabled" disabled>Уже активно</a>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-sm-6 col-lg-4">
              <div class="card card-md">
                <div class="card-body text-center">
                  <div class="text-uppercase text-muted font-weight-medium">PREMIUM - 1 месяц</div>
                  <div class="display-5 my-3">299 ₽</div>
                  <div class="display-10 my-3">Qiwi не доступен.</div>
                  <ul class="list-unstyled lh-lg">
                    <li><strong>∞</strong> ключей активации</li>
                    <li><strong>Есть</strong> система логирования</li>
                    <li><strong>Есть</strong> облачные конфигурации</li>
                  </ul>
                  <div class="text-center mt-4">
                    <a href="https://www.free-kassa.ru/merchant/cash.php?oa=299&o=Auther.club&us_login=<?php echo $_smarty_tpl->tpl_vars['Me']->value["login"];?>
&s=bc3af34b74e0497959a1b9f840ed73b7&m=263452" type="submit" class="btn w-100">Приобрести план</a>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-sm-6 col-lg-4">
              <div class="card card-md">
                <div class="card-body text-center">
                  <div class="text-uppercase text-muted font-weight-medium">PREMIUM - 3 месяца</div>
                  <div class="display-5 my-3">699 ₽</div>
                  <div class="display-10 my-3">Все методы оплаты.</div>
                  <ul class="list-unstyled lh-lg">
                    <li><strong>∞</strong> ключей активации</li>
                    <li><strong>Есть</strong> система логирования</li>
                    <li><strong>Есть</strong> облачные конфигурации</li>
                  </ul>
                  <div class="text-center mt-4">
                    <a href="https://www.free-kassa.ru/merchant/cash.php?oa=699&o=Auther.club&us_login=<?php echo $_smarty_tpl->tpl_vars['Me']->value["login"];?>
&s=3afad9252a7f3888ed1a3a7ba21a77fb&m=263452" type="submit" class="btn w-100">Приобрести план</a>
                  </div>
                </div>
              </div>
            </div>

            </div>

        </div>

        <footer class="footer footer-transparent d-print-none">
          <div class="container">
            <div class="row text-center align-items-center flex-row-reverse">
              <div class="col-lg-auto ms-lg-auto">
                <ul class="list-inline list-inline-dots mb-0">
                  <li class="list-inline-item"><a class="link-secondary" href="https://t.me/pers0na2tg"> <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 10l-4 4l6 6l4 -16l-18 7l4 2l2 6l3 -4" /></svg> pers0na2tg</a></li>
                </ul>
              </div>
              <div class="col-12 col-lg-auto mt-3 mt-lg-0">
                <ul class="list-inline list-inline-dots mb-0">
                  <li class="list-inline-item">
                    Copyright © 2021
                    <a href="." class="link-secondary">Auther.club</a>.
                    All rights reserved.
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
</body><?php }} ?>