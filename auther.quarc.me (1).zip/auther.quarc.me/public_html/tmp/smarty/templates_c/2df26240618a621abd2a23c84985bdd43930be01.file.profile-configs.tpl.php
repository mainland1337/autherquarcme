<?php /* Smarty version Smarty-3.1.6, created on 2019-01-18 19:25:53
         compiled from "../views/default/profile-configs.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20664990825c41fe1146c781-27120940%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2df26240618a621abd2a23c84985bdd43930be01' => 
    array (
      0 => '../views/default/profile-configs.tpl',
      1 => 1547763336,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20664990825c41fe1146c781-27120940',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'Title' => 0,
    'Me' => 0,
    'GetConfig' => 0,
    'status' => 0,
    'GetAllConfigs' => 0,
    'key' => 0,
    'Back' => 0,
    'CurrentPage' => 0,
    'MaxList' => 0,
    'Next' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5c41fe1154187',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5c41fe1154187')) {function content_5c41fe1154187($_smarty_tpl) {?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo $_smarty_tpl->tpl_vars['Title']->value;?>
</title>
	<link href="/main/templates/default/css/bootstrap.min.css" rel="stylesheet">
	<link href="/main/templates/default/css/font-awesome.min.css" rel="stylesheet">
	<link href="/main/templates/default/css/datepicker3.css" rel="stylesheet">
	<link href="/main/templates/default/css/styles.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="/"><span><?php echo $_smarty_tpl->tpl_vars['Title']->value;?>
</span></a>
			</div>
		</div><!-- /.container-fluid -->
	</nav>
	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			<div class="profile-userpic">
				<img src="http://png-images.ru/wp-content/uploads/2014/11/parrot_PNG722-170x170.png" class="img-responsive" alt="">
			</div>
			<div class="profile-usertitle">
				<div class="profile-usertitle-name"><a href="/profile/" class="color-black"><?php echo $_smarty_tpl->tpl_vars['Me']->value['login'];?>
</a></div>
				<div class="profile-usertitle-status"><span class="indicator label-success"></span><?php echo $_smarty_tpl->tpl_vars['Me']->value['class'];?>
</div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="divider"></div>
		<ul class="nav menu">
			<?php if ($_smarty_tpl->tpl_vars['Me']->value['access_admin']==1){?>
				<li><a href="/admin/"><em class="fa fa-circle-o-notch">&nbsp;</em> Админ панель</a></li>
			<?php }?>

			<li><a href="/profile/"><em class="fa fa-dashboard">&nbsp;</em> Профиль</a></li>
		
			<li class="parent active">
				<a data-toggle="collapse" href="#sub-item-1" class="collapsed" aria-expanded="false">
					<em class="fa fa-wheelchair">&nbsp;</em> Конфиг <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right collapsed" aria-expanded="false"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-1" aria-expanded="false" style="height: 0px;">
					<li><a class="" href="/profile/createConfig/">
						<span class="fa fa-arrow-right">&nbsp;</span> Создать конфиг
					</a></li>
					<?php if ($_smarty_tpl->tpl_vars['GetConfig']->value){?>
						<li><a class="" href="/profile/myconfig/">
							<span class="fa fa-arrow-right">&nbsp;</span> Мой конфиг
						</a></li>
					<?php }?>
					<li><a class="" href="/profile/configs/">
						<span class="fa fa-arrow-right">&nbsp;</span> Все конфиги
					</a></li>
					<li><a class="" href="/profile/settingsconfigs/">
						<span class="fa fa-arrow-right">&nbsp;</span> Настройка
					</a></li>
				</ul>
			</li>

			<li><a href="/profile/reset_binding/"><em class="fa fa-envelope">&nbsp;</em> Сброс привязки</a></li>

			<li><a href="/authorization/logout/"><em class="fa fa-power-off">&nbsp;</em> Выход</a></li>

		</ul>
	</div><!--/.sidebar-->
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="/">
					<em class="fa fa-home"></em>
				</a></li>
				<li><a href="/profile/">Профиль</a></li>
				<li><a href="/profile/settingsconfigs/">Конфиг</a></li>
				<li class="active"><a href="/profile/configs/">Все конфиги</a></li>
			</ol>
		</div><!--/.row-->
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Все конфиги</h1>
				<?php if ($_smarty_tpl->tpl_vars['status']->value!=false){?>
					<div class="alert bg-danger" role="alert"><em class="fa fa-lg fa-warning">&nbsp;</em> <?php echo $_smarty_tpl->tpl_vars['status']->value;?>
 </div>
				<?php }?>
			</div>
		</div><!--/.row-->
		
		<div class="row d-flex js-center">
			<div class="col-lg-8">
				<div class="panel panel-default articles">
					<div class="panel-heading">
						Конфиги
						<ul class="pull-right panel-settings panel-button-tab-right">
							<li class="dropdown"><a class="pull-right dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
								<em class="fa fa-inbox"></em>
							</a>
								<ul class="dropdown-menu dropdown-menu-right">
									<li>
										<ul class="dropdown-settings">
											<li><a href="/profile/createConfig/">
												<em class="fa fa-file"></em> Создать конфиг
											</a></li>
											<li><a href="/profile/settingsconfigs/">
												<em class="fa fa-list-alt"></em> Мои конфиги
											</a></li>
										</ul>
									</li>
								</ul>
							</li>
						</ul>
						<span class="pull-right clickable panel-toggle panel-button-tab-left"><em class="fa fa-toggle-up"></em></span></div>
					<div class="panel-body articles-container">


						<div class="article border-bottom">
							<div class="col-xs-12">
								<div class="row">
									<div class="col-md-5 text-muted">
										Название
									</div><!--
									<div class="col-md-2 text-muted">
										Репутация
									</div>-->
									<div class="col-md-3 text-muted">
										Дата создания
									</div>
									<div class="col-md-4 text-muted">
										Действие
									</div>
								</div>
							</div>
							<div class="clear"></div>
						</div><!--End .article-->

				<?php if ($_smarty_tpl->tpl_vars['GetAllConfigs']->value!=false){?>
					<?php  $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['key']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['GetAllConfigs']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['key']->key => $_smarty_tpl->tpl_vars['key']->value){
$_smarty_tpl->tpl_vars['key']->_loop = true;
?>	

						<div class="article border-bottom">
							<div class="col-xs-12">
								<div class="row">
									<div class="col-md-5">
										<h4><?php echo $_smarty_tpl->tpl_vars['key']->value['name'];?>
</h4>
									</div><!--
									<div class="col-md-2">
										<h4><?php echo $_smarty_tpl->tpl_vars['key']->value['reputation'];?>
</h4>
									</div>-->
									<div class="col-md-3">
										<h4><?php echo date('d.m.Y H:i:s',$_smarty_tpl->tpl_vars['key']->value['date']);?>
</h4>
									</div>
									<div class="col-md-4">
										
										<a href="#" class="btn btn-md btn-primary">Добавить</a>
										<a href="#" class="btn btn-md btn-info">Открыть</a>
										<!-- 
											<a href="#" class="btn btn-md btn-success"><em class="fa fa-thumbs-o-up"></em></a>
											<a href="#" class="btn btn-md btn-danger"><em class="fa fa-thumbs-o-down"></em></a>
										-->
									</div>
								</div>
							</div>
							<div class="clear"></div>
						</div><!--End .article-->
					<?php } ?>

						<div class="article border-bottom">
							<div class="col-xs-12">
								<div class="row d-flex js-center">
									<a href="?page=<?php echo $_smarty_tpl->tpl_vars['Back']->value;?>
" class="btn btn-md btn-info"><</a>
									<span class="m-a-y"><?php echo $_smarty_tpl->tpl_vars['CurrentPage']->value;?>
 / <?php echo $_smarty_tpl->tpl_vars['MaxList']->value;?>
</span>
									<a href="?page=<?php echo $_smarty_tpl->tpl_vars['Next']->value;?>
" class="btn btn-md btn-info">></a>
								</div>
							</div>
							<div class="clear"></div>
						</div><!--End .article-->

				<?php }?>

					</div>
				</div><!--End .articles-->
			</div>
		</div>
		

			<div class="col-sm-12">
				<p class="back-link">MoloF SYSTEM</p>
			</div>

	</div>	<!--/.main-->
	
	<script src="/main/js/jquery-1.11.1.min.js"></script>
	<script src="/main/js/bootstrap.min.js"></script>
	<script src="/main/js/chart.min.js"></script>
	<script src="/main/js/chart-data.js"></script>
	<script src="/main/js/easypiechart.js"></script>
	<script src="/main/js/easypiechart-data.js"></script>
	<script src="/main/js/bootstrap-datepicker.js"></script>
	<script src="/main/js/custom.js"></script>	
</body>
</html><?php }} ?>