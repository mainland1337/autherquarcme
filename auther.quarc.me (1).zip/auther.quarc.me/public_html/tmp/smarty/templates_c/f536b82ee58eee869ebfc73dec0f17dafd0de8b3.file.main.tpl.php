<?php /* Smarty version Smarty-3.1.6, created on 2021-04-27 19:28:48
         compiled from "../views/default/main.tpl" */ ?>
<?php /*%%SmartyHeaderCode:8369302875c40fe9015e2e8-15656601%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f536b82ee58eee869ebfc73dec0f17dafd0de8b3' => 
    array (
      0 => '../views/default/main.tpl',
      1 => 1619540887,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8369302875c40fe9015e2e8-15656601',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5c40fe9028784',
  'variables' => 
  array (
    'Title' => 0,
    'Me' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5c40fe9028784')) {function content_5c40fe9028784($_smarty_tpl) {?><html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,500,500i,600,600i,700,700i&amp;subset=latin-ext">

    <link href="https://auther.club/views/default/css/tabler.min.css" rel="stylesheet" />
    <link href="https://auther.club/views/default/css/tabler-flags.min.css" rel="stylesheet" />
    <link href="https://auther.club/views/default/css/tabler-payments.min.css" rel="stylesheet" />
    <link href="https://auther.club/views/default/css/demo.min.css" rel="stylesheet" />

    <meta name="enot" content="7361612280340NVb20l7lUl0etbiwXieFDn9gjk4wquV5" />

    <style>
.alert {
    --tblr-alert-color: #656d77;
    background: #fff;
    border: 1px solid rgba(101,109,119,.16);
    border-left: .25rem solid var(--tblr-alert-color);
    box-shadow: rgb(35 46 60 / 4%) 0 2px 4px 0;
}
.alert-danger {
    --tblr-alert-color: #d63939;
}

      .alert-title {
    font-size: .875rem;
    line-height: 1.4285714;
    font-weight: 600;
    margin-bottom: .25rem;
    color: var(--tblr-alert-color);
}
    </style>

	<title> <?php echo $_smarty_tpl->tpl_vars['Title']->value;?>
 </title>
</head>

<body class="antialiased">
    <div class="page">
      <header class="navbar navbar-expand-md navbar-dark navbar-overlap d-print-none">
        <div class="container-xl">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu">
            <span class="navbar-toggler-icon"></span>
          </button>
          <h1 class="navbar-brand navbar-brand-autodark d-none-navbar-horizontal pe-0 pe-md-3">
            <!--<a href=".">
              <img src="./static/logo-white.svg" width="110" height="32" alt="Tabler" class="navbar-brand-image">
            </a>-->
          </h1>
          <div class="navbar-nav flex-row order-md-last">
            <div class="nav-item">
                <?php if ($_smarty_tpl->tpl_vars['Me']->value==false){?>
                <li class="nav-item active">
                    <a class="nav-link" href="/authorization">
                      <span class="nav-link-title">
                        Авторизация
                      </span>
                    </a>
                  </li>
                <?php }?> 

                <?php if ($_smarty_tpl->tpl_vars['Me']->value!=false){?>
                <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="/authorization/logout/">
                      <span class="nav-link-title">
                        Выход
                      </span>
                    </a>
                  </li>
                  <li class="nav-item active">
                    <a class="nav-link" href="/profile">
                      <span class="nav-link-title">
                        <?php echo $_smarty_tpl->tpl_vars['Me']->value["login"];?>

                      </span>
                    </a>
                  </li>
                  </ul>
                <?php }?>
            </div>
          </div>
          <div class="collapse navbar-collapse" id="navbar-menu">
            <div class="d-flex flex-column flex-md-row flex-fill align-items-stretch align-items-md-center">
              <ul class="navbar-nav">
                <li class="nav-item active">
                  <a class="nav-link" href="https://auther.quarc.me/">
                    <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="5 12 3 12 12 3 21 12 19 12"></polyline><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7"></path><path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6"></path></svg>
                    </span>
                    <span class="nav-link-title">
                      Главная
                    </span>
                  </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/profile">
                    <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><rect x="4" y="4" width="6" height="5" rx="2"></rect><rect x="4" y="13" width="6" height="7" rx="2"></rect><rect x="14" y="4" width="6" height="7" rx="2"></rect><rect x="14" y="15" width="6" height="5" rx="2"></rect></svg>
                    </span>
                    <span class="nav-link-title">
                      Мой профиль
                    </span>
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/docs">
                    <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M14 3v4a1 1 0 0 0 1 1h4"></path><path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z"></path><line x1="9" y1="9" x2="10" y2="9"></line><line x1="9" y1="13" x2="15" y2="13"></line><line x1="9" y1="17" x2="15" y2="17"></line></svg>
                    </span>
                    <span class="nav-link-title">
                      Документация
                    </span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </header>
      <div class="content">
        <div class="container-xl">
          <!-- Page title -->
          <div class="page-header text-white d-print-none">
            <div class="row align-items-center">
              <div class="col">
                <!-- Page pre-title -->
                <div class="page-pretitle">
                  О нас
                </div>
                <h2 class="page-title">
                  auther.quarc.me
                </h2>
              </div>
              <!-- Page title actions -->
            </div>
          </div>
          <div class="row row-deck row-cards">

            <div class="alert alert-danger" role="alert">
              <h4 class="alert-title">Важная информация</h4>
              <div class="text-muted"> Проект перенесен на новый домен и теперь полностью бесплатен! Пожалуйста обновитите библиотеки и ссылки на доступ API в ваших проектах.
                <br>
                <br>
                5 числа старый домен будет отключен и API по нему более не будет доступно.</div>
            </div>

            <div class="col-4">
                <div class="card">
                  <div class="card-status-bottom bg-blue"></div>
                  <div class="card-body">
                    <h3 class="card-title">Лицензирование ПО</h3>
                    <p>Мы предоставляем вам услуги автоматической аутентификации для Вашего ПО, контролируйте всех кто сможет пользоваться вашим ПО всего в один клик.</p>
                  </div>
                </div>
              </div>

              <div class="col-4">
                <div class="card">
                  <div class="card-status-bottom bg-blue"></div>
                  <div class="card-body">
                    <h3 class="card-title">Система логгирования действий</h3>
                    <p>Сохраняйте и привязывайте любые действия к вашему пользователю. Удобный просмотр и создания лога.</p>
                  </div>
                </div>
              </div>


              <div class="col-4">
                <div class="card">
                  <div class="card-status-bottom bg-blue"></div>
                  <div class="card-body">
                    <h3 class="card-title">Облачные конфигурации (Очень скоро)</h3>
                    <p>Ваши пользователи смогут иметь доступ к пользовательским настройкам вашего ПО с любого компьютера. Передача конфигов между пользователями и другие особенности.</p>
                  </div>
                </div>
              </div>


            <div class="col-4">
                <div class="card">
                  <div class="card-status-bottom bg-success"></div>
                  <div class="card-body">
                    <h3 class="card-title">Легкая интеграция</h3>
                    <p>Мы предоставляем вам удобное API, с помощью которого вы с легкостью интегрируете наш сервис к вашему приложению.</p>
                  </div>
                </div>
              </div>
              <div class="col-4">
                <div class="card">
                  <div class="card-status-bottom bg-success"></div>
                  <div class="card-body">
                    <h3 class="card-title">Кроссплатформенность</h3>
                    <p>Вы можете использовать наше API в любом языке программирования, который поддерживает JSON-парсинг и POST-запросы.</p>
                  </div>
                </div>
              </div>
              <div class="col-4">
                <div class="card">
                  <div class="card-status-bottom bg-success"></div>
                  <div class="card-body">
                    <h3 class="card-title">Защищенность</h3>
                    <p>Безопастность - наш главный приоритет. Все хранимые данные о ваших клиентах надежно зашифрованны. </p>
                  </div>
                </div>
              </div>

                <div class="col-sm-6 col-lg-4">
                  <div class="card card-md">
                    <div class="card-body text-center">
                      <div class="text-uppercase text-muted font-weight-medium">Бесплатно</div>
                      <div class="display-5 my-3">0 ₽</div>
                      <ul class="list-unstyled lh-lg">
                        <li><strong>∞</strong> ключей активации</li>
                        <li><strong>Есть</strong> система логирования</li>
                        <li><strong>Есть</strong> автоматизация</li>
                        <!-- <li><strong>Нет</strong> облачных конфигураций</li>-->
                      </ul>
                      <div class="text-center mt-4">
                        <a href="#" class="btn w-100" disabled >Уже активен</a>
                      </div>
                    </div>
                  </div>
                </div>

                

          </div>
        </div>
        <footer class="footer footer-transparent d-print-none">
          <div class="container">
            <div class="row text-center align-items-center flex-row-reverse">
              <div class="col-lg-auto ms-lg-auto">
                <ul class="list-inline list-inline-dots mb-0">
                    <li class="list-inline-item"><a class="link-secondary" href="https://t.me/pers0na2tg"> <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 10l-4 4l6 6l4 -16l-18 7l4 2l2 6l3 -4" /></svg> pers0na2tg</a></li>
                  </ul>
              </div>
              <div class="col-12 col-lg-auto mt-3 mt-lg-0">
                <ul class="list-inline list-inline-dots mb-0">
                  <li class="list-inline-item">
                    Copyright © 2021
                    <a href="." class="link-secondary">Quarc.me</a>.
                    All rights reserved.
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
</body>


</html><?php }} ?>