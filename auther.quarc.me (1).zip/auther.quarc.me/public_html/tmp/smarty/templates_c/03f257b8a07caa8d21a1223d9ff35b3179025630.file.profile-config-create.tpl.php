<?php /* Smarty version Smarty-3.1.6, created on 2019-01-18 19:25:48
         compiled from "../views/default/profile-config-create.tpl" */ ?>
<?php /*%%SmartyHeaderCode:18482652045c41fe0cc71083-55998966%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '03f257b8a07caa8d21a1223d9ff35b3179025630' => 
    array (
      0 => '../views/default/profile-config-create.tpl',
      1 => 1547763336,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18482652045c41fe0cc71083-55998966',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'Title' => 0,
    'Me' => 0,
    'GetConfig' => 0,
    'status' => 0,
    'GetDefaultConfigs' => 0,
    'key' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5c41fe0cdc176',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5c41fe0cdc176')) {function content_5c41fe0cdc176($_smarty_tpl) {?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo $_smarty_tpl->tpl_vars['Title']->value;?>
</title>
	<link href="/main/templates/default/css/bootstrap.min.css" rel="stylesheet">
	<link href="/main/templates/default/css/font-awesome.min.css" rel="stylesheet">
	<link href="/main/templates/default/css/datepicker3.css" rel="stylesheet">
	<link href="/main/templates/default/css/styles.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="/"><span><?php echo $_smarty_tpl->tpl_vars['Title']->value;?>
</span></a>
			</div>
		</div><!-- /.container-fluid -->
	</nav>
	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			<div class="profile-userpic">
				<img src="http://png-images.ru/wp-content/uploads/2014/11/parrot_PNG722-170x170.png" class="img-responsive" alt="">
			</div>
			<div class="profile-usertitle">
				<div class="profile-usertitle-name"><a href="/profile/" class="color-black"><?php echo $_smarty_tpl->tpl_vars['Me']->value['login'];?>
</a></div>
				<div class="profile-usertitle-status"><span class="indicator label-success"></span><?php echo $_smarty_tpl->tpl_vars['Me']->value['class'];?>
</div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="divider"></div>
		<ul class="nav menu">
			<?php if ($_smarty_tpl->tpl_vars['Me']->value['access_admin']==1){?>
				<li><a href="/admin/"><em class="fa fa-circle-o-notch">&nbsp;</em> Админ панель</a></li>
			<?php }?>

			<li><a href="/profile/"><em class="fa fa-dashboard">&nbsp;</em> Профиль</a></li>
		
			<li class="parent active">
				<a data-toggle="collapse" href="#sub-item-1" class="collapsed" aria-expanded="false">
					<em class="fa fa-wheelchair">&nbsp;</em> Конфиг <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right collapsed" aria-expanded="false"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-1" aria-expanded="false" style="height: 0px;">
					<li><a class="" href="/profile/createConfig/">
						<span class="fa fa-arrow-right">&nbsp;</span> Создать конфиг
					</a></li>
					<?php if ($_smarty_tpl->tpl_vars['GetConfig']->value){?>
						<li><a class="" href="/profile/myconfig/">
							<span class="fa fa-arrow-right">&nbsp;</span> Мой конфиг
						</a></li>
					<?php }?>
					<li><a class="" href="/profile/configs/">
						<span class="fa fa-arrow-right">&nbsp;</span> Все конфиги
					</a></li>
					<li><a class="" href="/profile/settingsconfigs/">
						<span class="fa fa-arrow-right">&nbsp;</span> Настройка
					</a></li>
				</ul>
			</li>

			<li><a href="/profile/reset_binding/"><em class="fa fa-envelope">&nbsp;</em> Сброс привязки</a></li>

			<li><a href="/authorization/logout/"><em class="fa fa-power-off">&nbsp;</em> Выход</a></li>

		</ul>
	</div><!--/.sidebar-->
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="/">
					<em class="fa fa-home"></em>
				</a></li>
				<li><a href="/profile/">Профиль</a></li>
				<li><a href="/profile/settingsconfigs/">Конфиг</a></li>
				<li class="active"><a href="/profile/configs/">Создание конфигов</a></li>
			</ol>
		</div><!--/.row-->
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Все конфиги</h1>
				<?php if ($_smarty_tpl->tpl_vars['status']->value!=false){?>
					<div class="alert bg-danger" role="alert"><em class="fa fa-lg fa-warning">&nbsp;</em> <?php echo $_smarty_tpl->tpl_vars['status']->value;?>
 </div>
				<?php }?>
			</div>
		</div><!--/.row-->
		
		<div class="row d-flex js-center">
			<div class="col-lg-6">
				<div class="panel panel-default">

				<form role="form" method="POST" action="/profile/createConf/">
					<div class="panel-heading">
						Создать конфиг
					</div>
					<div class="panel-body">
						<div class="col-md-12">
								<div class="col-xs-12">

									<div class="d-flex js-sp-b f-wrap">
										<label>
											<h4>Название</h4>
										</label>
										<label>
											<input type="input" name="name" class="form-control small" >
										</label>
									</div>

									<div class="d-flex js-sp-b f-wrap">
										<label>
											<h4>Приватность</h4>
										</label>
										<label>
											<input type="hidden"
											name="private" value="0">
											<input type="checkbox"
											name="private" class="checkbox" >
											<div class="checkbox-custom"></div>
										</label>
									</div>

									<div class="d-flex js-sp-b f-wrap">
										<label>
											<h4>Выбрать дефолтный конфиг</h4>
										</label>
										<label>
											<select class="form-control" name="config">
												<?php  $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['key']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['GetDefaultConfigs']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['key']->key => $_smarty_tpl->tpl_vars['key']->value){
$_smarty_tpl->tpl_vars['key']->_loop = true;
?>
													<option value="<?php echo $_smarty_tpl->tpl_vars['key']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['key']->value['name'];?>
</option>
												<?php } ?>
											</select>
										</label>
									</div>
	

								</div>

								<div class="form-group txt-center">
									<input type="submit" class="btn  btn-lg  btn-primary" value="Создать">
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		

			<div class="col-sm-12">
				<p class="back-link">MoloF SYSTEM</p>
			</div>

	</div>	<!--/.main-->
	
	<script src="/main/js/jquery-1.11.1.min.js"></script>
	<script src="/main/js/bootstrap.min.js"></script>
	<script src="/main/js/chart.min.js"></script>
	<script src="/main/js/chart-data.js"></script>
	<script src="/main/js/easypiechart.js"></script>
	<script src="/main/js/easypiechart-data.js"></script>
	<script src="/main/js/bootstrap-datepicker.js"></script>
	<script src="/main/js/custom.js"></script>

</body>
</html><?php }} ?>