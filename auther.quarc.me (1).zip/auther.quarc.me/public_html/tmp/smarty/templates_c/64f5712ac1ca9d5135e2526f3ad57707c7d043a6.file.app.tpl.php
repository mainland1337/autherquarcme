<?php /* Smarty version Smarty-3.1.6, created on 2021-05-13 08:46:08
         compiled from "../views/default/app.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9354435116017077ed5d983-06674006%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '64f5712ac1ca9d5135e2526f3ad57707c7d043a6' => 
    array (
      0 => '../views/default/app.tpl',
      1 => 1619540886,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9354435116017077ed5d983-06674006',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_6017077edc2cc',
  'variables' => 
  array (
    'Title' => 0,
    'UserApps' => 0,
    'key' => 0,
    'Me' => 0,
    'CURRENTKEY' => 0,
    'UserApp' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_6017077edc2cc')) {function content_6017077edc2cc($_smarty_tpl) {?><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,500,500i,600,600i,700,700i&amp;subset=latin-ext">

    <link href="https://auther.club/views/default/css/tabler.min.css" rel="stylesheet" />
    <link href="https://auther.club/views/default/css/tabler-flags.min.css" rel="stylesheet" />
    <link href="https://auther.club/views/default/css/tabler-payments.min.css" rel="stylesheet" />
    <link href="https://auther.club/views/default/css/demo.min.css" rel="stylesheet" />

	<title> <?php echo $_smarty_tpl->tpl_vars['Title']->value;?>
 </title>
</head>

<?php  $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['key']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['UserApps']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['key']->key => $_smarty_tpl->tpl_vars['key']->value){
$_smarty_tpl->tpl_vars['key']->_loop = true;
?>
<?php echo $_smarty_tpl->tpl_vars['key']->value['keycode'];?>

<?php } ?>

<body class="antialiased">
    <div class="page">
      <header class="navbar navbar-expand-md navbar-dark navbar-overlap d-print-none">
        <div class="container-xl">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu">
            <span class="navbar-toggler-icon"></span>
          </button>
          <h1 class="navbar-brand navbar-brand-autodark d-none-navbar-horizontal pe-0 pe-md-3">
            <!--<a href=".">
              <img src="./static/logo-white.svg" width="110" height="32" alt="Tabler" class="navbar-brand-image">
            </a>-->
          </h1>
          <div class="navbar-nav flex-row order-md-last">
            <div class="nav-item">
                <?php if ($_smarty_tpl->tpl_vars['Me']->value==false){?>
                <li class="nav-item active">
                    <a class="nav-link" href="/authorization">
                      <span class="nav-link-title">
                        Авторизация
                      </span>
                    </a>
                  </li>
                <?php }?> 

                <?php if ($_smarty_tpl->tpl_vars['Me']->value!=false){?>
                <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="/authorization/logout/">
                      <span class="nav-link-title">
                        Выход
                      </span>
                    </a>
                  </li>
                  <li class="nav-item active">
                    <a class="nav-link" href="/profile">
                      <span class="nav-link-title">
                        <?php echo $_smarty_tpl->tpl_vars['Me']->value["login"];?>

                      </span>
                    </a>
                  </li>
                  </ul>
                <?php }?>
            </div>
          </div>
          <div class="collapse navbar-collapse" id="navbar-menu">
            <div class="d-flex flex-column flex-md-row flex-fill align-items-stretch align-items-md-center">
              <ul class="navbar-nav">
                <li class="nav-item">
                  <a class="nav-link" href="https://auther.club/">
                    <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="5 12 3 12 12 3 21 12 19 12"></polyline><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7"></path><path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6"></path></svg>
                    </span>
                    <span class="nav-link-title">
                      Главная
                    </span>
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/buy">
                  <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M16.7 8a3 3 0 0 0 -2.7 -2h-4a3 3 0 0 0 0 6h4a3 3 0 0 1 0 6h-4a3 3 0 0 1 -2.7 -2" /><path d="M12 3v3m0 12v3" /></svg>
                  </span>
                  <span class="nav-link-title">
                    Тарифы
                  </span>
                </a>
              </li>
                <li class="nav-item active">
                    <a class="nav-link" href="/profile">
                    <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><rect x="4" y="4" width="6" height="5" rx="2"></rect><rect x="4" y="13" width="6" height="7" rx="2"></rect><rect x="14" y="4" width="6" height="7" rx="2"></rect><rect x="14" y="15" width="6" height="5" rx="2"></rect></svg>
                    </span>
                    <span class="nav-link-title">
                      Мой профиль
                    </span>
                  </a>
                </li>
              <li class="nav-item">
                <a class="nav-link" href="/docs">
                  <span class="nav-link-icon d-md-none d-lg-inline-block"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M14 3v4a1 1 0 0 0 1 1h4"></path><path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z"></path><line x1="9" y1="9" x2="10" y2="9"></line><line x1="9" y1="13" x2="15" y2="13"></line><line x1="9" y1="17" x2="15" y2="17"></line></svg>
                  </span>
                  <span class="nav-link-title">
                    Документация
                  </span>
                </a>
              </li>
              </ul>
            </div>
          </div>
        </div>
      </header>
      <div class="content">
        <div class="container-xl">
          <!-- Page title -->
          <div class="page-header text-white d-print-none">
            <div class="row align-items-center">
              <div class="col">
                <!-- Page pre-title -->
                <div class="page-pretitle">
                  ЛОГИ
                </div>
                <h2 class="page-title">
                 <?php echo $_smarty_tpl->tpl_vars['CURRENTKEY']->value;?>

                </h2>
              </div>

            </div>
          </div>

          <div class="row row-deck row-cards">
          
  

              <div class="col-md-12 col-lg-12" style="margin-top: 32px;">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">Действия пользователя</h3>
                  </div>
                  <div class="card-table table-responsive">
                    <table class="table table-vcenter" style="margin-bottom: 0rem;">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Дата</th>
                          <th>IP запроса</th>
                          <th>Тэг</th>
                          <th>Сообщение</th>
                        </tr>
                      </thead>
                      <tbody>

                    <?php  $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['key']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['UserApp']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['key']->key => $_smarty_tpl->tpl_vars['key']->value){
$_smarty_tpl->tpl_vars['key']->_loop = true;
?>
                    <tr>
                        <td style="font-size: 11px;"><?php echo $_smarty_tpl->tpl_vars['key']->value['id'];?>
</td>
                        <td style="font-size: 11px;"><?php echo $_smarty_tpl->tpl_vars['key']->value['time'];?>
</td>
                        <td style="font-size: 11px;"><?php echo $_smarty_tpl->tpl_vars['key']->value['ip'];?>
</td>
                        <td class="text-muted">
                          <?php if ($_smarty_tpl->tpl_vars['key']->value['tag']!=null){?>
                          <a class="btn btn-primary d-none d-sm-inline-block" style="line-height: 0.585714rem; font-size: 10px;">
                            <span class="nav-link-title">
                              <?php echo $_smarty_tpl->tpl_vars['key']->value['tag'];?>

                            </span>
                          </a>
                        <?php }?>
                        </td>
                        <td style="font-size: 11px;"><?php echo $_smarty_tpl->tpl_vars['key']->value['message'];?>
</td>
                    </tr>
                    <?php } ?>
                      
                    </tbody>
                    </table>
                  </div>
                </div>
              </div>

          </div>
        </div>
        <footer class="footer footer-transparent d-print-none">
          <div class="container">
            <div class="row text-center align-items-center flex-row-reverse">
              <div class="col-lg-auto ms-lg-auto">
                <ul class="list-inline list-inline-dots mb-0">
                  <li class="list-inline-item"><a class="link-secondary" href="https://t.me/pers0na2tg"> <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M15 10l-4 4l6 6l4 -16l-18 7l4 2l2 6l3 -4" /></svg> pers0na2tg</a></li>
                </ul>
              </div>
              <div class="col-12 col-lg-auto mt-3 mt-lg-0">
                <ul class="list-inline list-inline-dots mb-0">
                  <li class="list-inline-item">
                    Copyright © 2021
                    <a href="." class="link-secondary">Auther.club</a>.
                    All rights reserved.
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
</body><?php }} ?>