<?php /* Smarty version Smarty-3.1.6, created on 2021-05-16 21:51:22
         compiled from "../views/default/maintenance.tpl" */ ?>
<?php /*%%SmartyHeaderCode:105583470360a169aaebbf26-48176995%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9e60e83fe90e48244b2eb305210ad3f866bcdc63' => 
    array (
      0 => '../views/default/maintenance.tpl',
      1 => 1621190969,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '105583470360a169aaebbf26-48176995',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_60a169aaeebeb',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_60a169aaeebeb')) {function content_60a169aaeebeb($_smarty_tpl) {?><!doctype html>

<?php echo $_smarty_tpl->getSubTemplate ("site/site-header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<body class="antialiased border-top-wide border-primary d-flex flex-column">
<div class="page page-center">
    <div class="container-tight py-4">
        <div class="empty">
            <div class="empty-img"><img src="https://preview.tabler.io/static/illustrations/undraw_quitting_time_dm8t.svg" height="128"  alt="">
            </div>
            <p class="empty-title">Технические работы.</p>
            <p class="empty-subtitle text-muted">
                Мы готовим вам какое-то крутое обновление :) <br> Мы вернемся к работе в ближайшее время, спасибо за ожидание!
                <br> API V1 и V2 все еще доступны для ваших пользователей.
            </p>
            <div class="empty-action">
                <a href="https://discord.gg/v2hhdq7Kg4" class="btn btn-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-discord" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                        <circle cx="9" cy="12" r="1"></circle>
                        <circle cx="15" cy="12" r="1"></circle>
                        <path d="M7.5 7.5c3.5 -1 5.5 -1 9 0"></path>
                        <path d="M7 16.5c3.5 1 6.5 1 10 0"></path>
                        <path d="M15.5 17c0 1 1.5 3 2 3c1.5 0 2.833 -1.667 3.5 -3c.667 -1.667 .5 -5.833 -1.5 -11.5c-1.457 -1.015 -3 -1.34 -4.5 -1.5l-1 2.5"></path>
                        <path d="M8.5 17c0 1 -1.356 3 -1.832 3c-1.429 0 -2.698 -1.667 -3.333 -3c-.635 -1.667 -.476 -5.833 1.428 -11.5c1.388 -1.015 2.782 -1.34 4.237 -1.5l1 2.5"></path>
                    </svg>
                    Наш канал в Discord
                </a>
            </div>
        </div>
    </div>
</div>
</body>
</html><?php }} ?>