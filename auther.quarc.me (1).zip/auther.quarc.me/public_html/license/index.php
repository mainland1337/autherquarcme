<?php

$kek = $_GET['token'];

echo md5($kek . 'ZvMsV5MsI3jIGhlm1OvwC8wmesBEMOcQktZxW1sQ');

?>