<?php

include_once ('../models/IndexModel.php');

include_once ('../models/UsersModel.php');
include_once ('../models/PrivilegeModel.php');
include_once ('../models/SettingsModel.php');

function RSACrypt($input, $token, $license) 
{
	$key = (intdiv_1(time(),60)).$token.(intdiv_1(time(),60)).$license.(intdiv_1(time(),60));

	$inputLen = strlen($input);
	$keyLen = strlen($key);

	if ($inputLen <= $keyLen) {
		return $input ^ $key;
	}

	for ($i = 0; $i < $inputLen; ++$i) {
		$input[$i] = $input[$i] ^ $key[$i % $keyLen];
	}

	return $input;
}


function intdiv_1($a, $b){
    return ($a - $a % $b) / $b;
}

function indexAction($smarty)
{
	if (!isset($_POST[ "type" ]))
		die();

	if($_POST["type"] == "auth")
	{
		if (!isset($_POST[ "public_token" ]) || !isset($_POST[ "license" ]) || !isset($_POST[ "hwid" ]))
			die();

		$KEYDATA = GetKeyData($_POST["license"]);

		if(!$KEYDATA)
		{
			echo(RSACrypt("{"."\"Status\"".":"."\"WrongKey\""."}",
			$_POST[ "public_token" ], $_POST[ "license" ]));

			die();
		}

		$OWNERDATA = GetUserByID($KEYDATA["profileid"]);

		if(!$OWNERDATA)
			die();

		if($OWNERDATA["token"] != $_POST[ "public_token" ])
			die();

		if($KEYDATA["actived"] == 0)
		{
			$endtime = time() + $KEYDATA["hours"] * 60 * 60;
			RegisterKey($_POST[ "license" ], $endtime, $_POST["hwid"]);

			$KEYDATA = GetKeyData($_POST["license"]);

			echo(RSACrypt("{"
			."\"Status\"".":"."\"Activated\"".","
			."\"HWID\"".":"."\"".$_POST[ "hwid" ]."\"".","
			."\"License\"".":"."\"".$_POST[ "license" ]."\"".","
			."\"LicenseTime\"".":"."\"".$KEYDATA[ "hours" ]."\"".","
			."\"SubStartTime\"".":"."\"".$KEYDATA[ "starttime" ]."\"".","
			."\"SubEndTime\"".":"."\"".$KEYDATA[ "endtime" ]."\""
			."}",
			$_POST[ "public_token" ], $_POST[ "license" ]));

			die();
		}
		else
		{
			if($KEYDATA["hwid"] == NULL)
			{
				RegisterHWID($_POST[ "license" ], $_POST["hwid"]);
			}

			$KEYDATA = GetKeyData($_POST["license"]);

			if($KEYDATA["hwid"] != $_POST[ "hwid" ])
			{
				echo(RSACrypt("{"
					."\"Status\"".":"."\"WrongHWID\"".","
					."\"License\"".":"."\"".$_POST[ "license" ]."\""
				."}",
				$_POST[ "public_token" ], $_POST[ "license" ]));
				
				die();
			}

			if($KEYDATA["endtime"] <= time())
			{
				echo(RSACrypt("{"
					."\"Status\"".":"."\"SubEnded\"".","
					."\"License\"".":"."\"".$_POST[ "license" ]."\"".","
					."\"LicenseTime\"".":"."\"".$KEYDATA[ "hours" ]."\"".","
					."\"SubStartTime\"".":"."\"".$KEYDATA[ "starttime" ]."\"".","
					."\"SubEndTime\"".":"."\"".$KEYDATA[ "endtime" ]."\""
				."}",
				$_POST[ "public_token" ], $_POST[ "license" ]));
				
				die();
			}

			if($KEYDATA["hwid"] == $_POST[ "hwid" ] && $KEYDATA["endtime"] >= time())
			{
				echo(RSACrypt("{"
					."\"Status\"".":"."\"Authorized\"".","
					."\"HWID\"".":"."\"".$_POST[ "hwid" ]."\"".","
					."\"License\"".":"."\"".$_POST[ "license" ]."\"".","
					."\"LicenseTime\"".":"."\"".$KEYDATA[ "hours" ]."\"".","
					."\"SubStartTime\"".":"."\"".$KEYDATA[ "starttime" ]."\"".","
					."\"SubEndTime\"".":"."\"".$KEYDATA[ "endtime" ]."\""
				."}",
				$_POST[ "public_token" ], $_POST[ "license" ]));

				die();
			}
		}
	}
	else if($_POST["type"] == "log")
	{
		if (!isset($_POST[ "private_token" ]) || !isset($_POST[ "license" ]) || !isset($_POST[ "message" ]))
			die();

		$KEYDATA = GetKeyData($_POST["license"]);

		if(!$KEYDATA)
		{
			echo(RSACrypt("{"
				."\"Status\"".":"."\"WrongKey\""
			."}",
			 $_POST[ "private_token" ], $_POST[ "license" ]));

			die();
		}

		$OWNERDATA = GetUserByID($KEYDATA["profileid"]);

		if(!$OWNERDATA)		
			die();

		if($OWNERDATA["secret_token"] != $_POST[ "private_token" ])
			die();

		$LogAutomatic = GetLogAutomatization($_POST['private_token']);

		foreach($LogAutomatic as $key)
		{
			if($key["tag_filter"] == $_POST["tag"])
			{
				if($key["action"] == 0)
				{
					ExpireKey($_POST["license"]);
				}
				if($key["action"] == 1)
				{
					deleteKey($_POST["license"]);
				}
			}
		}

		create_log($_POST["license"], $_POST["message"], $_POST["tag"], $_POST[ "private_token" ]);

		echo(RSACrypt("{"."\"Status\"".":"."\"Success\""."}", $_POST[ "private_token" ], $_POST[ "license" ]));
	}
	else { die(); }
}
