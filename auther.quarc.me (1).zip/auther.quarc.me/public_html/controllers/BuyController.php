<?php

include_once ('../models/UsersModel.php');

include_once ('../models/PrivilegeModel.php');
include_once ('../models/SettingsModel.php');


function OrderFunc() 
   {

   	 $daysselected = document.getElementById("orderdaysamt").value;
   
    if($daysselected == 7)
   	{		
   			
   	}
	if($daysselected == 30)
   	{
   			
   	}
   	if($daysselected == 90)
   	{
   		
   	}
   	if($daysselected == 180)
   	{		
   		
   	}

   }

function IndexAction($smarty){
/* 				CHECK USER PRIVILEGE AND AUTHORIZATION 			*/
/*--------------------------------------------------------------*/
	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	if(!$CheckUser)
		return header('Location: /authorization/?status=Ошибка авторизации');

	$GetPrivilege = GetPrivilege($CheckUser['class']);
	if(!$GetPrivilege)
		return header('Location: /admin/?status=Ошибка привилегии');

	if($GetPrivilege['flags']['access_site'] != 1)
		return header('Location: /index/?status=Забанен');

	$days = 30;
	$orderid = 'Auther.club - Premium Acces';
			
	switch ($days) 
	{
		case 30:$price = 180;break;
		case 9999:$price = 550;break;
	}
		
	switch ($days) {
		case 30:$orderid = 'Auther.club - Premium Acces';break;
		case 9999:$orderid = 'Auther.club - Premium Acces';break;
	}

	$site_name = GetSettingByName('site_name');
	$merchant = GetSettingByName('merchant_id');
	$secret = GetSettingByName('merchant_secret');
	$CheckUser['access_admin'] = $GetPrivilege['flags']['access_adminpanel'];

	$data = array(
		'shopid' => $merchant,
		'payno' => time(),
		'amount' => $price,
		'description' => $site_name,
		'us_login' => $CheckUser['login'],
		'order_id' => $orderid		
	);

    $sign = md5($merchant.":".$_REQUEST["AMOUNT"].":".$secret.":".$orderid);
	
	$smarty->assign('Title', $site_name);
	$smarty->assign('Me', $CheckUser);

	$smarty->assign('data', $data);
	$smarty->assign('sign', $sign);
	$smarty->assign('days', $days);

	$smarty->assign('status', htmlspecialchars($_GET['status']));

	loadTemplate($smarty, 'buy');

}