<?php

include_once ('../models/UsersModel.php');
include_once ('../models/ProfileModel.php');

include_once ('../models/PrivilegeModel.php');
include_once ('../models/SettingsModel.php');

include_once ('../models/ConfigModel.php');

include_once ('../models/DownloadModel.php');
include_once ('../models/ResbindingController.php');

/* 				CHECK USER PRIVILEGE AND AUTHORIZATION 			*/
/*--------------------------------------------------------------*/
	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	if(!$CheckUser)
		return header('Location: /authorization/?status=Ошибка авторизации');

	$GetPrivilege = GetPrivilege($CheckUser['class']);
	if(!$GetPrivilege)
		return header('Location: /admin/?status=Ошибка привилегии');

	if($GetPrivilege['flags']['access_site'] != 1)
		return header('Location: /index/?status=Забанен');

/* !-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- 	*/


function indexAction($smarty){
	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	if(!$CheckUser)
		return header('Location: /authorization/?status=Ошибка авторизации');

	$GetPrivilege = GetPrivilege($CheckUser['class']);
	if(!$GetPrivilege)
		return header('Location: /admin/?status=Ошибка привилегии');

	if($GetPrivilege['flags']['access_site'] != 1)
		return header('Location: /index/?status=Забанен');

	$site_name = GetSettingByName('site_name');
    $Status_Cheat = GetSettingByName('cheat_status');
    
	$CurrentTime = time();

	$smarty->assign('Title', $site_name);
	$smarty->assign('Me', $CheckUser);
	$smarty->assign('CurrentTime', $CurrentTime);
	$smarty->assign('Status_Cheat', $Status_Cheat);

	$UserApps = GetUserApps($CheckUser['id']);
	$smarty->assign('UserApp', $UserApps);

	$smarty->assign('status', htmlspecialchars($_GET['status']));

	foreach($UserApps as $key)
	{
		if($key["actived"] != 1)
		{
			echo $key['keycode'];
			echo " ; HOURS - ";
			echo $key['hours'];
			echo("<br>");
		}
	}
}