<?php

include_once ('../models/IndexModel.php');

include_once ('../models/UsersModel.php');
include_once ('../models/PrivilegeModel.php');
include_once ('../models/SettingsModel.php');



function indexAction($smarty){
	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);

	$site_name = GetSettingByName('site_name');
	

	$UserCount = count(GetAllUsers());

	$smarty->assign('Title', $site_name);
	$smarty->assign('Me', $CheckUser);
	$smarty->assign('UserCount', $UserCount);
	$smarty->assign('status', htmlspecialchars($_GET['status']));

    if(GetSettingByName('cheat_status') == "1")
        loadTemplate($smarty, 'maintenance');

	loadTemplate($smarty, 'main');
}
