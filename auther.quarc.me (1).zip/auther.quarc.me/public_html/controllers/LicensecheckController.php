<?php
include_once ('../models/UsersModel.php');
include_once ('../models/LicenseModel.php');
include_once ('../models/PrivilegeModel.php');
include_once ('../models/SettingsModel.php');


function indexAction()
{
	$binding 	= $_GET['binding'];
	$login 		= $_GET['login'];
	$password 	= $_GET['password'];

	if($binding == null){return print_r('error1440');}
	if($login == null){return print_r('error1440');}
	if($password == null){return print_r('error1440');}

	$version = GetSettingByName('version');

	$User = CheckUser($login, $password);
	if($User == false){return print_r('error1403');}

	$CheatStatus = GetSettingByName('cheat_status');
	if($CheatStatus != '1'){return print_r('error0');}

	if ($User['class'] == 'banned')
		return print_r('banned');
	
	if($User['binding'] != null)
	{

		if($User['binding'] != $binding){return print_r('errorHWID');}

	}else
	{
		EnterBinding($User['login'], $binding);
	}

	if($User['subscription'] <= time()){
		return print_r('errorTIME');
	}

	$days = intval(($User['subscription'] - time()) / 60 / 60 / 24);
	
	return print_r('success_ok');
}

function timeAction(){

return print_r(date('d.m.Y H:i'));
}

?>