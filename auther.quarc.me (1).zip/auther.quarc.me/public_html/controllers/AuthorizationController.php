<?php

include_once ('../models/IndexModel.php');

include_once ('../models/UsersModel.php');
include_once ('../models/PrivilegeModel.php');
include_once ('../models/SettingsModel.php');

include_once ('../models/CaptchaModel.php');

$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
if($CheckUser != false)
    return header('Location: /profile/');

function indexAction($smarty){
	$site_name = GetSettingByName('site_name');
	$site_key = GetSettingByName('site_key');

	$smarty->assign('Title', $site_name);
	$smarty->assign('site_key', $site_key);
	$smarty->assign('status', htmlspecialchars($_GET['status']));

	loadTemplate($smarty, 'authorization');
}

function authAction(){

	$login = $_POST['login'];
	$password = $_POST['password'];

	if(Captcha($_POST['g-recaptcha-response'], GetSettingByName('secret_key')) == false){
		return header('Location: /authorization/?status=Please prove that you are human.');
	}

	if(!$login || !$password){
		return header('Location: /authorization/?status=Fill the all text inputs.');
	}

	if(!preg_match('/^[A-z0-9@.-_\/|)(!%]{5,50}$/', $login)){
		return header('Location: /authorization/?status=Forbidden symbols.');
	}

	if($login && $password){
		$CheckUser = CheckUser($login, $password);
	}

	if(!$CheckUser){
		return header('Location: /authorization/?status=Wrong username and/or password.');
	}

	set_log("Авторизовался", $CheckUser['login']);

	setcookie('login', $login, time() + 24 * 60 * 60, "/");
	setcookie('password', $password, time() + 24 *  60 * 60, "/");

	return header('Location: /profile/');
}

function registerAction($smarty){
	$site_name = GetSettingByName('site_name');
	$site_key = GetSettingByName('site_key');

	$smarty->assign('Title', $site_name);
	$smarty->assign('site_key', $site_key);
	$smarty->assign('status', htmlspecialchars($_GET['status']));

	loadTemplate($smarty, 'register');
}

function regAction(){

	$login = $_POST['login'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$password2 = $_POST['password2'];

	if(Captcha($_POST['g-recaptcha-response'], GetSettingByName('secret_key')) == false){
		return header('Location: /authorization/register/?status=Please prove that you are human.');
	}

	if(!$login || !$email){
		return header('Location: /authorization/register/?status=Fill the all text inputs.');
	}

	if(!$password || !$password2){
		return header('Location: /authorization/register/?status=Fill the all text inputs.');
	}

	if($password != $password2){
		return header('Location: /authorization/register/?status=Passwords do not match.');
	}


	if(!preg_match('/^[A-z0-9@.-_\/|)(!%]{5,50}$/', $login)){
		return header('Location:  /authorization/register/?status=Forbidden symbols.');
	}

	if(!preg_match('/^[A-z0-9@.-_\/|)(!%]{5,50}$/', $email)){
		return header('Location:  /authorization/register/?status=Forbidden symbols.');
	}

	$Check = GiveInfo($login);
	if($Check){
		return header('Location: /authorization/register/?status=Such user already exists.');
	}


	$Check = GiveInfo($email);
		if($Check){
			return header('Location: /authorization/register/?status=Such user already exists.');
		}


	$class = GetSettingByName('default_privilege');

	register($login, $email, $password, $class);

	set_log("Зарегистрировался", $login);

	setcookie('login', $login, time() + 24 * 60 * 60, "/");
	setcookie('password', $password, time() + 24 * 60 * 60, "/");

	return header('Location: /profile/');
}

function logoutAction(){

	setcookie('login', $login, time() - 24 * 60 * 60, "/");
	setcookie('password', $password, time() - 24 * 60 * 60, "/");


	return header('Location: /');
}
