<?php

include_once ('../models/IndexModel.php');

include_once ('../models/UsersModel.php');
include_once ('../models/PrivilegeModel.php');
include_once ('../models/SettingsModel.php');

function indexAction($smarty)
{
	if (!isset($_POST[ "type" ]))
		die();

	if($_POST["type"] == "auth")
	{
		if (!isset($_POST[ "public_token" ]) || !isset($_POST[ "license" ]) || !isset($_POST[ "hwid" ]))
			die();

		$KEYDATA = GetKeyData($_POST["license"]);

		if(!$KEYDATA)
		{
			echo("{");
				echo("\"Status\"".":"."\"WrongKey\"");
			echo("}");

			die();
		}

		$OWNERDATA = GetUserByID($KEYDATA["profileid"]);

		if(!$OWNERDATA)
			die();

		if($OWNERDATA["token"] != $_POST[ "public_token" ])
			die();

		if($KEYDATA["actived"] == 0)
		{
			$endtime = time() + $KEYDATA["hours"] * 60 * 60;
			RegisterKey($_POST[ "license" ], $endtime, $_POST["hwid"]);

			$KEYDATA = GetKeyData($_POST["license"]);

			echo("{");
			echo("\"Status\"".":"."\"Activated\"".",");
			echo("\"HWID\"".":"."\"".$_POST[ "hwid" ]."\"".",");
			echo("\"License\"".":"."\"".$_POST[ "license" ]."\"".",");
			echo("\"LicenseTime\"".":"."\"".$KEYDATA[ "hours" ]."\"".",");
			echo("\"SubStartTime\"".":"."\"".$KEYDATA[ "starttime" ]."\"".",");
			echo("\"SubEndTime\"".":"."\"".$KEYDATA[ "endtime" ]."\"");
			echo("}");

			die();
		}
		else
		{
			if($KEYDATA["hwid"] == NULL)
			{
				RegisterHWID($_POST[ "license" ], $_POST["hwid"]);
			}

			$KEYDATA = GetKeyData($_POST["license"]);

			if($KEYDATA["hwid"] != $_POST[ "hwid" ])
			{
				echo("{");
					echo("\"Status\"".":"."\"WrongHWID\"".",");
					echo("\"License\"".":"."\"".$_POST[ "license" ]."\"");
				echo("}");
				
				die();
			}

			if($KEYDATA["endtime"] <= time())
			{
				echo("{");
					echo("\"Status\"".":"."\"SubEnded\"".",");
					echo("\"License\"".":"."\"".$_POST[ "license" ]."\"".",");
					echo("\"LicenseTime\"".":"."\"".$KEYDATA[ "hours" ]."\"".",");
					echo("\"SubStartTime\"".":"."\"".$KEYDATA[ "starttime" ]."\"".",");
					echo("\"SubEndTime\"".":"."\"".$KEYDATA[ "endtime" ]."\"");
				echo("}");
				
				die();
			}

			if($KEYDATA["hwid"] == $_POST[ "hwid" ] && $KEYDATA["endtime"] >= time())
			{
				echo("{");
					echo("\"Status\"".":"."\"Authorized\"".",");
					echo("\"HWID\"".":"."\"".$_POST[ "hwid" ]."\"".",");
					echo("\"License\"".":"."\"".$_POST[ "license" ]."\"".",");
					echo("\"LicenseTime\"".":"."\"".$KEYDATA[ "hours" ]."\"".",");
					echo("\"SubStartTime\"".":"."\"".$KEYDATA[ "starttime" ]."\"".",");
					echo("\"SubEndTime\"".":"."\"".$KEYDATA[ "endtime" ]."\"");
				echo("}");

				die();
			}
		}
	}
	else if($_POST["type"] == "log")
	{
		if (!isset($_POST[ "private_token" ]) || !isset($_POST[ "license" ]) || !isset($_POST[ "message" ]))
			die();

		$KEYDATA = GetKeyData($_POST["license"]);

		if(!$KEYDATA)
		{
			echo("{");
				echo("\"Status\"".":"."\"WrongKey\"");
			echo("}");

			die();
		}

		$OWNERDATA = GetUserByID($KEYDATA["profileid"]);

		if(!$OWNERDATA)		
			die();

		if($OWNERDATA["secret_token"] != $_POST[ "private_token" ])
			die();

		$LogAutomatic = GetLogAutomatization($_POST['private_token']);

		foreach($LogAutomatic as $key)
		{
			if($key["tag_filter"] == $_POST["tag"])
			{
				if($key["action"] == 0)
				{
					ExpireKey($_POST["license"]);
				}
				if($key["action"] == 1)
				{
					deleteKey($_POST["license"]);
				}
			}
		}


		create_log($_POST["license"], $_POST["message"], $_POST["tag"], $_POST[ "private_token" ]);

		echo("{");
			echo("\"Status\"".":"."\"Success\"");
		echo("}");
	}
	else { die(); }
}
