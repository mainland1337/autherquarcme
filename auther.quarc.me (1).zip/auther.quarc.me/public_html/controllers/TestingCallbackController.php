<?php

include_once ('../models/IndexModel.php');

include_once ('../models/UsersModel.php');
include_once ('../models/PrivilegeModel.php');
include_once ('../models/SettingsModel.php');

function indexAction($smarty)
{
	if (!isset($_GET[ "type" ]))
		die();

	if($_GET["type"] == "auth")
	{
		if (!isset($_GET[ "public_token" ]) || !isset($_GET[ "license" ]) || !isset($_GET[ "hwid" ]))
			die();

		$KEYDATA = GetKeyData($_GET["license"]);

		if(!$KEYDATA)
		{
			echo("{");
				echo("\"Status\"".":"."\"WrongKey\"");
			echo("}");

			die();
		}

		$OWNERDATA = GetUserByID($KEYDATA["profileid"]);

		if(!$OWNERDATA)
			die();

		if($OWNERDATA["token"] != $_GET[ "public_token" ])
			die();

		if($KEYDATA["actived"] == 0)
		{
			$endtime = time() + $KEYDATA["hours"] * 60 * 60;
			RegisterKey($_GET[ "license" ], $endtime, $_GET["hwid"]);

			$KEYDATA = GetKeyData($_GET["license"]);

			echo("{");
			echo("\"Status\"".":"."\"Activated\"".",");
			echo("\"HWID\"".":"."\"".$_GET[ "hwid" ]."\"".",");
			echo("\"License\"".":"."\"".$_GET[ "license" ]."\"".",");
			echo("\"LicenseTime\"".":"."\"".$KEYDATA[ "hours" ]."\"".",");
			echo("\"SubStartTime\"".":"."\"".$KEYDATA[ "starttime" ]."\"".",");
			echo("\"SubEndTime\"".":"."\"".$KEYDATA[ "endtime" ]."\"");
			echo("}");

			die();
		}
		else
		{
			if($KEYDATA["hwid"] == NULL)
			{
				RegisterHWID($_GET[ "license" ], $_GET["hwid"]);
			}

			$KEYDATA = GetKeyData($_GET["license"]);

			if($KEYDATA["hwid"] != $_GET[ "hwid" ])
			{
				echo("{");
					echo("\"Status\"".":"."\"WrongHWID\"".",");
					echo("\"License\"".":"."\"".$_GET[ "license" ]."\"");
				echo("}");
				
				die();
			}

			if($KEYDATA["endtime"] <= time())
			{
				echo("{");
					echo("\"Status\"".":"."\"SubEnded\"".",");
					echo("\"License\"".":"."\"".$_GET[ "license" ]."\"".",");
					echo("\"LicenseTime\"".":"."\"".$KEYDATA[ "hours" ]."\"".",");
					echo("\"SubStartTime\"".":"."\"".$KEYDATA[ "starttime" ]."\"".",");
					echo("\"SubEndTime\"".":"."\"".$KEYDATA[ "endtime" ]."\"");
				echo("}");
				
				die();
			}

			if($KEYDATA["hwid"] == $_GET[ "hwid" ] && $KEYDATA["endtime"] >= time())
			{
				echo("{");
					echo("\"Status\"".":"."\"Authorized\"".",");
					echo("\"HWID\"".":"."\"".$_GET[ "hwid" ]."\"".",");
					echo("\"License\"".":"."\"".$_GET[ "license" ]."\"".",");
					echo("\"LicenseTime\"".":"."\"".$KEYDATA[ "hours" ]."\"".",");
					echo("\"SubStartTime\"".":"."\"".$KEYDATA[ "starttime" ]."\"".",");
					echo("\"SubEndTime\"".":"."\"".$KEYDATA[ "endtime" ]."\"");
				echo("}");

				die();
			}
		}
	}
	else if($_GET["type"] == "log")
	{
		if (!isset($_GET[ "private_token" ]) || !isset($_GET[ "license" ]) || !isset($_GET[ "message" ]))
			die();

		$KEYDATA = GetKeyData($_GET["license"]);

		if(!$KEYDATA)
		{
			echo("{");
				echo("\"Status\"".":"."\"WrongKey\"");
			echo("}");

			die();
		}

		$OWNERDATA = GetUserByID($KEYDATA["profileid"]);

		if(!$OWNERDATA)		
			die();

		if($OWNERDATA["secret_token"] != $_GET[ "private_token" ])
			die();

        $LogAutomatic = GetLogAutomatization($OWNERDATA['secret_token']);

        foreach($LogAutomatic as $key)
        {
            if($key["tag_filter"] == $_GET["tag"])
            {
                if($key["action"] == 0)
                {
                    ExpireKey($_GET["license"]);
                }
                if($key["action"] == 1)
                {
                    deleteKey($_GET["license"]);
                }
            }
        }

		if($OWNERDATA["subscription"] >= time())
		{
			create_log($_GET["license"], $_GET["message"], $_GET["tag"], $_GET[ "private_token" ]);

			echo("{");
				echo("\"Status\"".":"."\"Success\"");
			echo("}");
		}
		else{
			echo("{");
				echo("\"Status\"".":"."\"PremiumOnly\"");
			echo("}");
		}
	}
	else { die(); }
}
