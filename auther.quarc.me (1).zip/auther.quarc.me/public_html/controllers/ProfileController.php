<?php

include_once ('../models/UsersModel.php');
include_once ('../models/ProfileModel.php');

include_once ('../models/PrivilegeModel.php');
include_once ('../models/SettingsModel.php');

include_once ('../models/ConfigModel.php');

include_once ('../models/DownloadModel.php');
include_once ('../models/ResbindingController.php');

/* 				CHECK USER PRIVILEGE AND AUTHORIZATION 			*/
/*--------------------------------------------------------------*/
$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
if(!$CheckUser)
	return header('Location: /authorization/?status=Ошибка авторизации');

$GetPrivilege = GetPrivilege($CheckUser['class']);
if(!$GetPrivilege)
	return header('Location: /admin/?status=Ошибка привилегии');

if($GetPrivilege['flags']['access_site'] != 1)
	return header('Location: /index/?status=Забанен');

/* !-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- 	*/


function indexAction($smarty){
	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	if(!$CheckUser)
		return header('Location: /authorization/?status=Ошибка авторизации');

	$GetPrivilege = GetPrivilege($CheckUser['class']);
	if(!$GetPrivilege)
		return header('Location: /admin/?status=Ошибка привилегии');

	if($GetPrivilege['flags']['access_site'] != 1)
		return header('Location: /index/?status=Забанен');

	if(GetSettingByName('cheat_status') == 1 && $CheckUser['login'] != "pers0na2")
		loadTemplate($smarty, 'maintenance');

	$days = SECURE($_GET['id']);
	$orderid = 'Nixware - 1 month';



	switch ($days) {
		case 30:$price = 99;break;
		case 60:$price = 179;break;
		case 90:$price = 249;break;
	}

	switch ($days) {
		case 30:$orderid = 'Nixware - 1 month';break;
		case 60:$orderid = 'Nixware - 2 month';break;
		case 90:$orderid = 'Nixware - 3 month';break;
	}

	$site_name = GetSettingByName('site_name');
	$Status_Cheat = GetSettingByName('cheat_status');
	$merchant = GetSettingByName('merchant_id');
	$secret = GetSettingByName('merchant_secret');

	/* !-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- 	*/

	$data = array(
		'shopid' => $merchant,
		'payno' => time(),
		'amount' => $price,
		'description' => $site_name,
		'us_login' => $CheckUser['login'],
		'us_days' => $days,
		'order_id' => $orderid
	);

	$sign = md5($data['shopid'].':'.$data['amount'].':'.$secret.':'.$data['order_id']);

	/* !-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- 	*/



	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	$GetPrivilege = GetPrivilege($CheckUser['class']);
	$CheckUser['access_admin'] = $GetPrivilege['flags']['access_adminpanel'];
	$CheckUser['access_banned'] = $CheckUser['flags']['banned'] == 1;
	$TicketInfo = GetTicketInfo($CheckUser['login']);

	$CurrentTime = time();

	$GetConfig = GetConfig($CheckUser['id']);

	$BuildsCount = GetBuildCount();

	$smarty->assign('UserApps', $total_user_apps);
	$smarty->assign('GetConfig', $GetConfig);
	$smarty->assign('Title', $site_name);
	$smarty->assign('Me', $CheckUser);
	$smarty->assign('CurrentTime', $CurrentTime);
	$smarty->assign('BuildsCount', $BuildsCount);
	$smarty->assign('Status_Cheat', $Status_Cheat);

	$UserApps = GetUserApps($CheckUser['id']);
	$smarty->assign('UserApp', $UserApps);

	$smarty->assign('data', $data);
	$smarty->assign('sign', $sign);

	$LogAutomatic = GetLogAutomatization($CheckUser['secret_token']);
	$smarty->assign('LogAutomatic', $LogAutomatic);

	$Files = GetFiles($CheckUser['secret_token']);
	$smarty->assign('Files', $Files);

	$smarty->assign('status', htmlspecialchars($_GET['status']));

	$TableCount = TableCount2('appkeys', $CheckUser['id']);
	$TableCount2 = TableCount3('appkeys', $CheckUser['id']);

	$smarty->assign('total_app_keys',$TableCount);
	$smarty->assign('total_app_keys_actived',$TableCount2);

	loadTemplate($smarty, 'profile');

}

function reset_passwordAction($smarty){
	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	if(!$CheckUser)
		return header('Location: /authorization/?status=Ошибка авторизации');

	$GetPrivilege = GetPrivilege($CheckUser['class']);
	if(!$GetPrivilege)
		return header('Location: /admin/?status=Ошибка привилегии');

	if($GetPrivilege['flags']['access_site'] != 1)
		return header('Location: /index/?status=Забанен');

	$site_name = GetSettingByName('site_name');

	$CheckUser['access_admin'] = $GetPrivilege['flags']['access_adminpanel'];

	$GetConfig = GetConfig($CheckUser['id']);


	$smarty->assign('GetConfig', $GetConfig);
	$smarty->assign('pageTitle', $site_name);
	$smarty->assign('Me', $CheckUser);
	$smarty->assign('status', htmlspecialchars($_GET['status']));

	loadTemplate($smarty, 'profile-reset-password');
}

function res_passAction(){

	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	if(!$CheckUser)
		return header('Location: /authorization/?status=Ошибка авторизации');

	$GetPrivilege = GetPrivilege($CheckUser['class']);
	if(!$GetPrivilege)
		return header('Location: /admin/?status=Ошибка привилегии');

	if($GetPrivilege['flags']['access_site'] != 1)
		return header('Location: /index/?status=Забанен');

	$old_password 	= md5($_POST['old_password']);
	$new_password 	= md5($_POST['new_password']);
	$new_password2 	= md5($_POST['new_password2']);

	if($old_password && $new_passowrd && $new_passowrd2)
		return header('Location: /error/?error=empty query');

	if($new_passowrd != $new_passowrd2)
		return header('Location: /error/?error=passwords do not match');

	if($CheckUser['password'] != $old_password)
		return header('Location: /error/?error=old password is incorrect');

	set_log("Сбросил пароль" , $CheckUser['login']);

	resetPassword($CheckUser['login'] , $new_password);

	return header('Location: ' . $_SERVER['HTTP_REFERER']);
}

function create_keyAction(){

	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	if(!$CheckUser)
		return header('Location: /authorization/?status=Ошибка авторизации');

	$GetPrivilege = GetPrivilege($CheckUser['class']);
	if(!$GetPrivilege)
		return header('Location: /admin/?status=Ошибка привилегии');

	if($GetPrivilege['flags']['access_site'] != 1)
		return header('Location: /index/?status=Забанен');

	$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

	$total_addkeys = $_POST["total_keys"];

	if($total_addkeys > 20)
		$total_addkeys = 20;

	for ($i = 0; $i < $total_addkeys; $i++)
	{
		switch($_POST["key_distance"])
		{
			case 1: create_app(	$CheckUser["id"], substr(str_shuffle($permitted_chars), 0, 8), $_POST["hours"], $_POST["tag"] ); break;
			case 2: create_app(	$CheckUser["id"], substr(str_shuffle($permitted_chars), 0, 16), $_POST["hours"], $_POST["tag"] ); break;
			case 3: create_app(	$CheckUser["id"], substr(str_shuffle($permitted_chars), 0, 24), $_POST["hours"], $_POST["tag"] ); break;
			case 4: create_app(	$CheckUser["id"], substr(str_shuffle($permitted_chars), 0, 32), $_POST["hours"], $_POST["tag"] ); break;
		}
	}

	return header('Location: /profile/');
}

function create_log_actionAction(){

	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	if(!$CheckUser)
		return header('Location: /authorization/?status=Ошибка авторизации');

	$GetPrivilege = GetPrivilege($CheckUser['class']);
	if(!$GetPrivilege)
		return header('Location: /admin/?status=Ошибка привилегии');

	if($GetPrivilege['flags']['access_site'] != 1)
		return header('Location: /index/?status=Забанен');

	create_log_filter($CheckUser["secret_token"], $_POST["Filter"], $_POST["Action"]);

	return header('Location: /profile/');
}

function delete_log_actionAction(){

	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	if(!$CheckUser)
		return header('Location: /authorization/?status=Ошибка авторизации');

	$GetPrivilege = GetPrivilege($CheckUser['class']);
	if(!$GetPrivilege)
		return header('Location: /admin/?status=Ошибка привилегии');

	if($GetPrivilege['flags']['access_site'] != 1)
		return header('Location: /index/?status=Забанен');

	delete_filter($_POST["id"]);

	return header('Location: ' . $_SERVER['HTTP_REFERER']);
}

function delete_keyAction(){

	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	if(!$CheckUser)
		return header('Location: /authorization/?status=Ошибка авторизации');

	$GetPrivilege = GetPrivilege($CheckUser['class']);
	if(!$GetPrivilege)
		return header('Location: /admin/?status=Ошибка привилегии');

	if($GetPrivilege['flags']['access_site'] != 1)
		return header('Location: /index/?status=Забанен');

	deleteKey($_POST["keycode"]);

	return header('Location: ' . $_SERVER['HTTP_REFERER']);
}

function reset_hwidAction(){

	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	if(!$CheckUser)
		return header('Location: /authorization/?status=Ошибка авторизации');

	$GetPrivilege = GetPrivilege($CheckUser['class']);
	if(!$GetPrivilege)
		return header('Location: /admin/?status=Ошибка привилегии');

	if($GetPrivilege['flags']['access_site'] != 1)
		return header('Location: /index/?status=Забанен');

	resetHwidKey($_POST["keycode"]);

	return header('Location: ' . $_SERVER['HTTP_REFERER']);
}

function file_uploadAction(){

	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	if(!$CheckUser)
		return header('Location: /authorization/?status=Ошибка авторизации');

	$GetPrivilege = GetPrivilege($CheckUser['class']);
	if(!$GetPrivilege)
		return header('Location: /admin/?status=Ошибка привилегии');

	if($GetPrivilege['flags']['access_site'] != 1)
		return header('Location: /index/?status=Забанен');


	$file = $_FILES["Executable"];

	$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOP';

	if($_POST["Action"] == "0")
		create_file($_POST["Filter"], substr(str_shuffle($permitted_chars), 0, 512), $_POST["Action"], $CheckUser["secret_token"], file_get_contents($_FILES["Executable"]));
	if($_POST["Action"] == "1")
		create_file($_POST["Filter"], "Отключено", $_POST["Action"], $CheckUser["secret_token"], file_get_contents($_FILES["Executable"]));

	return header('Location: ' . $_SERVER['HTTP_REFERER']);
}

function file_updateAction(){

	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	if(!$CheckUser)
		return header('Location: /authorization/?status=Ошибка авторизации');

	$GetPrivilege = GetPrivilege($CheckUser['class']);
	if(!$GetPrivilege)
		return header('Location: /admin/?status=Ошибка привилегии');

	if($GetPrivilege['flags']['access_site'] != 1)
		return header('Location: /index/?status=Забанен');

	$file = $_FILES["Executable"];

	return header('Location: ' . $_SERVER['HTTP_REFERER']);
}


function delete_fileAction(){

	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	if(!$CheckUser)
		return header('Location: /authorization/?status=Ошибка авторизации');

	$GetPrivilege = GetPrivilege($CheckUser['class']);
	if(!$GetPrivilege)
		return header('Location: /admin/?status=Ошибка привилегии');

	if($GetPrivilege['flags']['access_site'] != 1)
		return header('Location: /index/?status=Забанен');

	deleteFile($_POST["id"]);

	return header('Location: ' . $_SERVER['HTTP_REFERER']);
}


?>
