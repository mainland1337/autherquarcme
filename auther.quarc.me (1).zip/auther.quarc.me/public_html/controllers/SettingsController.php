<?php

include_once ('../models/PrivilegeModel.php');


include_once ('../models/UsersModel.php');

include_once ('../models/SettingsModel.php');


/* 				CHECK USER PRIVILEGE AND AUTHORIZATION 			*/
/*--------------------------------------------------------------*/
	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	if(!$CheckUser)
		return header('Location: /authorization/?status=ошибка авторизации');

	$GetPrivilege = GetPrivilege($CheckUser['class']);
	if(!$GetPrivilege)
		return header('Location: /error/?error=privilege-error');

	if($GetPrivilege['flags']['access_site'] != 1)
		return header('Location: /error/?error=BANNED');

	if($GetPrivilege['flags']['access_settings'] != 1)
		return header('Location: /error/?error=privilege accesss denied');
/* !-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- 	*/


function indexAction($smarty){
	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	if(!$CheckUser)
		return header('Location: /authorization/?status=ошибка авторизации');

	$GetPrivilege = GetPrivilege($CheckUser['class']);
	if(!$GetPrivilege)
		return header('Location: /error/?error=privilege-error');

	if($GetPrivilege['flags']['access_site'] != 1)
		return header('Location: /error/?error=BANNED');

	if($GetPrivilege['flags']['access_settings'] != 1)
		return header('Location: /error/?error=privilege accesss denied');

	$GetAllSettings = GetAllSettings();
	$site_name = GetSettingByName('site_name');

	$smarty->assign('Title', $site_name);
	$smarty->assign('GetAllSettings', $GetAllSettings);
	$smarty->assign('Me', $CheckUser);
	$smarty->assign('status', htmlspecialchars($_GET['status']));

	loadTemplate($smarty, 'settings');
}

function saveAction(){
	$CheckUser = CheckUser($_COOKIE['login'], $_COOKIE['password']);
	if(!$CheckUser)
		return header('Location: /authorization/?status=ошибка авторизации');

	$GetPrivilege = GetPrivilege($CheckUser['class']);
	if(!$GetPrivilege)
		return header('Location: /error/?error=privilege-error');

	if($GetPrivilege['flags']['access_site'] != 1)
		return header('Location: /error/?error=BANNED');

	if($GetPrivilege['flags']['access_settings'] != 1)
		return header('Location: /error/?error=privilege accesss denied');
		
	$data = $_POST;

	if($data == null)
		return header('Location: /error/?error=empty query');

	set_log("Обновил настройки сайта", $CheckUser['login']);
	saveSettings($data);

	return header('Location: ' . $_SERVER['HTTP_REFERER']);

}
