<?php 
include_once ("../models/UsersModel.php");
include_once ("../models/PrivilegeModel.php");
include_once ("../models/SettingsModel.php");

function getIP() {
	if(isset($_SERVER["HTTP_X_REAL_IP"])) 
		return $_SERVER["HTTP_X_REAL_IP"];
	return $_SERVER["REMOTE_ADDR"];			    
}


function indexAction()
{
	$AMT_PRICE          = $_REQUEST["AMOUNT"];
	$orderid            = $_REQUEST["MERCHANT_ORDER_ID"];
	$P_EMAIL 	        = $_REQUEST["P_EMAIL"];	
	$P_PHONE 	        = $_REQUEST["P_PHONE"];	
	$P_PAYID 	        = $_REQUEST["CUR_ID"];	
	$us_login 	        = $_REQUEST["us_login"];	

    if (!in_array(getIP(), array('136.243.38.147', '136.243.38.149', '136.243.38.150', '136.243.38.151', '136.243.38.189', '136.243.38.108'))) {
        die("hacking attempt!");
    }

    $result =  file_get_contents("https://marketplace.quarc.me/notification?customer=".$us_login."&amount=".$AMT_PRICE);

	die("YES");
}
